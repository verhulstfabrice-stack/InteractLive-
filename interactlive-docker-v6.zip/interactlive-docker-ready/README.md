# ⚡ InteractLive - Version Locale v2.0

Plateforme de sondages interactifs en temps réel, 100% locale.

## 🚀 Installation Rapide (Windows)

### Prérequis
- **Node.js 18+** : [Télécharger ici](https://nodejs.org/) (version LTS recommandée)

### Installation
1. **Extraire** le dossier ZIP
2. **Double-cliquer** sur `install.bat`
3. Attendre la fin de l'installation

### Démarrage
1. **Double-cliquer** sur `start.bat`
2. Le navigateur s'ouvre automatiquement sur **http://localhost:3000**

> **Note :** Le script lance deux serveurs :
> - **Port 3000** : Interface web (frontend Vite)
> - **Port 3001** : API backend + WebSocket (Socket.io)

---

## 📱 Utilisation

### Pour le Présentateur
1. Aller sur **http://localhost:3000**
2. Se connecter avec n'importe quel email (pas de mot de passe requis)
3. Créer un événement
4. Ajouter des questions (QCM, Nuage de mots, Questions ouvertes)
5. Optionnel : importer des questions depuis Moodle XML
6. Cliquer sur **"Lancer la présentation"** pour démarrer

### Pour les Participants
1. Scanner le **QR Code** affiché par le présentateur (avec l'IP locale)
2. Ou aller sur **http://[IP-DU-PC]:3000/join**
3. Entrer le **code** de l'événement
4. Choisir un **pseudo**
5. Répondre aux questions en temps réel !

### Trouver l'IP de votre PC
Le serveur affiche automatiquement l'IP au démarrage :
```
📍 Accès local:     http://localhost:3000
📍 Accès réseau:    http://192.168.1.XX:3000
```

Le QR Code affiché dans la vue présentateur utilise automatiquement cette IP locale.

---

## ✨ Fonctionnalités

### Types de questions
- **QCM** : Questions à choix multiples avec bonne réponse identifiée
- **Nuage de mots** : Les participants envoient des mots qui s'affichent en temps réel
- **Questions ouvertes** : Réponses texte libre

### Vue Présentateur
- Graphiques animés en temps réel (barres de progression colorées)
- Résultats colorés : **vert** = bonne réponse, **rouge** = mauvaise réponse
- Nuage de mots interactif avec tailles proportionnelles à la fréquence
- QR Code avec IP locale pour accès rapide des participants
- Navigation entre questions avec persistance des réponses
- Contrôles : ouvrir/fermer les votes, afficher/masquer les résultats

### Vue Participant (mobile-first)
- Interface responsive optimisée pour smartphones
- Texte complet des réponses visible (pas juste A, B, C, D)
- Boutons colorés pour les QCM
- Champ de saisie pour nuages de mots et questions ouvertes

### Gestion des événements
- **Export Excel/CSV** : Téléchargez les résultats avec pseudos, réponses et horodatage
- **Réinitialisation** : Remettez à zéro la progression d'un événement
- **Import Moodle XML** : Importez vos questions depuis Moodle

---

## 📥 Import Moodle

Vous pouvez importer des questions depuis Moodle :
1. Dans Moodle, exportez vos questions au format **XML Moodle**
2. Dans InteractLive, ouvrez l'éditeur d'événement
3. Cliquez sur **"Importer Moodle XML"**
4. Sélectionnez votre fichier

**Types supportés :** Questions à choix multiples (QCM)

---

## 📊 Export des résultats

Après un événement, vous pouvez exporter les résultats :
1. Ouvrez l'éditeur de l'événement
2. Cliquez sur **"Exporter résultats (Excel)"**
3. Un fichier CSV s'ouvre dans Excel avec :
   - Nom de la question
   - Type de question
   - Pseudo du participant
   - Réponse donnée
   - Correct/Incorrect (pour les QCM)
   - Date et heure

---

## 🔄 Réinitialisation

Pour relancer un événement :
1. Ouvrez l'éditeur de l'événement
2. Cliquez sur **"Réinitialiser la progression"**
3. Confirmez la suppression
4. Toutes les réponses et participants sont supprimés
5. Le statut revient à "Brouillon"

---

## 🔧 Configuration Avancée

### Variables d'environnement (.env)
```env
# Base de données SQLite (par défaut)
DATABASE_URL="file:./data/interactlive.db"

# Secret pour les sessions
JWT_SECRET="votre-secret-personnalise"

# Port du serveur API
PORT=3001
```

### Commandes disponibles
```bash
npm run dev      # Démarrer en mode développement (frontend + backend)
npm run server   # Démarrer uniquement le backend
npm run client   # Démarrer uniquement le frontend
npm run build    # Compiler pour la production
npm start        # Démarrer en mode production
```

---

## 🌐 Accès depuis d'autres appareils

### Sur le même réseau WiFi
Les participants peuvent rejoindre depuis leur smartphone en utilisant l'IP de votre PC :
```
http://192.168.1.XX:3000/join
```

### Pare-feu Windows
Si les participants ne peuvent pas se connecter :
1. Ouvrir **Pare-feu Windows Defender**
2. Cliquer sur **"Autoriser une application"**
3. Ajouter **Node.js** à la liste des applications autorisées
4. Cocher les cases "Privé" et "Public"

---

## 📁 Structure du projet

```
interactlive-local/
├── client/              # Frontend React + TypeScript
│   └── src/
│       ├── pages/       # Pages (Home, Dashboard, EventEditor, PresenterView, ParticipantView, JoinEvent, Login)
│       ├── hooks/       # Hooks personnalisés (useSocket pour WebSocket)
│       ├── stores/      # État global (Zustand)
│       └── lib/         # Configuration tRPC
├── server/              # Backend Express + Socket.io
│   ├── index.ts         # Serveur principal + tRPC + WebSocket + Auth
│   └── moodleImport.ts  # Service d'import Moodle XML
├── prisma/              # Schéma de base de données SQLite
├── data/                # Base de données SQLite (créée automatiquement)
├── install.bat          # Script d'installation Windows
├── start.bat            # Script de démarrage Windows
└── .env                 # Configuration
```

---

## ❓ Dépannage

### "Cannot GET /"
→ Assurez-vous que les deux serveurs sont lancés (npm run dev)
→ Attendez quelques secondes que Vite démarre

### "Node.js n'est pas installé"
→ Téléchargez Node.js sur https://nodejs.org/

### "Les participants ne peuvent pas se connecter"
→ Vérifiez que tous les appareils sont sur le même réseau WiFi
→ Vérifiez le pare-feu Windows (autorisez Node.js)
→ Utilisez l'IP affichée au démarrage du serveur

### "Le QR Code affiche localhost"
→ Le serveur n'a pas pu détecter l'IP locale
→ Vérifiez que votre PC est connecté au réseau WiFi
→ L'URL affichée sous le QR Code doit contenir votre IP locale (ex: 192.168.1.XX)

### "Le nuage de mots ne s'affiche pas"
→ Vérifiez que la question est bien de type "Nuage de mots"
→ Les mots apparaissent en temps réel quand les participants les envoient
→ Vérifiez la connexion WebSocket (indicateur vert dans le header)

### "Erreur de base de données"
→ Supprimez le fichier `data/interactlive.db`
→ Relancez `install.bat`

### "Port déjà utilisé"
→ Fermez les autres applications utilisant les ports 3000 ou 3001
→ Ou modifiez les ports dans `.env` et `vite.config.ts`

---

## 📄 Licence

MIT - Libre d'utilisation et de modification.
