import { XMLParser } from "fast-xml-parser";

export interface MoodleQuestion {
  type: "mcq" | "wordcloud" | "open";
  title: string;
  payload: {
    options?: Array<{ id: string; text: string; isCorrect: boolean }>;
    explanation?: string;
    category?: string;
    timerDuration?: number;
  };
}

export interface MoodleImportResult {
  success: boolean;
  questions: MoodleQuestion[];
  skipped: number;
  errors: string[];
}

/**
 * Extrait le texte d'une structure XML complexe
 */
function extractText(node: any): string {
  if (node === null || node === undefined) return "";
  if (typeof node === "string") return node.trim();
  if (typeof node === "number") return String(node);
  
  // Gérer les tableaux
  if (Array.isArray(node)) {
    for (const item of node) {
      const text = extractText(item);
      if (text) return text;
    }
    return "";
  }
  
  // Gérer les objets
  if (typeof node === "object") {
    // CDATA
    if ("#text" in node) return extractText(node["#text"]);
    if ("__cdata" in node) return extractText(node["__cdata"]);
    
    // Balise text imbriquée
    if ("text" in node) return extractText(node.text);
    
    // Parcourir les propriétés
    for (const key of Object.keys(node)) {
      if (key.startsWith("@")) continue;
      const text = extractText(node[key]);
      if (text) return text;
    }
  }
  
  return "";
}

/**
 * Vérifie si le contenu est un XML Moodle valide
 */
export function isValidMoodleXML(xmlContent: string): boolean {
  if (!xmlContent || typeof xmlContent !== "string") return false;
  const content = xmlContent.trim();
  return content.includes("<quiz") && content.includes("<question");
}

/**
 * Parse un fichier XML Moodle et extrait les questions
 */
export function parseMoodleXML(xmlContent: string): MoodleImportResult {
  const result: MoodleImportResult = {
    success: false,
    questions: [],
    skipped: 0,
    errors: [],
  };

  try {
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: "@_",
      textNodeName: "#text",
      cdataPropName: "__cdata",
      isArray: (name) => name === "question" || name === "answer",
    });

    const parsed = parser.parse(xmlContent);
    
    // Trouver les questions
    let questions: any[] = [];
    if (parsed.quiz?.question) {
      questions = Array.isArray(parsed.quiz.question) 
        ? parsed.quiz.question 
        : [parsed.quiz.question];
    }

    // Suivre la catégorie courante (Moodle utilise des questions type="category" comme séparateurs)
    let currentCategory = "";

    for (const q of questions) {
      const qType = q["@_type"];

      // Les balises <question type="category"> définissent la catégorie des questions suivantes
      if (qType === "category") {
        // Extrait le nom : "$course$/Nom" → on garde le dernier segment
        const catRaw = extractText(q.category);
        if (catRaw) {
          const parts = catRaw.split("/");
          currentCategory = parts[parts.length - 1].trim();
        }
        continue;
      }

      // Ignorer les autres types non supportés
      if (qType !== "multichoice") {
        result.skipped++;
        continue;
      }

      try {
        // Extraire le titre
        const title = extractText(q.questiontext);
        if (!title) {
          result.skipped++;
          result.errors.push("Question sans titre ignorée");
          continue;
        }

        // Extraire les réponses
        const answers = Array.isArray(q.answer) ? q.answer : [q.answer];
        const options: Array<{ id: string; text: string; isCorrect: boolean }> = [];

        for (let i = 0; i < answers.length; i++) {
          const answer = answers[i];
          const text = extractText(answer);
          const fraction = parseFloat(answer["@_fraction"] || "0");
          
          if (text) {
            options.push({
              id: `opt_${i + 1}`,
              text,
              isCorrect: fraction > 0,
            });
          }
        }

        if (options.length < 2) {
          result.skipped++;
          result.errors.push(`Question "${title.substring(0, 30)}..." ignorée: moins de 2 options`);
          continue;
        }

        // Extraire l'explication pédagogique depuis <generalfeedback>
        // C'est la balise native Moodle pour le feedback général à la question
        const explanation = extractText(q.generalfeedback);

        // Log de debug : visible dans la console du serveur lors de l'import
        console.log(`[Moodle Import] "${title.substring(0, 40)}..." → explication: ${explanation ? `"${explanation.substring(0, 50)}..."` : "(aucune)"}, catégorie: ${currentCategory || "(aucune)"}`);

        // Timer personnalisé via <tags><tag>timer:60</tag></tags> (facultatif)
        let customTimer: number | undefined;
        const tagsNode = q.tags;
        if (tagsNode) {
          const tagList = Array.isArray(tagsNode.tag) ? tagsNode.tag : [tagsNode.tag];
          for (const t of tagList) {
            const tagText = extractText(t);
            const match = /^timer\s*:\s*(\d+)$/i.exec(tagText);
            if (match) {
              const n = parseInt(match[1], 10);
              if (!isNaN(n) && n > 0) customTimer = n;
            }
          }
        }

        const payload: MoodleQuestion["payload"] = {
          options,
          timerDuration: customTimer ?? 30,
        };
        if (explanation) payload.explanation = explanation;
        if (currentCategory) payload.category = currentCategory;

        result.questions.push({
          type: "mcq",
          title,
          payload,
        });
      } catch (err) {
        result.skipped++;
        result.errors.push(`Erreur lors du parsing d'une question: ${err}`);
      }
    }

    result.success = result.questions.length > 0;
  } catch (err) {
    result.errors.push(`Erreur de parsing XML: ${err}`);
  }

  return result;
}
