# 🚀 Déploiement v3 → v4 sur ton VPS OVH

## ✅ Bonne nouvelle : pas de migration DB destructive

Contrairement à la v2 → v3 qui nécessitait la solution A (wipe) ou la solution B
(commande SQL manuelle), la **v3 → v4 est beaucoup plus simple** :

- Ajout d'une table `RevokedToken` (pas de modif des tables existantes)
- Pas de champ ajouté à des tables peuplées
- `prisma db push` gère tout automatiquement au premier démarrage

**Tu conserves tous tes comptes et événements.** Seule chose : tu devras te
reconnecter une fois (les anciens tokens JWT n'ont pas de `jti`, ils sont
automatiquement invalidés).

---

## Procédure de déploiement (8 min)

### 1. Sauvegarder la DB avant (sécurité)

Sur ton VPS :

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
docker compose exec interactlive sqlite3 /data/interactlive.db ".backup /data/backup-avant-v4.db"
```

### 2. Arrêter la v3 (sans supprimer les volumes !)

```bash
docker compose down
# ⚠️ PAS de -v, on garde les données
```

### 3. Remonter d'un cran + sauvegarder l'ancien dossier

```bash
cd ~/interactlive/interactlive-app
mv interactlive-docker-ready interactlive-docker-ready.v3.backup-$(date +%F)
```

### 4. Transférer le zip v4 depuis ton PC

**Sur ton PC (PowerShell)** :

```powershell
scp C:\Users\verhu\Downloads\interactlive-docker-v4.zip debian@51.178.25.60:~/
```

### 5. Sur le VPS, dézipper + récupérer le .env

```bash
cd ~/interactlive/interactlive-app
unzip ~/interactlive-docker-v4.zip
# Si le dossier est nommé différemment, adapte :
mv interactlive-docker-ready interactlive-docker-ready 2>/dev/null || true

# Récupérer le .env de la v3
cp interactlive-docker-ready.v3.backup-*/docker/.env interactlive-docker-ready/docker/.env
chmod 600 interactlive-docker-ready/docker/.env
```

### 6. Vérifier que le .env est bon

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
cat .env
```

Tu dois avoir les 3 bonnes lignes :

```
JWT_SECRET=<ton secret existant>
ALLOWED_ORIGINS=https://interactlive.duckdns.org
PUBLIC_URL=https://interactlive.duckdns.org
```

### 7. Lancer le déploiement v4

```bash
bash ../deploy-docker-guide/scripts/02-deploy.sh interactlive.duckdns.org verhulst.fabrice@gmail.com
```

Le script va :
- Rebuilder l'image (~3-5 min)
- Redémarrer les conteneurs
- Le certificat HTTPS existant est **conservé** (pas besoin de re-demander)

### 8. Vérification

```bash
docker compose ps
# Les 3 conteneurs doivent être "Up"

docker compose logs --tail=20 interactlive
# Tu dois voir "🚀 InteractLive - Serveur démarré !"
```

---

## 🧪 Tests à faire après le déploiement

### Test 1 — Reconnexion nécessaire

1. Ouvre https://interactlive.duckdns.org dans ton navigateur habituel
2. Tu dois être **redirigé vers la page de login** (ton ancien token est invalidé)
3. Reconnecte-toi avec `verhulst.fabrice@gmail.com` + ton mot de passe
4. Tu retrouves tes événements et utilisateurs existants

### Test 2 — Rate limiting login

1. En mode privé, essaie de te connecter 5 fois avec un **mauvais mot de passe**
2. Au 6ème essai, tu dois voir : « Trop de tentatives de connexion. Veuillez
   réessayer dans 15 minutes. »

(Attention : ça bloque ton IP pour 15 min. Pour débloquer plus vite, tu peux
redémarrer le conteneur : `docker compose restart interactlive`.)

### Test 3 — Socket.io sécurisé

1. Crée un événement, lance la présentation
2. Note le code à 6 caractères (ex: `ABC123`)
3. En mode privé, **sans être connecté**, essaie d'aller sur
   `https://interactlive.duckdns.org/presenter/XX` (avec un ID d'événement)
4. Tu dois être redirigé vers login, et aucune action présentateur ne doit passer

### Test 4 — Blocage immédiat

1. Crée un deuxième compte de test
2. Approuve-le depuis le panel admin
3. Connecte-toi avec ce compte dans un 2ème navigateur (ou fenêtre privée)
4. Depuis ton compte admin, bloque ce compte
5. Dans le 2ème navigateur : tu dois recevoir un **popup d'alerte** « Compte
   bloqué par l'administrateur » et être redirigé vers la page de login
6. Si tu tentes de te reconnecter : message « Compte bloqué »

### Test 5 — CSP en-têtes

Depuis ton PC, vérifie que les en-têtes de sécurité sont bien présents :

```powershell
curl.exe -sI https://interactlive.duckdns.org/
```

Tu dois voir dans la sortie :
- `Content-Security-Policy: ...`
- `Strict-Transport-Security: ...`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`

---

## 🔄 Rollback en cas de souci

Si quelque chose ne va pas, tu peux revenir à la v3 :

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
docker compose down
cd ~/interactlive/interactlive-app
rm -rf interactlive-docker-ready
mv interactlive-docker-ready.v3.backup-* interactlive-docker-ready
cd interactlive-docker-ready/docker
docker compose up -d
```

Tes données sont intactes (volumes Docker préservés).

---

## Questions fréquentes

**Q : Est-ce que mes événements en cours vont être perdus ?**
Non. Les volumes Docker (DB SQLite, certificats HTTPS) sont conservés pendant
le `docker compose down` classique.

**Q : Je vais recevoir un message "Compte bloqué" alors que je suis admin ?**
Non. La révocation ne s'applique qu'aux comptes effectivement bloqués depuis
la page admin. Toi, tu seras simplement redirigé vers la page de connexion
(token obsolète), tu te reconnectes, c'est tout.

**Q : Et si un participant a un événement en cours sur son téléphone ?**
Il recevra une déconnexion WebSocket et pourra se reconnecter automatiquement
après le redémarrage (reconnexion automatique déjà implémentée dans `useSocket`).
