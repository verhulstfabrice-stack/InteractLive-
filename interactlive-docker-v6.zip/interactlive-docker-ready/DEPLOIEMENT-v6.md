# 🚀 Déploiement v5 → v6

**Sprint 3** — Questions à trous.

## ✅ Migration ultra-simple

- ❌ Pas de modif schéma base de données
- ❌ Pas de nouvelle dépendance npm
- ✅ Juste un rebuild Docker avec le nouveau code

**Durée totale : ~5 minutes.**

---

## Procédure

### 1. Transférer le zip v6 depuis ton PC

```powershell
scp C:\Users\verhu\Downloads\interactlive-docker-v6.zip debian@51.178.25.60:~/
```

### 2. Sur le VPS

```bash
# Stopper la v5 (volumes conservés)
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
docker compose down

# Sauvegarder l'actuelle
cd ~/interactlive/interactlive-app
mv interactlive-docker-ready interactlive-docker-ready.v5.backup

# Dézipper la v6
unzip ~/interactlive-docker-v6.zip

# Récupérer le .env
cp interactlive-docker-ready.v5.backup/docker/.env interactlive-docker-ready/docker/.env
chmod 600 interactlive-docker-ready/docker/.env

# Vérification
cat interactlive-docker-ready/docker/.env
# Doit contenir : JWT_SECRET, ALLOWED_ORIGINS=https://interactlive.duckdns.org, PUBLIC_URL=https://interactlive.duckdns.org
```

### 3. Lancer le déploiement

```bash
cd interactlive-docker-ready/docker
bash ../deploy-docker-guide/scripts/02-deploy.sh interactlive.duckdns.org verhulst.fabrice@gmail.com
```

Build rapide (~2 min) grâce au cache Docker.

### 4. Vérifier

```bash
docker compose ps
# Les 3 conteneurs doivent être "Up"
```

---

## 🧪 Tests à faire après déploiement

### Test 1 — Créer une question à trous

1. Va sur https://interactlive.duckdns.org
2. Crée un nouvel événement (ou ouvre-en un existant)
3. Clique **"+ Ajouter une question"**
4. Sélectionne le nouveau type **"✏️ À trous"** (à droite des autres types)
5. Tape dans l'énoncé :
   > La pédagogie de `{}` postule que l'apprentissage se fait par `{}`.
6. **Effet attendu** : sous le champ "type", tu vois "2 trous détectés" et 2 cartes apparaissent
7. Remplis :
   - **Trou 1** — Réponse : `Dewey`, ajoute synonyme `John Dewey`
   - **Trou 2** — Réponse : `action`, ajoute synonyme `l'action`
8. Clique **"Créer la question"**

### Test 2 — Côté participant

1. Lance la présentation, partage le code à 6 caractères
2. Sur un autre appareil (ou navigation privée), rejoins en tant que participant
3. Quand le présentateur affiche la question à trous, tu dois voir :
   > La pédagogie de `[___]` postule que l'apprentissage se fait par `[___]`.
4. Tape dans le premier trou : **dewey** (en minuscules — doit être validé)
5. Tape dans le deuxième : **L'action** (avec apostrophe — doit être validé)
6. Bouton "Envoyer mes réponses" apparaît seulement quand les 2 trous sont remplis
7. Clique → message "✓ Réponse envoyée"

### Test 3 — Vue résultats côté présentateur

Quand au moins 1 participant a répondu :

1. Sur la vue présentateur, active l'affichage des résultats (touche `R`)
2. Tu dois voir un toggle **"📊 Vue par trou / 👥 Vue par participant"**
3. **Vue par trou** : pour chaque trou, % bonnes réponses + barre verte + erreurs fréquentes
4. **Vue par participant** : tableau avec scores individuels

### Test 4 — Tolérance orthographique

Crée une question avec réponse attendue `réflexion`.

Demande à un participant de tester ces réponses :
- `réflexion` → ✓
- `reflexion` → ✓ (accent ignoré)
- `Réflexion` → ✓ (casse ignorée)
- ` réflexion ` → ✓ (espaces ignorés)
- `reflection` → ✗ (orthographe différente, à mettre en synonyme si tu veux l'accepter)

### Test 5 — Modification d'une question existante

Les boutons "Modifier" / "Supprimer" sur les questions fillBlank fonctionnent
comme pour les autres types.

---

## 🔄 Rollback si besoin

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
docker compose down
cd ~/interactlive/interactlive-app
rm -rf interactlive-docker-ready
mv interactlive-docker-ready.v5.backup interactlive-docker-ready
cd interactlive-docker-ready/docker
docker compose up -d
```

Les données sont préservées (volumes Docker non touchés).

---

## 💡 Conseils pédagogiques pour exploiter le type "à trous"

**Pour les concepts et théoriciens** : 1 ou 2 trous max par question, focus sur
le mot-clé essentiel (ne pas mettre des trous sur des mots de liaison).

**Pour les définitions** : laisser un seul trou sur le terme à définir, et
utiliser les synonymes pour gérer les formulations équivalentes.

**Pour la grammaire / formulation** : **éviter** ce format pour évaluer la
forme rédactionnelle (l'évaluation est trop binaire). Préférer les questions
ouvertes pour ce besoin.

**Pour les chiffres et dates** : très efficace ! Réponse attendue `1916`,
synonymes possibles : `mil neuf cent seize`, `1916.0`...

**Astuce gain de temps** : si tu hésites sur les synonymes à anticiper, lance
la question une première fois sans synonymes. Regarde dans la "Vue par trou"
les erreurs fréquentes : ce sont souvent les synonymes que tu auras envie
d'ajouter pour les futures sessions.
