@echo off
title InteractLive - Installation
color 0B

echo.
echo ========================================
echo    InteractLive - Installation
echo ========================================
echo.

:: Verifier si Node.js est installe
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERREUR] Node.js n'est pas installe!
    echo.
    echo Veuillez installer Node.js depuis:
    echo https://nodejs.org/
    echo.
    echo Choisissez la version LTS (recommandee)
    echo.
    pause
    exit /b 1
)

echo [OK] Node.js detecte: 
node --version
echo.

:: Installer les dependances
echo [INFO] Installation des dependances npm...
echo [INFO] Cela peut prendre 1-2 minutes...
call npm install
if %ERRORLEVEL% NEQ 0 (
    echo [ERREUR] Echec de l'installation des dependances
    pause
    exit /b 1
)
echo [OK] Dependances installees
echo.

:: Generer le client Prisma (version locale, PAS npx)
echo [INFO] Generation du client Prisma...
call node_modules\.bin\prisma generate
if %ERRORLEVEL% NEQ 0 (
    echo [ERREUR] Echec de la generation Prisma
    pause
    exit /b 1
)
echo [OK] Client Prisma genere
echo.

:: Creer le dossier data
if not exist "data" mkdir data

:: Créer le fichier .env s'il n'existe pas
if not exist ".env" (
    echo [INFO] Creation du fichier .env...
    (
        echo # Configuration InteractLive - Version 100%% Locale
        echo DATABASE_URL="file:./data/interactlive.db"
        echo JWT_SECRET="interactlive-local-secret-key"
        echo PORT=3001
        echo APP_NAME="InteractLive"
    ) > .env
    echo [OK] Fichier .env cree
    echo.
)

:: Initialiser la base de donnees (version locale, PAS npx)
echo [INFO] Initialisation de la base de donnees SQLite...
call node_modules\.bin\prisma db push
if %ERRORLEVEL% NEQ 0 (
    echo [ERREUR] Echec de l'initialisation de la base de donnees
    pause
    exit /b 1
)
echo [OK] Base de donnees initialisee
echo.

echo ========================================
echo    Installation terminee avec succes!
echo ========================================
echo.
echo Pour demarrer l'application:
echo   1. Double-cliquez sur "start.bat"
echo   2. Ou executez: npm run dev
echo.
echo L'application sera accessible sur:
echo   http://localhost:3000
echo.
pause
