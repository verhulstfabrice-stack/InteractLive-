# 🚀 Déploiement v4 → v5

**Sprint 2** — Raccourcis clavier + mode plein écran.

## ✅ La plus simple des migrations

Cette fois, **pratiquement rien à faire** :

- ❌ Pas de modification de schéma DB
- ❌ Pas de nouvelle dépendance (pas de `npm install` bizarre)
- ❌ Pas de perte de session (le JWT_SECRET reste le même, tu restes connecté)
- ✅ Juste un rebuild de l'image Docker avec le nouveau code

**Durée totale : ~5 minutes.**

---

## Procédure

### 1. Transférer le zip v5 depuis ton PC

```powershell
scp C:\Users\verhu\Downloads\interactlive-docker-v5.zip debian@51.178.25.60:~/
```

### 2. Sur le VPS : stopper la v4, faire le ménage, installer la v5

```bash
# Arrêter la v4 proprement (les volumes restent, donc DB + certificats sauvés)
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
docker compose down

# Remonter d'un cran
cd ~/interactlive/interactlive-app

# Sauvegarder l'actuelle (par sécurité)
mv interactlive-docker-ready interactlive-docker-ready.v4.backup

# Dézipper la v5
unzip ~/interactlive-docker-v5.zip

# Récupérer le .env de la v4
cp interactlive-docker-ready.v4.backup/docker/.env interactlive-docker-ready/docker/.env
chmod 600 interactlive-docker-ready/docker/.env

# Vérifier qu'il a bien les bonnes valeurs (duckdns.org partout)
cat interactlive-docker-ready/docker/.env
```

### 3. Lancer le déploiement

```bash
cd interactlive-docker-ready/docker
bash ../deploy-docker-guide/scripts/02-deploy.sh interactlive.duckdns.org verhulst.fabrice@gmail.com
```

Le build sera rapide cette fois — ~2 min environ (les couches Docker sont en cache).

### 4. Vérifier

```bash
docker compose ps
# Les 3 conteneurs doivent être "Up"
```

---

## 🧪 Tests à faire

### Test 1 — Raccourcis clavier

1. Va sur https://interactlive.duckdns.org
2. Connecte-toi (si pas déjà fait)
3. Ouvre un événement existant et clique "Lancer la présentation"
4. Sur la page présentateur, appuie sur **`?`** (point d'interrogation, touche `Maj` + `,` sur Azerty)
5. Une fenêtre s'ouvre avec la liste des 7 raccourcis

### Test 2 — Navigation au clavier

Dans un événement **en cours de présentation** (statut "live"), avec au moins
2 questions :

- `Espace` → passe à la question suivante ✓
- `←` (flèche gauche) → revient à la précédente ✓
- `R` → bascule l'affichage des résultats ✓
- `V` → bascule votes ouverts/fermés ✓

### Test 3 — Mode plein écran

1. Dans la vue présentateur, appuie sur **`F`**
2. Effet attendu :
   - Le header disparaît (plus de "Retour", "QR Code", "Terminer")
   - Un mini-bandeau apparaît en haut à droite avec `👥 X` et `✕ Quitter`
   - Le contenu s'étend sur toute la largeur
   - Le navigateur passe en plein écran (comme F11)
3. Appuie sur **`Échap`** → retour à la vue normale
4. Appuie sur **`F`** → plein écran à nouveau
5. Clique sur le bouton **✕ Quitter** → retour à la vue normale

### Test 4 — Respect des champs de saisie

- Va dans l'éditeur d'un événement (`/event/X/edit`)
- Tape dans un champ (titre, description)
- Appuie sur les touches `R`, `V`, `F`, etc.
- Effet attendu : aucun raccourci ne se déclenche, tu tapes normalement

### Test 5 — Bouton ⌨️ dans le header

- Retourne sur la vue présentateur en mode normal
- Clique sur le bouton **⌨️** en haut à droite
- La même fenêtre d'aide qu'avec `?` s'ouvre

---

## 🎯 Cas d'usage recommandé en formation

**Configuration idéale :**
1. Connecter ton PC au vidéoprojecteur
2. Sur ton PC : ouvrir la vue présentateur
3. Activer le mode plein écran (`F`)
4. (Optionnel) : brancher une **télécommande de présentation** USB/Bluetooth
   (celles de PowerPoint fonctionnent : elles envoient `ArrowRight` / `ArrowLeft`)
5. Circuler dans la salle, piloter la session au clavier ou à la télécommande

**Les apprenants** voient uniquement la question et les résultats, sans aucune
interface technique — plus professionnel.

---

## 🔄 Rollback si besoin

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker
docker compose down
cd ~/interactlive/interactlive-app
rm -rf interactlive-docker-ready
mv interactlive-docker-ready.v4.backup interactlive-docker-ready
cd interactlive-docker-ready/docker
docker compose up -d
```

---

## Prochain sprint

Sprint 3 (v6) : **Questions à trous** (nouveau type de question). Durée estimée
de dev : 3-4h. Tu pourras créer des questions comme :

> La pédagogie de ____ postule que l'apprentissage se fait par l'action.

Le participant tape sa réponse dans un champ. Validation tolérante
(insensibilité à la casse/accents + liste de synonymes acceptés).
