# 🎯 InteractLive — Version Docker

Application de sondages en temps réel pour tes sessions de formation.
Prête à l'emploi : dézippe, lance le script, c'est parti.

---

## 🚀 Démarrage en 3 étapes

### Pré-requis
- **Docker Desktop** installé et **démarré** (icône baleine 🐳 active dans la barre des tâches)
  - Télécharger : https://www.docker.com/products/docker-desktop/

### Étape 1 — Ouvre PowerShell dans ce dossier

Dans l'Explorateur Windows :
1. Va dans le dossier `interactlive-docker-ready`
2. Fais un **clic droit** dans la zone vide
3. Choisis **"Ouvrir dans le Terminal"** ou **"Ouvrir PowerShell ici"**

### Étape 2 — Lance le script de démarrage

Dans PowerShell, tape :

```powershell
.\demarrer.ps1
```

Le script va :
- Détecter automatiquement l'IP locale de ton PC (exemple `192.168.1.42`)
- Configurer Docker en conséquence
- Démarrer l'application

Première fois : 3-5 minutes (build de l'image).
Fois suivantes : quelques secondes.

### Étape 3 — Accède à l'app

Quand tu vois :
```
🚀 InteractLive - Serveur démarré !
```

Ouvre ton navigateur sur :

| Qui | URL |
|---|---|
| **Toi (formateur)** sur ton PC | http://localhost:3001 |
| **Tes participants** sur leur téléphone | http://TON_IP:3001 |

L'URL exacte pour les participants est affichée par le script au démarrage (et dans le QR code de la vue présentateur).

---

## 📱 Pour que les participants puissent rejoindre

### 1. Les participants doivent être sur le MÊME WiFi que ton PC

Si tu veux l'utiliser hors d'un réseau partagé, il te faut la version **production** déployée sur un VPS (voir le dossier `deploy-docker-guide/`).

### 2. Autoriser le port 3001 dans le pare-feu Windows

**La première fois** que tu lances Docker, Windows te demande probablement "Voulez-vous autoriser ce programme à communiquer ?" → Clique **Autoriser** sur **Réseaux privés**.

Si tu as cliqué "Refuser" par erreur, voici comment corriger :

1. Menu Démarrer → tape `Pare-feu Windows Defender avec fonctions avancées de sécurité`
2. Clique sur **Règles de trafic entrant** (à gauche)
3. **Nouvelle règle** (à droite) → **Port** → Suivant
4. **TCP** → Ports locaux spécifiques : `3001` → Suivant
5. **Autoriser la connexion** → Suivant
6. Coche **Privé** (décoche Domaine et Public si tu es prudent) → Suivant
7. Nom : `InteractLive` → Terminer

### 3. Partager l'URL avec les participants

Au démarrage du script, tu vois :
```
Participants :  http://192.168.1.42:3001
```

Donne cette adresse à tes apprenants, ou fais-les scanner le QR code affiché dans la vue présentateur (l'URL est automatiquement bonne).

---

## 📋 Commandes utiles

Depuis le dossier du projet, dans PowerShell :

| Action | Commande |
|---|---|
| Démarrer (détection auto de l'IP) | `.\demarrer.ps1` |
| Démarrer en arrière-plan | `docker compose -f docker-compose.auto.yml up -d` |
| Voir les logs en direct | `docker compose logs -f` |
| Arrêter | `Ctrl+C` si script au premier plan, sinon `docker compose down` |
| Arrêter et effacer la DB | `docker compose down -v` ⚠️ perte des données |
| Rebuild complet après modif | `docker compose -f docker-compose.auto.yml up --build --force-recreate` |

---

## 🔐 Premier compte

Au premier login, le compte est créé automatiquement avec :
- Ton email
- Un **mot de passe d'au moins 8 caractères** (obligatoire)

Ce compte est administrateur du système.

---

## 🌐 Passer en production sur VPS

Pour mettre l'app en ligne publiquement (accessible hors WiFi local, avec HTTPS et un nom de domaine), voir le dossier `deploy-docker-guide/` qui contient :

- `GUIDE-DOCKER.md` : procédure complète pas-à-pas
- `scripts/` : scripts automatisés de setup VPS et déploiement

---

## ❓ Dépannage

### "L'exécution de scripts est désactivée sur ce système"
PowerShell bloque les scripts par défaut. Solution (une seule fois) :
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```
Tape `O` pour confirmer, puis relance `.\demarrer.ps1`.

### Les participants ont "ERR_CONNECTION_REFUSED" ou "Impossible de se connecter"
3 causes possibles, à vérifier dans l'ordre :
1. Ils ne sont pas sur le même WiFi que toi → vérifier
2. Le pare-feu Windows bloque → voir section "Pour que les participants puissent rejoindre" ci-dessus
3. L'URL est fausse → regarde dans le terminal après `.\demarrer.ps1`, tu verras la bonne URL

### L'IP détectée est mauvaise
Le script `demarrer.ps1` filtre les IP Docker/VPN/VM mais il arrive que ton PC ait plusieurs IP (ex. WiFi + Ethernet). Pour vérifier la bonne IP :
```powershell
ipconfig
```
Puis édite `docker-compose.yml` (pas `.auto.yml`) en mettant ton IP correcte dans `PUBLIC_URL` et `ALLOWED_ORIGINS`, et lance simplement :
```powershell
docker compose up --build
```
(Sans passer par le script.)

### Port 3001 déjà utilisé
Une autre app utilise déjà ce port. Deux options :
- Arrêter l'autre app
- Ou éditer `docker-compose.yml` / `docker-compose.auto.yml` en changeant `"3001:3001"` en `"3002:3001"` → accède via `http://localhost:3002`

### Docker Desktop ne démarre pas
- Vérifier que WSL 2 est activé : dans PowerShell admin, `wsl --install`
- Vérifier que la virtualisation est activée dans le BIOS (Intel VT-x / AMD-V)
- Redémarrer Windows après l'installation

### Remettre tout à zéro
```powershell
docker compose -f docker-compose.auto.yml down -v
docker image rm interactlive:local
.\demarrer.ps1
```

---

## 📁 Structure du projet

```
interactlive-docker-ready/
├── LISEZ-MOI.md                 ← tu es ici
├── demarrer.ps1                 ← script de démarrage (Windows)
├── docker-compose.yml           ← config Docker manuelle (IP à éditer)
├── docker-compose.auto.yml      ← config utilisée par demarrer.ps1
├── package.json                 ← projet InteractLive
├── client/                      ← code front
├── server/                      ← code back
├── prisma/                      ← schéma base de données
├── docker/                      ← Dockerfile + config prod (VPS)
│   ├── Dockerfile
│   ├── docker-compose.yml       ← version prod HTTPS
│   └── nginx/
└── deploy-docker-guide/         ← guide + scripts pour déploiement VPS
    ├── GUIDE-DOCKER.md
    └── scripts/
```

---

Bonne formation ! 🎓
