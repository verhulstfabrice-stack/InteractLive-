# ⌨️ v5 — Sprint 2 : Raccourcis clavier et mode plein écran

## Ce qui change

### 🎹 Raccourcis clavier du présentateur

Sur la page de présentation (`/presenter/:id`), les raccourcis suivants sont
maintenant actifs :

| Touche | Action |
|---|---|
| `Espace` ou `→` | Question suivante |
| `←` | Question précédente |
| `R` | Afficher / masquer les résultats |
| `V` | Ouvrir / fermer les votes |
| `F` | Basculer le mode présentation (plein écran) |
| `Échap` | Quitter le mode plein écran |
| `?` | Afficher la liste des raccourcis |

**Intelligence intégrée** : les raccourcis sont automatiquement **désactivés**
quand tu tapes dans un champ de texte (input, textarea, éditeur), pour ne pas
perturber la saisie.

### 🖥️ Mode présentation (plein écran)

Un nouveau bouton **🖥️** apparaît dans le header de la vue présentateur, ou tu
peux l'activer avec `F`.

**Effets du mode plein écran :**
- Le header complet disparaît (plus de bouton "Retour", "QR Code", etc.)
- Un **bandeau minimal** en haut à droite affiche le nombre de participants et
  un bouton **"✕ Quitter"**
- Le contenu principal s'étend sur **toute la largeur** de l'écran
- Le navigateur bascule aussi en **plein écran natif** (comme F11) si le
  navigateur le supporte
- Pour sortir : touche `Échap`, clic sur "✕ Quitter", ou touche `F` à nouveau

**Cas d'usage typique :** projeter ta session sur un vidéoprojecteur en salle.
Tu actives le mode plein écran, tu as un rendu 100% propre, aucun élément
parasite. Tu pilotes ensuite la session avec les raccourcis clavier (avec la
souris dans le fond de la salle, ou avec une télécommande Bluetooth style
PowerPoint).

### 💡 Bouton "⌨️" d'aide rapide

Dans le header de la vue présentateur, un nouveau bouton **⌨️** ouvre une
fenêtre avec la liste complète des raccourcis — pratique si tu oublies une
commande pendant une session.

---

## 🎯 Effets concrets pour toi

**Avant** (v4) :
> Pendant une présentation, tu devais cliquer sur "Question suivante" à la
> souris, ce qui :
> - fait apparaître le pointeur à l'écran (distraction pour les apprenants),
> - t'oblige à rester près du PC,
> - t'empêche de circuler dans la salle.

**Maintenant** (v5) :
> Tu actives le mode présentation avec `F`, et tu pilotes tout au clavier :
> `Espace` pour avancer, `R` pour révéler les résultats, `V` pour fermer les
> votes. Tu peux circuler librement dans la salle et revenir seulement à la
> fin pour terminer la session.
>
> Avec une télécommande de présentation (souvent autour de 20 €), la plupart
> des touches "suivant" envoient un `ArrowRight` — donc ça marche direct avec
> InteractLive.

---

## Aucune régression

- ✅ Tous les patches de sécurité v3 et v4 sont conservés
- ✅ Vue participant inchangée (aucun impact côté apprenants)
- ✅ Timer, réponses temps réel, scoreboard : identiques
- ✅ Pas de migration DB

## Impact technique

- **Pas de modif base de données** → rien à migrer
- **Pas de nouvelle dépendance npm** → build plus rapide
- **Pas d'impact sur les performances**
- Le conteneur Docker se rebuilde en ~1-2 min au lieu de 3-5 min

---

## Petits détails bonus

- **Modale QR Code** : reste ouvrable en plein écran (pour révéler le code
  après avoir commencé la présentation)
- **Plein écran et Échap** : si tu appuies sur Échap pendant le plein écran
  natif du navigateur, l'app détecte automatiquement la sortie et re-active
  le header sans rechargement
- **Bouton "?"** : si tu préfères `?` au bouton ⌨️, les deux mènent à la
  même fenêtre d'aide
