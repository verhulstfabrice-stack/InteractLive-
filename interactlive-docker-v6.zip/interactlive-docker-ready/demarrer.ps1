# =============================================================================
# InteractLive - Démarrage automatique (Windows PowerShell)
# =============================================================================
# Ce script :
#   1. Détecte automatiquement l'IP locale de ton PC sur ton WiFi
#   2. Lance Docker Compose avec cette IP configurée
#
# Utilisation : clic droit sur le fichier -> "Exécuter avec PowerShell"
# Ou dans PowerShell : .\demarrer.ps1
# =============================================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  InteractLive - Démarrage" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# -----------------------------------------------------------------------------
# 1. Détecter l'IP locale (WiFi / Ethernet, hors Docker/VPN/Hyper-V)
# -----------------------------------------------------------------------------
Write-Host "[1/3] Détection de l'IP locale..." -ForegroundColor Yellow

$ip = Get-NetIPAddress -AddressFamily IPv4 `
    | Where-Object {
        $_.IPAddress -notlike "127.*" -and
        $_.IPAddress -notlike "169.254.*" -and
        $_.PrefixOrigin -ne "WellKnown" -and
        $_.InterfaceAlias -notlike "*Loopback*" -and
        $_.InterfaceAlias -notlike "*Docker*" -and
        $_.InterfaceAlias -notlike "*vEthernet*" -and
        $_.InterfaceAlias -notlike "*VirtualBox*" -and
        $_.InterfaceAlias -notlike "*VMware*"
    } `
    | Select-Object -First 1 -ExpandProperty IPAddress

if (-not $ip) {
    Write-Host "❌ Impossible de détecter automatiquement une IP locale." -ForegroundColor Red
    Write-Host "   Fais manuellement : ipconfig" -ForegroundColor Yellow
    Write-Host "   Puis édite docker-compose.yml et remplace 192.168.1.42 par ton IP." -ForegroundColor Yellow
    Read-Host "Appuie sur Entrée pour quitter"
    exit 1
}

Write-Host "  IP détectée : $ip" -ForegroundColor Green
Write-Host ""

# -----------------------------------------------------------------------------
# 2. Exporter les variables d'environnement pour docker compose
# -----------------------------------------------------------------------------
Write-Host "[2/3] Configuration de Docker Compose..." -ForegroundColor Yellow

$env:INTERACTLIVE_IP = $ip
$env:PUBLIC_URL = "http://${ip}:3001"
$env:ALLOWED_ORIGINS = "http://localhost:3001,http://127.0.0.1:3001,http://${ip}:3001"

Write-Host "  PUBLIC_URL       = $env:PUBLIC_URL" -ForegroundColor Gray
Write-Host "  ALLOWED_ORIGINS  = $env:ALLOWED_ORIGINS" -ForegroundColor Gray
Write-Host ""

# -----------------------------------------------------------------------------
# 3. Lancer Docker Compose
# -----------------------------------------------------------------------------
Write-Host "[3/3] Lancement de Docker Compose..." -ForegroundColor Yellow
Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Accès à l'application :" -ForegroundColor Cyan
Write-Host "  - Sur ce PC    :  http://localhost:3001" -ForegroundColor White
Write-Host "  - Participants :  http://${ip}:3001" -ForegroundColor White
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "(Ctrl+C pour arrêter)" -ForegroundColor Gray
Write-Host ""

# On utilise docker-compose.auto.yml qui lit les variables d'environnement
docker compose -f docker-compose.auto.yml up --build
