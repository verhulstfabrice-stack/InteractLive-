# Guide Docker — Déploiement d'InteractLive

**Auteur :** préparé pour Fabrice Verhulst
**Cible :** VPS OVH Debian 13 avec Docker
**Durée estimée :** 45 min la première fois, 1-2 min pour les mises à jour suivantes

---

## Sommaire

1. [Ce que tu gagnes avec Docker](#1-ce-que-tu-gagnes-avec-docker)
2. [Architecture](#2-architecture)
3. [Ce que tu dois préparer](#3-ce-que-tu-dois-préparer)
4. [Étape 1 — Patcher le code](#4-étape-1--patcher-le-code)
5. [Étape 2 — Tester en local sur ton poste](#5-étape-2--tester-en-local-sur-ton-poste)
6. [Étape 3 — DNS](#6-étape-3--dns)
7. [Étape 4 — Setup du VPS](#7-étape-4--setup-du-vps)
8. [Étape 5 — Déploiement avec HTTPS](#8-étape-5--déploiement-avec-https)
9. [Étape 6 — Sauvegardes](#9-étape-6--sauvegardes)
10. [Maintenance](#10-maintenance)
11. [Dépannage](#11-dépannage)
12. [FAQ Docker](#12-faq-docker)

---

## 1. Ce que tu gagnes avec Docker

Par rapport à l'approche "systemd + Nginx sur la machine" :

| Aspect | Sans Docker | Avec Docker |
|---|---|---|
| Installer Node sur le VPS | Oui (version précise) | Non (Docker s'en occupe) |
| Tester en local ce qui ira en prod | Approximatif | À l'identique |
| Mettre à jour | Redéployer, rebuild, redémarrer | `docker compose up -d --build` |
| Rollback en cas de bug | Restaurer un backup + redéployer | Une commande |
| Dépendances système (OpenSSL, etc.) | À installer à la main | Incluses dans l'image |
| Un jour changer de VPS | Réinstaller, reconfigurer | Copier 2 dossiers, relancer |

**En contrepartie** : Docker utilise un peu plus de RAM (~100-200 Mo) et de disque (~500 Mo pour l'image). Sur un VPS OVH de base (2 Go RAM), c'est parfaitement gérable.

---

## 2. Architecture

```
                    Internet
                       ↓ HTTPS (443)
           ┌─────────────────────────────────┐
           │       VPS OVH Debian 13         │
           │                                 │
           │   ┌─────────────────────────┐   │
           │   │  docker-compose         │   │
           │   │                         │   │
           │   │  ┌────────┐  ┌──────┐   │   │
           │   │  │ nginx  │→ │ app  │   │   │
           │   │  │ (443)  │  │ 3001 │   │   │
           │   │  └────────┘  └──┬───┘   │   │
           │   │       ↑         ↓        │   │
           │   │  ┌────────┐ ┌───────┐   │   │
           │   │  │certbot │ │ data  │   │   │
           │   │  │        │ │volume │   │   │
           │   │  └────────┘ └───────┘   │   │
           │   └─────────────────────────┘   │
           └─────────────────────────────────┘
```

- **nginx** : reçoit HTTPS public → transfère à `app` via réseau Docker interne
- **app** (InteractLive) : l'appli Node.js, non exposée publiquement
- **certbot** : renouvelle le certificat HTTPS en arrière-plan toutes les 12h
- **volumes Docker** : `interactlive_data` (SQLite) + `interactlive_certs` (HTTPS)

---

## 3. Ce que tu dois préparer

### Sur ton poste
- **Docker Desktop** (Mac/Windows) ou **Docker Engine** (Linux) : https://docs.docker.com/get-docker/
- Un client SSH, une clé SSH (cf. guide sans Docker si besoin)

### Côté OVH
- VPS Debian 13 actif
- Domaine avec accès à la zone DNS

### À choisir
| Élément | Exemple | Ton choix |
|---|---|---|
| Sous-domaine | `interactlive.tondomaine.fr` | |
| Utilisateur Linux du VPS | `fabrice` | |
| Email Let's Encrypt | `toi@exemple.fr` | |

---

## 4. Étape 1 — Patcher le code

**Exactement les mêmes 5 patches que sans Docker** : Docker ne dispense pas des modifications de sécurité nécessaires.

Si tu as déjà appliqué les patches avec le kit précédent, tu peux passer directement à l'étape suivante.

Sinon, applique les patches du dossier `patches/` :
- `server/index.ts` (5 modifications pour production/CORS/HTTPS/mots de passe)
- `client/src/main.tsx`
- `client/src/hooks/useSocket.ts`
- `client/src/pages/PresenterView.tsx` (un bloc à remplacer)

Voir `patches/SERVER_PATCHES.md` pour le détail.

Le dossier `docker/` de ce kit doit être placé **à la racine de ton projet InteractLive** :

```
interactlive/
├── client/
├── server/
├── prisma/
├── package.json
├── docker/                 ← tout le contenu du dossier docker/ de ce kit
│   ├── Dockerfile
│   ├── .dockerignore
│   ├── docker-compose.yml
│   ├── docker-compose.dev.yml
│   ├── .env.example
│   └── nginx/
│       └── conf.d/
│           ├── interactlive-http-only.conf.template
│           └── interactlive.conf.template
└── scripts/                ← scripts de déploiement
    ├── 01-setup-vps.sh
    ├── 02-deploy.sh
    ├── 03-update.sh
    └── 04-backup.sh
```

---

## 5. Étape 2 — Tester en local sur ton poste

C'est le gros bénéfice de Docker : valider avant la prod.

Depuis la racine de ton projet :

```bash
cd docker
docker compose -f docker-compose.dev.yml up --build
```

Première fois : build de l'image (3-5 min). Ensuite, démarrage quasi instantané.

Quand tu vois :
```
interactlive-dev  | 🚀 InteractLive - Serveur démarré !
```

Ouvre : **http://localhost:3001**

Crée un compte, fais un test. Si ça marche ici, ça marchera sur le VPS.

Pour arrêter :
```bash
# Ctrl+C dans le terminal, puis :
docker compose -f docker-compose.dev.yml down
```

Pour tout supprimer (y compris la base SQLite de test) :
```bash
docker compose -f docker-compose.dev.yml down -v
```

---

## 6. Étape 3 — DNS

Chez OVH, dans la zone DNS de ton domaine :
- Ajouter un enregistrement **A**
- Sous-domaine : `interactlive` (ou celui de ton choix)
- Cible : IP IPv4 du VPS
- TTL : 3600

Vérifie depuis ton poste :
```bash
dig interactlive.tondomaine.fr +short
# doit retourner l'IP du VPS
```

**Ne passe à l'étape 5 qu'après propagation** (de 5 minutes à 2h).

---

## 7. Étape 4 — Setup du VPS

### 7.1 Première connexion

```bash
ssh root@IP_DU_VPS
```

### 7.2 Transfert du script de setup

Depuis ton poste :
```bash
scp scripts/01-setup-vps.sh root@IP_DU_VPS:/root/
```

### 7.3 Personnalisation

Sur le VPS :
```bash
nano /root/01-setup-vps.sh
```

Change `APP_USER="fabrice"` si tu veux un autre nom. Colle ta clé SSH publique dans `APP_USER_SSH_KEY` (optionnel mais recommandé).

### 7.4 Exécution

```bash
bash /root/01-setup-vps.sh
```

Le script installe :
- Docker + Docker Compose plugin (depuis le dépôt officiel Docker)
- UFW (pare-feu, ports 22/80/443 ouverts)
- fail2ban
- Crée l'utilisateur `fabrice`, l'ajoute aux groupes `sudo` et `docker`

Durée : 3-5 minutes.

### 7.5 Définir un mot de passe

```bash
passwd fabrice
```

### 7.6 Durcir SSH

Teste d'abord depuis un **autre terminal** que tu peux te connecter en tant que `fabrice` :
```bash
ssh fabrice@IP_DU_VPS
```

Si OK, dans la session root :
```bash
nano /etc/ssh/sshd_config
```

Mets :
```
PermitRootLogin no
PasswordAuthentication no
```

Puis :
```bash
systemctl restart ssh
```

---

## 8. Étape 5 — Déploiement avec HTTPS

### 8.1 Transfert du code sur le VPS

Depuis ton poste, dans le dossier parent de ton projet :

```bash
# Préparer un zip propre
cd /chemin/vers/projet-parent
rm -rf interactlive/node_modules interactlive/dist interactlive/data
zip -r interactlive.zip interactlive -x "interactlive/.git/*"

# Transfert
scp interactlive.zip fabrice@IP_DU_VPS:~/
```

### 8.2 Extraction sur le VPS

```bash
ssh fabrice@IP_DU_VPS
mkdir -p ~/apps
cd ~/apps
unzip ~/interactlive.zip
cd interactlive
```

### 8.3 Fichier .env de production

```bash
cd docker
cp .env.example .env
nano .env
```

Contenu minimal à remplir :
```env
JWT_SECRET=<résultat de: openssl rand -hex 48>
ALLOWED_ORIGINS=https://interactlive.tondomaine.fr
PUBLIC_URL=https://interactlive.tondomaine.fr
```

Pour générer le secret, dans un terminal :
```bash
openssl rand -hex 48
```

Puis :
```bash
chmod 600 .env
```

### 8.4 Déploiement + obtention HTTPS

```bash
bash ../scripts/02-deploy.sh interactlive.tondomaine.fr toi@exemple.fr
```

Le script fait **tout automatiquement** :
1. Prépare les configs Nginx pour TON domaine
2. Build l'image Docker de l'app (3-5 min la première fois)
3. Démarre l'app + Nginx en HTTP
4. Vérifie que le DNS pointe bien ici
5. Lance Certbot pour obtenir le certificat HTTPS
6. Bascule Nginx en mode HTTPS
7. Démarre le conteneur certbot pour les renouvellements

À la fin : **https://interactlive.tondomaine.fr** est accessible.

---

## 9. Étape 6 — Sauvegardes

### 9.1 Transfert du script

Depuis ton poste :
```bash
scp scripts/04-backup.sh fabrice@IP_DU_VPS:~/apps/interactlive/docker/
```

Sur le VPS :
```bash
chmod +x ~/apps/interactlive/docker/04-backup.sh
```

### 9.2 Test

```bash
cd ~/apps/interactlive/docker
bash 04-backup.sh
ls -lh ~/backups/interactlive/
```

### 9.3 Cron quotidien

```bash
crontab -e
```

Ajoute :
```cron
0 3 * * * cd /home/fabrice/apps/interactlive/docker && /home/fabrice/apps/interactlive/docker/04-backup.sh >> /home/fabrice/backup.log 2>&1
```

---

## 10. Maintenance

### Commandes Docker essentielles

Toutes à lancer depuis `~/apps/interactlive/docker/`.

```bash
# État des conteneurs
docker compose ps

# Logs en direct (tous les services)
docker compose logs -f

# Logs d'un seul service
docker compose logs -f interactlive
docker compose logs -f nginx

# Redémarrer un service
docker compose restart interactlive

# Tout arrêter (sans supprimer les données)
docker compose down

# Tout démarrer
docker compose up -d

# Redémarrer tout après modif d'un fichier de conf
docker compose up -d --force-recreate
```

### Déployer une nouvelle version

**Si tu utilises Git :**
```bash
cd ~/apps/interactlive/docker
bash ../scripts/03-update.sh
```

**Si tu uploades un zip manuellement :**

Depuis ton poste :
```bash
scp interactlive-nouvelle-version.zip fabrice@IP_DU_VPS:~/
```

Sur le VPS :
```bash
cd ~/apps
docker compose -f interactlive/docker/docker-compose.yml down
# Backup du .env et du dossier docker/ avant remplacement
cp interactlive/docker/.env /tmp/interactlive-env-backup
cp -r interactlive/docker /tmp/interactlive-docker-backup

mv interactlive interactlive.old.$(date +%F-%H%M)
unzip ~/interactlive-nouvelle-version.zip
# Remet les fichiers de config Docker en place
cp -r /tmp/interactlive-docker-backup/* interactlive/docker/
cp /tmp/interactlive-env-backup interactlive/docker/.env

cd interactlive/docker
docker compose up -d --build
```

Les volumes (données SQLite, certificats HTTPS) sont **préservés** entre les déploiements. Tu ne perds rien.

### Restaurer un backup

```bash
cd ~/apps/interactlive/docker
docker compose stop interactlive

# Décompresse le backup voulu
gunzip -k ~/backups/interactlive/interactlive-2026-04-18_03-00.db.gz

# Copie dans le volume Docker
docker run --rm \
  -v interactlive_data:/data \
  -v ~/backups/interactlive:/backup \
  alpine cp /backup/interactlive-2026-04-18_03-00.db /data/interactlive.db

docker compose start interactlive
```

### Renouvellement HTTPS

Automatique. Le conteneur `certbot` tente un renouvellement toutes les 12h. Nginx recharge sa config toutes les 6h pour prendre en compte les nouveaux certificats.

Pour vérifier :
```bash
docker compose logs certbot | tail -20
docker compose exec nginx nginx -t
```

Pour forcer un renouvellement (test) :
```bash
docker compose run --rm certbot certbot renew --dry-run
```

### Nettoyer les vieilles images Docker

Au fil des mises à jour, les anciennes versions d'images prennent de la place :
```bash
docker image prune -a
```

---

## 11. Dépannage

### Le conteneur `interactlive` redémarre en boucle
```bash
docker compose logs interactlive --tail=50
```
Causes fréquentes :
- `.env` mal rempli (variable manquante → erreur au démarrage)
- Base SQLite corrompue (restaurer un backup)
- Conflit de port avec autre chose sur la machine (peu probable vu que l'app n'expose pas de port à l'hôte)

### Certbot échoue à obtenir le certificat
Vérifie que le DNS pointe bien vers le bon serveur :
```bash
dig interactlive.tondomaine.fr +short
curl -s https://api.ipify.org   # IP publique du VPS
```
Les deux doivent être identiques.

Si Let's Encrypt a eu un échec récent, tu peux être rate-limité. Attends 1h ou utilise le staging (test) :
```bash
docker compose run --rm --entrypoint "" certbot \
    certbot certonly --webroot -w /var/www/certbot \
    --staging \
    --email toi@exemple.fr --agree-tos \
    -d interactlive.tondomaine.fr
```

### WebSocket ne se connecte pas (graphiques figés)
La config Nginx contient déjà les directives nécessaires (`Upgrade`, `Connection`). Vérifie dans la console du navigateur (F12 > Réseau > WS) qu'une connexion s'établit bien.

### Erreur "Origine non autorisée"
`ALLOWED_ORIGINS` dans `.env` ne correspond pas à l'URL que le navigateur utilise.
- Pas de `/` final
- Bon protocole (https, pas http)
- Exactement le bon sous-domaine

Après modif de `.env` :
```bash
docker compose up -d --force-recreate interactlive
```

### Je veux tout réinitialiser
```bash
cd ~/apps/interactlive/docker
docker compose down -v         # ⚠ supprime les volumes (DB et certs) !
docker image rm interactlive:latest
# Puis relancer 02-deploy.sh
```

---

## 12. FAQ Docker

**Je dois apprendre Docker avant ?**
Non, pas vraiment. Les 5-6 commandes du tableau "Maintenance" couvrent 99% des besoins.

**Ça consomme beaucoup plus de RAM ?**
Environ 150-250 Mo en plus pour les conteneurs (nginx + certbot). Sur un VPS 2 Go, c'est inexistant.

**Et si je veux revenir à l'ancienne version (sans Docker) ?**
Tes données sont dans le volume `interactlive_data`. Tu peux les exporter :
```bash
docker run --rm -v interactlive_data:/data -v $(pwd):/out alpine \
    cp /data/interactlive.db /out/interactlive.db
```
Puis les réimporter dans une installation classique.

**Je peux avoir plusieurs instances sur le même VPS ?**
Oui, mais chacune doit utiliser un sous-domaine distinct et un `docker-compose.yml` avec des noms de volumes/conteneurs différents (préfixe ou suffixe). Pour tes besoins actuels c'est inutile, une seule instance suffit.

**Les logs sont gardés combien de temps ?**
Par défaut, tout est gardé tant que le conteneur existe. Pour éviter que ça grossisse trop, ajoute ces lignes à chaque service dans `docker-compose.yml` :
```yaml
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

---

## Récapitulatif des fichiers de ce kit

```
deploy-docker/
├── GUIDE-DOCKER.md              # Ce document
├── README.md                    # Quick start
│
├── docker/                      # À placer à la racine du projet InteractLive
│   ├── Dockerfile               # Image multi-stage (builder + runner)
│   ├── .dockerignore
│   ├── docker-compose.yml       # Stack de production (app + nginx + certbot)
│   ├── docker-compose.dev.yml   # Pour tester en local
│   ├── .env.example             # Modèle de variables d'environnement
│   └── nginx/
│       └── conf.d/
│           ├── interactlive-http-only.conf.template    # Avant HTTPS
│           └── interactlive.conf.template              # Avec HTTPS
│
└── scripts/                     # Scripts de déploiement
    ├── 01-setup-vps.sh          # Installe Docker + UFW + fail2ban (root, 1 fois)
    ├── 02-deploy.sh             # Premier déploiement + HTTPS (1 fois)
    ├── 03-update.sh             # Redéploiement rapide après modif
    └── 04-backup.sh             # Sauvegarde SQLite (cron)
```

---

Quand tu es prêt, commence par l'étape 5 (test local) : c'est le meilleur moyen de valider que tout marche avant de toucher au VPS. Si un bloc te résiste, donne-moi la commande exacte + le message d'erreur.
