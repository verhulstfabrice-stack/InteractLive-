#!/usr/bin/env bash
# =============================================================================
# InteractLive Docker - 02-deploy.sh
# =============================================================================
# Premier déploiement : build de l'image + obtention du certificat HTTPS +
# lancement de la stack complète.
#
# Prérequis :
#   - Docker installé (script 01 exécuté)
#   - DNS pointant vers l'IP du VPS
#   - Fichier .env rempli (à côté de docker-compose.yml)
#   - Code de l'app présent dans le dossier parent
#
# Usage :
#   cd ~/apps/interactlive/docker
#   bash 02-deploy.sh interactlive.tondomaine.fr toi@exemple.fr
# =============================================================================

set -euo pipefail

# Arguments
DOMAIN="${1:-}"
EMAIL="${2:-}"

if [[ -z "$DOMAIN" || -z "$EMAIL" ]]; then
  echo "Usage : $0 <domaine> <email>"
  echo "Ex.   : $0 interactlive.tondomaine.fr toi@exemple.fr"
  exit 1
fi

# Vérifications
if [[ ! -f ".env" ]]; then
  echo "❌ .env absent. Copie .env.example -> .env et remplis-le."
  exit 1
fi

if [[ ! -f "docker-compose.yml" ]]; then
  echo "❌ docker-compose.yml absent. Lance ce script depuis le dossier docker/."
  exit 1
fi

echo ""
echo "========================================================"
echo "  Déploiement InteractLive avec Docker + HTTPS"
echo "========================================================"
echo "  Domaine : $DOMAIN"
echo "  Email   : $EMAIL"
echo ""

chmod 600 .env

# -------------------------------------------------------------------
# 1. Préparation des configs Nginx (substitution du domaine)
# -------------------------------------------------------------------
echo "[1/5] Préparation des configs Nginx..."
mkdir -p nginx/conf.d

# Config HTTP-only pour la validation initiale Let's Encrypt
sed "s/DOMAIN_PLACEHOLDER/$DOMAIN/g" \
    nginx/conf.d/interactlive-http-only.conf.template \
    > nginx/conf.d/interactlive.conf

# On supprime l'éventuelle conf HTTPS restante pour démarrer en HTTP
rm -f nginx/conf.d/interactlive-https.conf

# -------------------------------------------------------------------
# 2. Build de l'image InteractLive
# -------------------------------------------------------------------
echo "[2/5] Build de l'image Docker InteractLive..."
docker compose build interactlive

# -------------------------------------------------------------------
# 3. Démarrage de l'app + Nginx en mode HTTP
# -------------------------------------------------------------------
echo "[3/5] Démarrage de l'app et Nginx (HTTP seulement)..."
docker compose up -d interactlive nginx

# Attend que Nginx soit prêt
sleep 5

# -------------------------------------------------------------------
# 4. Obtention du certificat HTTPS via Certbot (mode webroot)
# -------------------------------------------------------------------
echo "[4/5] Obtention du certificat HTTPS..."

# Test : le domaine résout-il bien vers ce serveur ?
SERVER_IP=$(curl -s https://api.ipify.org || echo "")
DOMAIN_IP=$(getent hosts "$DOMAIN" | awk '{print $1}' | head -1 || echo "")

if [[ -n "$SERVER_IP" && -n "$DOMAIN_IP" && "$SERVER_IP" != "$DOMAIN_IP" ]]; then
  echo ""
  echo "⚠  ATTENTION : le domaine $DOMAIN résout vers $DOMAIN_IP"
  echo "   mais ce serveur a l'IP $SERVER_IP."
  echo "   Vérifie ton DNS ou attends la propagation avant de continuer."
  echo ""
  read -p "Continuer quand même ? (o/N) " -n 1 -r
  echo ""
  [[ ! $REPLY =~ ^[OoYy]$ ]] && exit 1
fi

docker compose run --rm --entrypoint "" certbot \
    certbot certonly \
        --webroot -w /var/www/certbot \
        --email "$EMAIL" \
        --agree-tos \
        --no-eff-email \
        --non-interactive \
        -d "$DOMAIN"

# -------------------------------------------------------------------
# 5. Bascule sur la config HTTPS complète
# -------------------------------------------------------------------
echo "[5/5] Activation de la config HTTPS..."

sed "s/DOMAIN_PLACEHOLDER/$DOMAIN/g" \
    nginx/conf.d/interactlive.conf.template \
    > nginx/conf.d/interactlive.conf

# Redémarre Nginx pour prendre en compte la nouvelle config
docker compose restart nginx

# Démarre certbot pour les renouvellements automatiques
docker compose up -d

sleep 3

echo ""
echo "========================================================"
echo "  ✅  Déploiement terminé"
echo "========================================================"
echo ""
echo "  ▶  Ton app est accessible sur : https://$DOMAIN"
echo ""
echo "Commandes utiles :"
echo "  docker compose ps                  # État des conteneurs"
echo "  docker compose logs -f              # Logs en direct"
echo "  docker compose logs -f interactlive # Logs de l'app uniquement"
echo "  docker compose restart              # Redémarrage"
echo "  docker compose down                 # Arrêt"
echo "  docker compose up -d                # Démarrage"
echo ""
