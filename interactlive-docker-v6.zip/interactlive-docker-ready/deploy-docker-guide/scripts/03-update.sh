#!/usr/bin/env bash
# =============================================================================
# InteractLive Docker - 03-update.sh
# =============================================================================
# Rebuild de l'image et redémarrage après modification du code.
# La base de données et les certificats HTTPS sont préservés (volumes).
#
# Usage :
#   cd ~/apps/interactlive/docker
#   bash 03-update.sh
# =============================================================================

set -euo pipefail

if [[ ! -f "docker-compose.yml" ]]; then
  echo "❌ Lance ce script depuis le dossier docker/."
  exit 1
fi

echo ""
echo "========================================================"
echo "  Mise à jour InteractLive (rebuild + restart)"
echo "========================================================"
echo ""

# 1. Backup DB avant tout
echo "[1/4] Backup préventif de la base de données..."
mkdir -p ../backups
BACKUP_FILE="../backups/pre-update-$(date +%Y-%m-%d_%H-%M).db"
docker compose exec -T interactlive \
    sqlite3 /data/interactlive.db ".backup /tmp/backup.db" || \
    docker cp interactlive:/data/interactlive.db "$BACKUP_FILE" 2>/dev/null || \
    echo "  (Pas de backup, peut-être premier démarrage.)"

# 2. Git pull si repo
if [[ -d ../.git ]]; then
  echo "[2/4] git pull..."
  (cd .. && git pull --ff-only)
else
  echo "[2/4] Pas de repo Git (code déjà à jour)."
fi

# 3. Rebuild de l'image
echo "[3/4] Rebuild de l'image..."
docker compose build interactlive

# 4. Redémarrage
echo "[4/4] Redémarrage du conteneur..."
docker compose up -d interactlive
sleep 3

docker compose ps

echo ""
echo "========================================================"
echo "  ✅  Mise à jour terminée"
echo "========================================================"
echo ""
echo "Logs : docker compose logs -f interactlive"
echo ""
