#!/usr/bin/env bash
# =============================================================================
# InteractLive Docker - 04-backup.sh
# =============================================================================
# Sauvegarde la base SQLite depuis le volume Docker.
# À planifier dans cron :
#   crontab -e
#   0 3 * * * /home/fabrice/apps/interactlive/docker/04-backup.sh >> /home/fabrice/backup.log 2>&1
# =============================================================================

set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-/home/fabrice/backups/interactlive}"
RETENTION_DAYS=30

mkdir -p "$BACKUP_DIR"

DATE=$(date +%Y-%m-%d_%H-%M)
BACKUP_FILE="$BACKUP_DIR/interactlive-$DATE.db"

# Utilise .backup de sqlite3 depuis l'intérieur du conteneur
# (cohérent même pendant écriture)
docker compose exec -T interactlive \
    sh -c "sqlite3 /data/interactlive.db '.backup /tmp/backup.db' && cat /tmp/backup.db" \
    > "$BACKUP_FILE"

gzip -9 "$BACKUP_FILE"

echo "[$(date -Iseconds)] Backup OK : ${BACKUP_FILE}.gz ($(du -h "${BACKUP_FILE}.gz" | cut -f1))"

# Rotation
find "$BACKUP_DIR" -name "interactlive-*.db.gz" -type f -mtime +$RETENTION_DAYS -delete

echo "[$(date -Iseconds)] $(ls "$BACKUP_DIR" | wc -l) sauvegardes conservées."
