#!/usr/bin/env bash
# =============================================================================
# InteractLive Docker - 01-setup-vps.sh
# =============================================================================
# Installe Docker + Docker Compose + durcissement minimal sur Debian 13.
# À exécuter UNE FOIS en root sur un VPS vierge.
#
# Usage :
#   ssh root@TON_VPS
#   bash 01-setup-vps.sh
# =============================================================================

set -euo pipefail

APP_USER="fabrice"            # À personnaliser
APP_USER_SSH_KEY=""           # Optionnel : ta clé SSH publique

if [[ $EUID -ne 0 ]]; then
  echo "Lance-moi en root : sudo bash $0"
  exit 1
fi

echo ""
echo "========================================================"
echo "  Setup VPS Debian 13 pour Docker"
echo "========================================================"
echo ""

# -------------------------------------------------------------------
# 1. Système à jour
# -------------------------------------------------------------------
echo "[1/5] Mise à jour du système..."
apt update
DEBIAN_FRONTEND=noninteractive apt upgrade -y

# -------------------------------------------------------------------
# 2. Paquets de base + Docker (depuis le dépôt officiel)
# -------------------------------------------------------------------
echo "[2/5] Installation de Docker..."
apt install -y ca-certificates curl gnupg ufw fail2ban

install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/debian $(. /etc/os-release; echo "$VERSION_CODENAME") stable" \
    > /etc/apt/sources.list.d/docker.list

apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

systemctl enable --now docker

# -------------------------------------------------------------------
# 3. Utilisateur applicatif (peut lancer Docker sans sudo)
# -------------------------------------------------------------------
echo "[3/5] Utilisateur $APP_USER..."
if ! id "$APP_USER" &>/dev/null; then
  adduser --disabled-password --gecos "" "$APP_USER"
  usermod -aG sudo "$APP_USER"
fi
usermod -aG docker "$APP_USER"

if [[ -n "$APP_USER_SSH_KEY" ]]; then
  mkdir -p "/home/$APP_USER/.ssh"
  echo "$APP_USER_SSH_KEY" >> "/home/$APP_USER/.ssh/authorized_keys"
  chmod 700 "/home/$APP_USER/.ssh"
  chmod 600 "/home/$APP_USER/.ssh/authorized_keys"
  chown -R "$APP_USER:$APP_USER" "/home/$APP_USER/.ssh"
fi

# -------------------------------------------------------------------
# 4. Pare-feu UFW
# -------------------------------------------------------------------
echo "[4/5] Configuration du pare-feu UFW..."
ufw --force reset >/dev/null
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'SSH'
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'
ufw --force enable
ufw status verbose

# -------------------------------------------------------------------
# 5. Fail2ban
# -------------------------------------------------------------------
echo "[5/5] Activation de fail2ban..."
systemctl enable --now fail2ban

echo ""
echo "========================================================"
echo "  ✅  Setup VPS terminé"
echo "========================================================"
echo ""
echo "Versions installées :"
docker --version
docker compose version
echo ""
echo "Prochaines étapes :"
echo "  1. passwd $APP_USER        (définir un mot de passe)"
echo "  2. Durcir /etc/ssh/sshd_config : PermitRootLogin no, PasswordAuthentication no"
echo "  3. systemctl restart ssh"
echo "  4. Se reconnecter en tant que $APP_USER et lancer 02-deploy.sh"
echo ""
