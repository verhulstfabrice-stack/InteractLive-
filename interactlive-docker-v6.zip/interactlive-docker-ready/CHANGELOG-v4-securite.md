# 🔒 v4 — Sprint 1.5 : Sécurité renforcée

## Ce qui change

### 🔴 Corrections de failles CRITIQUES

#### 1. Socket.io : authentification + ownership
Auparavant, n'importe qui connaissant le code à 6 caractères d'un événement
pouvait se connecter en tant que "présentateur" via Socket.io et déclencher
`START_EVENT`, `NEXT_QUESTION`, `END_EVENT`, etc.

Désormais :
- Un middleware `io.use()` lit le cookie JWT à chaque connexion Socket.io
- Les infos utilisateur (id, rôle, email) sont attachées à `socket.data`
- **Tous les événements présentateur** (`PRESENTER_JOIN`, `START_EVENT`,
  `NEXT_QUESTION`, `PREVIOUS_QUESTION`, `TOGGLE_RESULTS`, `TOGGLE_VOTING`,
  `START_TIMER`, `STOP_TIMER`, `END_EVENT`) vérifient maintenant que
  l'utilisateur est **propriétaire de l'événement** (ou admin)
- En cas d'accès refusé sur une action critique, le socket est **déconnecté
  immédiatement** + message `UNAUTHORIZED` envoyé au client
- Les participants anonymes (sans JWT) peuvent toujours rejoindre un événement
  comme avant — aucun impact sur l'usage normal

#### 2. Rate limiting sur `auth.login`
Auparavant, la route de connexion acceptait un nombre illimité de tentatives →
bruteforce possible sur les mots de passe.

Désormais :
- **5 tentatives d'échec maximum** par IP dans une fenêtre de 15 minutes
- Au 5ème échec : **blocage 15 minutes** sur cette IP
- Un succès réinitialise le compteur (UX normale)
- Les erreurs "compte en attente de validation" ne comptent pas comme des
  tentatives d'intrusion (pas de double peine pour l'utilisateur légitime)
- Message clair à l'utilisateur : « Trop de tentatives, réessayez dans X minutes »

### 🟡 Corrections MOYENNES

#### 3. Helmet + Content-Security-Policy
Ajout de la librairie `helmet` qui pose des en-têtes HTTP de sécurité :
- **CSP** stricte adaptée à InteractLive (fonts Google autorisées, `'self'` sinon)
- `X-Content-Type-Options: nosniff`
- `X-DNS-Prefetch-Control`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Cross-Origin-Resource-Policy`

#### 4. JWT avec `jti` et révocation
Auparavant, un token JWT de 7 jours ne pouvait pas être invalidé avant son
expiration naturelle. Si un compte était bloqué ou si un token était volé,
il restait valide pendant une semaine.

Désormais :
- Chaque token a un identifiant unique `jti` (généré aléatoirement à la connexion)
- Nouvelle table `RevokedToken` en base pour tracer les tokens invalidés
- La déconnexion (`logout`) révoque réellement le token en base
- Le blocage d'un utilisateur depuis la page admin invalide immédiatement ses
  sessions actives (WebSocket + prochaine requête HTTP)
- Nettoyage automatique toutes les heures des tokens expirés

### 🎯 Effets concrets pour toi

**En tant qu'admin**, tu peux maintenant bloquer un utilisateur en toute
confiance : il sera éjecté dans la seconde, plus besoin d'attendre 7 jours.

**En tant qu'utilisateur**, si tu te déconnectes volontairement, ton token
est vraiment détruit — impossible pour quelqu'un d'intercepter ton cookie
et de l'utiliser après.

**En tant que formateur**, tu peux désormais partager le code à 6 caractères
d'un événement sans risque : seul toi (ou un autre admin) pouvez contrôler
la progression du quiz. Même quelqu'un qui devinerait le code ne pourrait
ni démarrer, ni avancer, ni arrêter l'événement.

---

## Nouvelles dépendances

- `helmet@^8.0.0` (côté serveur)

## Migration de la base de données

Une nouvelle table `RevokedToken` est créée automatiquement au premier démarrage
(`prisma db push` dans le Dockerfile). **Aucune action manuelle requise.**

## Aucune régression

- ✅ Tous les patches de sécurité v3 sont conservés
- ✅ Système de rôles admin/user intact
- ✅ Validation des comptes `pending` intacte
- ✅ Participants anonymes (sans compte) peuvent toujours rejoindre
- ✅ Les tokens existants sont invalidés automatiquement à la migration (reconnexion
  simple requise — pas de perte de données)

## Impact utilisateur visible

Au premier déploiement de la v4 :
1. Tu devras te **reconnecter une fois** (tes anciens tokens n'ont pas de `jti`)
2. Après ça, tout fonctionne comme avant, en plus sûr

---

## Limites connues / à travailler plus tard

- **Refactoring serveur monolithique** : `server/index.ts` fait maintenant ~1900 lignes.
  À découper en modules (`auth.ts`, `sockets.ts`, `admin.ts`...) dans un futur sprint dédié.
- **Persistance de l'état des sessions live** : toujours en mémoire. Un redémarrage
  du conteneur pendant une session perd la progression en cours.
- **Tests automatisés** : toujours absents. À planifier.
