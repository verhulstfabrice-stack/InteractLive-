# 🚀 Guide de mise à jour v2 → v3 (Sprint 1)

## ⚠️ Lis bien ceci avant de déployer

Le schéma de la base de données change (ajout du champ `status` sur les utilisateurs).
**Conséquence** : tous les comptes existants vont se retrouver avec `status = pending`
par défaut. **Y COMPRIS TON PROPRE COMPTE D'ADMIN.**

Si tu déploies sans action complémentaire, **tu seras bloqué à ta propre connexion**.

**Deux solutions** (choisis celle qui t'arrange) :

---

## ✅ SOLUTION A — La plus propre (recommandée)

Supprimer l'ancien compte et le recréer après le déploiement. **Le premier compte créé sur la v3 deviendra automatiquement admin approuvé.**

⚠️ **Seulement valable si** : tu n'as pas encore créé d'événements importants
que tu veux garder. (Ce qui est probablement ton cas actuel — tu viens juste
d'installer.)

**Étapes** :

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker

# 1. Arrêter et supprimer TOUTES les données (attention : irréversible)
docker compose down -v

# 2. Supprimer l'ancien dossier et les backups
cd ~/interactlive/interactlive-app
rm -rf interactlive-docker-ready

# 3. Transférer et dézipper la v3 (voir plus bas)
unzip ~/interactlive-docker-v3.zip
mv interactlive-docker-ready-v3 interactlive-docker-ready  # si le nom du dossier est différent

# 4. Recréer le .env avec tes valeurs
cd interactlive-docker-ready/docker
cp .env.example .env
nano .env
# Remplis JWT_SECRET (nouveau ou le même qu'avant), ALLOWED_ORIGINS, PUBLIC_URL
chmod 600 .env

# 5. Redéployer
bash ../deploy-docker-guide/scripts/02-deploy.sh interactlive.duckdns.org verhulst.fabrice@gmail.com

# 6. Aller sur https://interactlive.duckdns.org et te recréer ton compte
# Premier compte = admin approuvé automatiquement
```

**Durée totale** : ~10-15 min.

---

## ✅ SOLUTION B — Migration sans perte de données

Si tu as déjà des événements que tu veux garder, il faut **basculer manuellement
ton compte à `status = approved`** après la migration.

**Étapes** :

```bash
cd ~/interactlive/interactlive-app/interactlive-docker-ready/docker

# 1. Faire un backup de sécurité
docker compose exec interactlive sqlite3 /data/interactlive.db ".backup /data/backup-avant-v3.db"

# 2. Arrêter (sans -v, on GARDE les volumes donc la DB)
docker compose down

# 3. Remonter d'un cran
cd ~/interactlive/interactlive-app

# 4. Sauvegarder l'ancien dossier
mv interactlive-docker-ready interactlive-docker-ready.v2.backup

# 5. Transférer le zip v3 depuis ton PC (scp ou filezilla) puis dézipper
unzip ~/interactlive-docker-v3.zip

# 6. Récupérer le .env
cp interactlive-docker-ready.v2.backup/docker/.env interactlive-docker-ready/docker/.env

# 7. Relancer (la DB existe toujours dans le volume, le schéma sera mis à jour
#    automatiquement au démarrage via `prisma db push`)
cd interactlive-docker-ready/docker
bash ../deploy-docker-guide/scripts/02-deploy.sh interactlive.duckdns.org verhulst.fabrice@gmail.com
```

**Puis** — étape cruciale — passer ton compte admin en `approved` :

```bash
# Accès direct à la DB SQLite via le conteneur
docker compose exec interactlive sqlite3 /data/interactlive.db

# Dans le prompt SQLite :
UPDATE User SET status = 'approved', role = 'admin' WHERE email = 'verhulst.fabrice@gmail.com';
.quit
```

Tu peux aussi en profiter pour approuver d'autres comptes si tu en avais déjà.
Pour voir qui est en base :

```bash
docker compose exec interactlive sqlite3 /data/interactlive.db "SELECT id, email, role, status FROM User;"
```

---

## 🎯 Après le déploiement (les deux solutions)

1. Va sur **https://interactlive.duckdns.org**
2. Connecte-toi avec `verhulst.fabrice@gmail.com` + ton mot de passe
3. Tu arrives sur le dashboard avec un nouveau bouton **"👥 Utilisateurs"** en haut à droite
4. Clique dessus pour voir la page d'administration

## 🧪 Test que tout fonctionne

**Test 1 — Nouveau compte** :

1. Ouvre un navigateur en **mode privé** (ou un autre navigateur)
2. Va sur https://interactlive.duckdns.org/login
3. Entre un email différent, crée un mot de passe
4. Tu dois voir le message **"⏳ Compte en attente de validation"** en orange

**Test 2 — Approbation** :

1. Reviens sur ta session admin principale
2. Page Utilisateurs : tu vois le nouveau compte en statut `pending`
3. Clique "✓ Approuver"
4. Dans l'autre navigateur, reconnecte-toi avec cet email → ça doit marcher

**Test 3 — Blocage** :

1. Sur la page admin, bloque le compte de test
2. Dans l'autre navigateur, déconnecte-toi et reconnecte-toi
3. Tu dois voir "⛔ Compte bloqué"

Si tout ça marche, le Sprint 1 est validé. 🎉

---

## 🔄 Rollback en cas de problème

Si quelque chose ne va pas et que tu veux revenir à la v2 :

**Solution A** : tu as forcément perdu les données, pas de rollback possible.
À toi de ne pas avoir choisi A si tu avais des données importantes.

**Solution B** (rollback possible) :
```bash
cd ~/interactlive/interactlive-app
# Arrêter la v3
cd interactlive-docker-ready/docker && docker compose down && cd ~/interactlive/interactlive-app

# Restaurer l'ancien dossier
mv interactlive-docker-ready interactlive-docker-ready.v3.failed
mv interactlive-docker-ready.v2.backup interactlive-docker-ready

# Restaurer la DB depuis le backup pris avant migration
docker run --rm \
    -v interactlive_data:/data \
    -v /var/lib/docker/volumes/interactlive_data/_data:/source \
    alpine sh -c "cp /source/backup-avant-v3.db /data/interactlive.db"

# Relancer la v2
cd interactlive-docker-ready/docker
docker compose up -d
```

---

## Questions fréquentes

**Q : Est-ce que je peux encore utiliser `.\demarrer.ps1` en local pour tester ?**
Oui, toujours. Le script n'a pas changé, il fonctionnera avec la v3 sur ton PC Windows.

**Q : Si j'oublie mon mot de passe admin, je suis bloqué ?**
Tu peux toujours accéder à la DB SQLite directement via `docker compose exec interactlive sqlite3 /data/interactlive.db` et réinitialiser ton compte manuellement.

**Q : Je peux avoir plusieurs admins ?**
Oui. Depuis la page Utilisateurs, tu peux cliquer "👑 Promouvoir" sur un utilisateur approuvé pour en faire un admin. Limite de sécurité : au moins un admin doit toujours exister.
