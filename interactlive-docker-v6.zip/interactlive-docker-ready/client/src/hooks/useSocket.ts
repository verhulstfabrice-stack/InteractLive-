import { useEffect, useRef, useCallback, useState } from "react";
import { io, Socket } from "socket.io-client";

interface EventState {
  currentQuestion: number;
  showResults: boolean;
  votingOpen: boolean;
  status: string;
  timerEndAt: number | null;
  timerDuration: number | null;
}

interface LiveResults {
  questionId: number;
  results: Record<string, number> | string[];
  totalAnswers: number;
  type?: string;
}

// URL WebSocket : toujours même origine.
// - En dev : Vite proxifie /socket.io vers 3001
// - En prod : Nginx proxifie /socket.io vers 3001
// Une chaîne vide dans io() signifie "même origine" => compatible HTTPS/WSS
function getSocketUrl(): string {
  return "";
}

export function useSocket() {
  const socketRef = useRef<Socket | null>(null);
  const rejoinRef = useRef<
    | { type: "participant"; eventCode: string; participantId: number; nickname: string }
    | { type: "presenter"; eventCode: string }
    | null
  >(null);
  const [isConnected, setIsConnected] = useState(false);
  const [eventState, setEventState] = useState<EventState | null>(null);
  const [liveResults, setLiveResults] = useState<LiveResults | null>(null);
  const [participantCount, setParticipantCount] = useState(0);
  const [answerConfirmed, setAnswerConfirmed] = useState(false);

  useEffect(() => {
    const socketUrl = getSocketUrl();
    console.log("[Socket] Connexion à:", socketUrl || "même origine");

    const socket = socketUrl
      ? io(socketUrl, { transports: ["websocket", "polling"], withCredentials: true })
      : io({ transports: ["websocket", "polling"], withCredentials: true });

    socket.on("connect", () => {
      console.log("[Socket] Connecté, id:", socket.id);
      setIsConnected(true);
      const r = rejoinRef.current;
      if (r) {
        if (r.type === "participant") {
          socket.emit("JOIN_ROOM", { eventCode: r.eventCode, participantId: r.participantId, nickname: r.nickname });
        } else {
          socket.emit("PRESENTER_JOIN", { eventCode: r.eventCode });
        }
      }
    });

    socket.on("disconnect", () => {
      console.log("[Socket] Déconnecté");
      setIsConnected(false);
    });

    socket.on("connect_error", (error) => {
      console.error("[Socket] Erreur de connexion:", error.message);
    });

    socket.on("UPDATE_STATE", (state: EventState) => {
      setEventState(state);
      setAnswerConfirmed(false);
    });

    socket.on("LIVE_RESULTS", (results: LiveResults) => {
      setLiveResults(results);
    });

    socket.on("PARTICIPANT_COUNT", (count: number) => {
      setParticipantCount(count);
    });

    socket.on("QUESTION_CHANGED", (data: any) => {
      const questionIndex = typeof data === "number" ? data : data.questionIndex;
      setEventState(prev => prev ? { ...prev, currentQuestion: questionIndex } : null);
      setLiveResults(null);
      setAnswerConfirmed(false);
    });

    socket.on("ANSWER_CONFIRMED", () => {
      setAnswerConfirmed(true);
    });

    // Événements de sécurité : accès refusé ou session révoquée
    socket.on("UNAUTHORIZED", (data: { action: string; message: string }) => {
      console.warn("[Socket] Accès refusé:", data);
      alert(`⛔ ${data.message}\n\nAction refusée: ${data.action}`);
    });

    socket.on("SESSION_REVOKED", (data: { reason: string }) => {
      console.warn("[Socket] Session révoquée:", data);
      alert(
        data.reason === "blocked"
          ? "⛔ Votre compte a été bloqué par un administrateur.\nVous allez être déconnecté."
          : "Votre session a été révoquée. Vous allez être déconnecté."
      );
      // Rediriger vers la page de connexion après déconnexion du socket
      setTimeout(() => {
        window.location.href = "/login";
      }, 1500);
    });

    socketRef.current = socket;

    return () => {
      socket.disconnect();
    };
  }, []);

  const joinRoom = useCallback((eventCode: string, participantId: number, nickname: string) => {
    rejoinRef.current = { type: "participant", eventCode, participantId, nickname };
    socketRef.current?.emit("JOIN_ROOM", { eventCode, participantId, nickname });
  }, []);

  const submitAnswer = useCallback((eventCode: string, questionId: number, participantId: number, content: any) => {
    socketRef.current?.emit("SUBMIT_ANSWER", { eventCode, questionId, participantId, content });
  }, []);

  const presenterJoin = useCallback((eventCode: string) => {
    rejoinRef.current = { type: "presenter", eventCode };
    socketRef.current?.emit("PRESENTER_JOIN", { eventCode });
  }, []);

  const startEvent = useCallback((eventCode: string) => {
    socketRef.current?.emit("START_EVENT", { eventCode });
  }, []);

  const nextQuestion = useCallback((eventCode: string) => {
    socketRef.current?.emit("NEXT_QUESTION", { eventCode });
  }, []);

  const previousQuestion = useCallback((eventCode: string) => {
    socketRef.current?.emit("PREVIOUS_QUESTION", { eventCode });
  }, []);

  const toggleResults = useCallback((eventCode: string) => {
    socketRef.current?.emit("TOGGLE_RESULTS", { eventCode });
  }, []);

  const toggleVoting = useCallback((eventCode: string) => {
    socketRef.current?.emit("TOGGLE_VOTING", { eventCode });
  }, []);

  const endEvent = useCallback((eventCode: string) => {
    socketRef.current?.emit("END_EVENT", { eventCode });
  }, []);

  const startTimer = useCallback((eventCode: string, durationMs: number) => {
    socketRef.current?.emit("START_TIMER", { eventCode, durationMs });
  }, []);

  const stopTimer = useCallback((eventCode: string) => {
    socketRef.current?.emit("STOP_TIMER", { eventCode });
  }, []);

  return {
    isConnected,
    eventState,
    liveResults,
    participantCount,
    answerConfirmed,
    joinRoom,
    submitAnswer,
    presenterJoin,
    startEvent,
    nextQuestion,
    previousQuestion,
    toggleResults,
    toggleVoting,
    endEvent,
    startTimer,
    stopTimer,
  };
}
