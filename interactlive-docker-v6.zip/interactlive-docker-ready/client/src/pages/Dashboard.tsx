import { useState } from "react";
import { trpc } from "../lib/trpc";
import { navigate } from "../App";

export default function Dashboard() {
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const { data: user } = trpc.auth.me.useQuery();
  const { data: events, isLoading } = trpc.event.list.useQuery();
  const utils = trpc.useUtils();

  const createMutation = trpc.event.create.useMutation({
    onSuccess: () => {
      utils.event.list.invalidate();
      setShowCreate(false);
      setTitle("");
      setDescription("");
    },
  });

  const deleteMutation = trpc.event.delete.useMutation({
    onSuccess: () => utils.event.list.invalidate(),
  });

  const duplicateMutation = trpc.event.duplicate.useMutation({
    onSuccess: () => utils.event.list.invalidate(),
    onError: (err) => alert(`Erreur: ${err.message}`),
  });

  const [statsEventId, setStatsEventId] = useState<number | null>(null);
  const { data: eventStats } = trpc.event.getStats.useQuery(
    { id: statsEventId ?? 0 },
    { enabled: statsEventId !== null }
  );

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      navigate("/");
    },
  });

  // Compteur d'utilisateurs en attente (admin uniquement)
  const isAdmin = user?.role === "admin";
  const { data: pendingData } = trpc.admin.pendingCount.useQuery(undefined, {
    enabled: isAdmin,
    refetchInterval: 30000, // rafraîchit toutes les 30s
  });
  const pendingCount = pendingData?.count ?? 0;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    createMutation.mutate({ title, description });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex flex-wrap gap-y-2 justify-between items-center">
          <button onClick={() => navigate("/")} className="text-xl sm:text-2xl font-bold text-primary-600">
            ⚡ InteractLive
          </button>
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            {isAdmin && (
              <button
                onClick={() => navigate("/admin/users")}
                className="relative px-2 sm:px-3 py-1.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium text-sm sm:text-base"
                title="Gérer les utilisateurs"
              >
                <span className="hidden sm:inline">👥 Utilisateurs</span>
                <span className="sm:hidden">👥</span>
                {pendingCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full min-w-[20px] h-5 flex items-center justify-center px-1.5">
                    {pendingCount}
                  </span>
                )}
              </button>
            )}
            <span className="text-gray-600 text-sm sm:text-base truncate max-w-[140px] sm:max-w-none">
              {user?.name || user?.email}
            </span>
            <button
              onClick={() => logoutMutation.mutate()}
              className="text-gray-500 hover:text-red-500 text-sm sm:text-base"
            >
              <span className="hidden sm:inline">Déconnexion</span>
              <span className="sm:hidden">↩</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-3 sm:px-4 py-5 sm:py-8">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 sm:mb-8 gap-3">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Mes événements</h1>
          <button
            onClick={() => setShowCreate(true)}
            className="px-5 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-semibold text-sm sm:text-base"
          >
            + Nouvel événement
          </button>
        </div>

        {/* Modal création */}
        {showCreate && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-3">
            <div className="bg-white rounded-2xl p-5 sm:p-8 w-full max-w-md max-h-[90vh] overflow-y-auto">
              <h2 className="text-2xl font-bold mb-6">Nouvel événement</h2>
              <form onSubmit={handleCreate} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Titre *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    placeholder="Ex: Formation React"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                    rows={3}
                    placeholder="Description de l'événement..."
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowCreate(false)}
                    className="flex-1 py-3 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={createMutation.isPending}
                    className="flex-1 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
                  >
                    {createMutation.isPending ? "Création..." : "Créer"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Liste des événements */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent mx-auto"></div>
          </div>
        ) : events?.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl">
            <p className="text-gray-500 text-lg">Aucun événement pour le moment</p>
            <p className="text-gray-400 mt-2">Créez votre premier événement pour commencer</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events?.map((event) => (
              <div key={event.id} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{event.title}</h3>
                    <p className="text-sm text-gray-500 mt-1">Code: {event.code}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    event.status === "live" ? "bg-green-100 text-green-700" :
                    event.status === "finished" ? "bg-gray-100 text-gray-700" :
                    "bg-yellow-100 text-yellow-700"
                  }`}>
                    {event.status === "live" ? "En cours" : 
                     event.status === "finished" ? "Terminé" : "Brouillon"}
                  </span>
                </div>

                <div className="flex gap-2 text-sm text-gray-500 mb-4">
                  <span>{event._count.questions} questions</span>
                  <span>•</span>
                  <span>{event._count.participants} participants</span>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => navigate(`/event/${event.id}/edit`)}
                    className="flex-1 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm font-medium min-w-[80px]"
                  >
                    Éditer
                  </button>
                  <button
                    onClick={() => navigate(`/presenter/${event.id}`)}
                    className="flex-1 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 text-sm font-medium min-w-[80px]"
                  >
                    Lancer
                  </button>
                  <button
                    onClick={() => setStatsEventId(event.id)}
                    className="px-3 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-sm"
                    title="Statistiques"
                  >
                    📊
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Dupliquer « ${event.title} » ?`)) {
                        duplicateMutation.mutate({ id: event.id });
                      }
                    }}
                    className="px-3 py-2 text-blue-500 hover:bg-blue-50 rounded-lg text-sm"
                    title="Dupliquer"
                  >
                    📋
                  </button>
                  <button
                    onClick={() => {
                      if (confirm("Supprimer cet événement ?")) {
                        deleteMutation.mutate({ id: event.id });
                      }
                    }}
                    className="px-3 py-2 text-red-500 hover:bg-red-50 rounded-lg"
                    title="Supprimer"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal Statistiques */}
        {statsEventId !== null && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 overflow-y-auto p-3">
            <div className="bg-white rounded-2xl p-5 sm:p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-2xl font-bold">📊 Statistiques</h2>
                <button onClick={() => setStatsEventId(null)} className="text-gray-400 hover:text-gray-600 text-2xl">×</button>
              </div>

              {!eventStats ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-10 w-10 border-4 border-primary-500 border-t-transparent mx-auto"></div>
                </div>
              ) : eventStats.scorableQuestions === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p className="text-4xl mb-3">📭</p>
                  <p>Aucune question QCM ou Vrai/Faux à analyser.</p>
                  <p className="text-sm mt-2">Les statistiques de réussite ne s'appliquent qu'à ces types de questions.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-gray-50 rounded-xl p-4">
                      <p className="text-xs text-gray-500 mb-1">Questions</p>
                      <p className="text-2xl font-bold">{eventStats.totalQuestions}</p>
                    </div>
                    <div className="bg-gray-50 rounded-xl p-4">
                      <p className="text-xs text-gray-500 mb-1">Participants</p>
                      <p className="text-2xl font-bold">{eventStats.totalParticipants}</p>
                    </div>
                    <div className="bg-green-50 rounded-xl p-4">
                      <p className="text-xs text-green-700 mb-1">Réussite moyenne</p>
                      <p className="text-2xl font-bold text-green-700">
                        {eventStats.avgSuccessRate !== null ? `${eventStats.avgSuccessRate}%` : "—"}
                      </p>
                    </div>
                    <div className="bg-indigo-50 rounded-xl p-4">
                      <p className="text-xs text-indigo-700 mb-1">Questions notées</p>
                      <p className="text-2xl font-bold text-indigo-700">{eventStats.scorableQuestions}</p>
                    </div>
                  </div>

                  {eventStats.hardest && (
                    <div className="bg-red-50 border-l-4 border-red-400 rounded-xl p-4">
                      <p className="text-xs font-bold text-red-700 mb-1">😰 QUESTION LA PLUS RATÉE</p>
                      <p className="font-medium">{eventStats.hardest.title}</p>
                      <p className="text-sm text-red-600 mt-1">
                        {eventStats.hardest.successRate}% de réussite ({eventStats.hardest.correct}/{eventStats.hardest.total})
                      </p>
                    </div>
                  )}

                  {eventStats.easiest && eventStats.easiest.id !== eventStats.hardest?.id && (
                    <div className="bg-green-50 border-l-4 border-green-400 rounded-xl p-4">
                      <p className="text-xs font-bold text-green-700 mb-1">🌟 QUESTION LA MIEUX RÉUSSIE</p>
                      <p className="font-medium">{eventStats.easiest.title}</p>
                      <p className="text-sm text-green-600 mt-1">
                        {eventStats.easiest.successRate}% de réussite ({eventStats.easiest.correct}/{eventStats.easiest.total})
                      </p>
                    </div>
                  )}

                  <div>
                    <h3 className="font-semibold mb-3">Détail par question</h3>
                    <div className="space-y-2">
                      {eventStats.perQuestion.map((q: any) => (
                        <div key={q.id} className="bg-gray-50 rounded-lg p-3 flex items-center gap-3">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{q.title}</p>
                            <p className="text-xs text-gray-500">
                              {q.type === "mcq" ? "QCM" : "Vrai/Faux"}
                              {q.category && ` • 🏷️ ${q.category}`}
                            </p>
                          </div>
                          <div className="text-right shrink-0">
                            <p className={`font-bold ${q.successRate >= 70 ? "text-green-600" : q.successRate >= 40 ? "text-orange-500" : "text-red-500"}`}>
                              {q.successRate}%
                            </p>
                            <p className="text-xs text-gray-500">{q.correct}/{q.total}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <button onClick={() => setStatsEventId(null)}
                className="mt-6 w-full py-3 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium">
                Fermer
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
