import { useState, useEffect } from "react";
import { trpc } from "../lib/trpc";
import { navigate } from "../App";
import { useStore } from "../stores/useStore";

export default function JoinEvent({ initialCode }: { initialCode?: string }) {
  const [code, setCode] = useState(initialCode || "");
  const [nickname, setNickname] = useState("");
  const [error, setError] = useState("");
  const [step, setStep] = useState<"code" | "nickname">(initialCode ? "nickname" : "code");

  const { setParticipantSession } = useStore();

  const checkEvent = trpc.event.getByCode.useQuery(
    { code: code.toUpperCase() },
    { enabled: code.length >= 4, retry: false }
  );

  const joinMutation = trpc.participant.join.useMutation({
    onSuccess: (data) => {
      setParticipantSession({
        sessionId: data.participant.sessionId,
        participantId: data.participant.id,
        nickname: data.participant.nickname,
        eventId: data.event.id,
        eventCode: data.event.code,
      });
      navigate(`/participate/${data.event.id}/${data.participant.id}`);
    },
    onError: (err) => {
      setError(err.message);
    },
  });

  useEffect(() => {
    if (initialCode) {
      setCode(initialCode);
    }
  }, [initialCode]);

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      setError("Veuillez entrer un code");
      return;
    }
    if (checkEvent.isError) {
      setError("Code invalide");
      return;
    }
    setStep("nickname");
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nickname.trim()) {
      setError("Veuillez entrer un pseudo");
      return;
    }
    joinMutation.mutate({ code: code.toUpperCase(), nickname });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary-500 to-primary-700">
      <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary-600 mb-2">⚡ InteractLive</h1>
          <p className="text-gray-600">
            {step === "code" ? "Entrez le code de l'événement" : "Choisissez votre pseudo"}
          </p>
        </div>

        {step === "code" ? (
          <form onSubmit={handleCodeSubmit} className="space-y-6">
            <div>
              <input
                type="text"
                value={code}
                onChange={(e) => {
                  setCode(e.target.value.toUpperCase());
                  setError("");
                }}
                className="w-full px-6 py-4 text-3xl font-mono text-center border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent tracking-widest"
                placeholder="CODE"
                maxLength={8}
                autoFocus
              />
              {checkEvent.data && (
                <p className="text-green-600 text-center mt-2">
                  ✓ {checkEvent.data.title}
                </p>
              )}
            </div>

            {error && <p className="text-red-500 text-center">{error}</p>}

            <button
              type="submit"
              disabled={!checkEvent.data}
              className="w-full py-4 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-semibold text-lg disabled:opacity-50"
            >
              Continuer →
            </button>
          </form>
        ) : (
          <form onSubmit={handleJoin} className="space-y-6">
            <div className="text-center mb-4">
              <span className="inline-block px-4 py-2 bg-primary-100 text-primary-700 rounded-full text-sm font-medium">
                {checkEvent.data?.title}
              </span>
            </div>

            <div>
              <input
                type="text"
                value={nickname}
                onChange={(e) => {
                  setNickname(e.target.value);
                  setError("");
                }}
                className="w-full px-6 py-4 text-xl text-center border-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="Votre pseudo"
                maxLength={20}
                autoFocus
              />
            </div>

            {error && <p className="text-red-500 text-center">{error}</p>}

            <button
              type="submit"
              disabled={joinMutation.isPending}
              className="w-full py-4 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-semibold text-lg disabled:opacity-50"
            >
              {joinMutation.isPending ? "Connexion..." : "Rejoindre 🚀"}
            </button>

            <button
              type="button"
              onClick={() => setStep("code")}
              className="w-full py-2 text-gray-600 hover:text-gray-800"
            >
              ← Changer de code
            </button>
          </form>
        )}

        <button
          onClick={() => navigate("/")}
          className="w-full mt-6 py-2 text-gray-500 hover:text-primary-600"
        >
          Retour à l'accueil
        </button>
      </div>
    </div>
  );
}
