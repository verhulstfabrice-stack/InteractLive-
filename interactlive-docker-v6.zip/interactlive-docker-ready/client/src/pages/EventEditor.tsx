import { useState, useRef } from "react";
import * as XLSX from "xlsx";
import { trpc } from "../lib/trpc";
import { navigate } from "../App";

export default function EventEditor({ eventId }: { eventId: number }) {
  const [showAddQuestion, setShowAddQuestion] = useState(false);
  const [questionType, setQuestionType] = useState<"mcq" | "wordcloud" | "open" | "trueFalse" | "scale" | "fillBlank">("mcq");
  const [questionTitle, setQuestionTitle] = useState("");
  const [options, setOptions] = useState([
    { id: "opt_1", text: "", isCorrect: true },
    { id: "opt_2", text: "", isCorrect: false },
  ]);
  const [scaleMin, setScaleMin] = useState(1);
  const [scaleMax, setScaleMax] = useState(5);
  const [scaleLabel, setScaleLabel] = useState("");
  // Sprint 3 — fillBlank : liste de blocs de réponse, indexés sur les {} du titre
  const [blanks, setBlanks] = useState<Array<{ answer: string; synonyms: string[] }>>([
    { answer: "", synonyms: [] },
  ]);
  const [timerDuration, setTimerDuration] = useState<number | null>(30);
  const [explanation, setExplanation] = useState("");
  const [category, setCategory] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<any | null>(null);
  const [editTimerDuration, setEditTimerDuration] = useState<number | null>(30);
  const [editExplanation, setEditExplanation] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: event, isLoading } = trpc.event.get.useQuery({ id: eventId });
  const utils = trpc.useUtils();

  const createQuestion = trpc.question.create.useMutation({
    onSuccess: () => { utils.event.get.invalidate({ id: eventId }); resetForm(); },
  });
  const deleteQuestion = trpc.question.delete.useMutation({
    onSuccess: () => utils.event.get.invalidate({ id: eventId }),
  });
  const updateQuestion = trpc.question.update.useMutation({
    onSuccess: () => utils.event.get.invalidate({ id: eventId }),
  });
  const swapOrder = trpc.question.swapOrder.useMutation({
    onSuccess: () => utils.event.get.invalidate({ id: eventId }),
  });
  const importMoodle = trpc.question.importMoodle.useMutation({
    onSuccess: (result) => {
      utils.event.get.invalidate({ id: eventId });
      setShowImport(false);
      alert(`${result.imported} questions importées !`);
    },
    onError: (err) => { alert(`Erreur: ${err.message}`); },
  });
  const resetProgress = trpc.event.resetProgress.useMutation({
    onSuccess: () => {
      utils.event.get.invalidate({ id: eventId });
      alert("Progression réinitialisée !");
    },
    onError: (err) => { alert(`Erreur: ${err.message}`); },
  });
  const { refetch: fetchExport } = trpc.event.exportResults.useQuery({ id: eventId }, { enabled: false });

  const handleExportExcel = async () => {
    const result = await fetchExport();
    const data = result.data;
    if (!data || data.rows.length === 0) { alert("Aucune donnée à exporter."); return; }

    const wb = XLSX.utils.book_new();

    // Feuille 1 : Réponses brutes
    const rawSheet = XLSX.utils.json_to_sheet(
      data.rows.map((r: any) => ({
        Question: r.question,
        Type: r.questionType,
        Catégorie: r.category || "",
        Participant: r.participant,
        Réponse: r.answer,
        Correcte: r.isCorrect,
        "Date/Heure": new Date(r.timestamp).toLocaleString("fr-FR"),
      }))
    );
    XLSX.utils.book_append_sheet(wb, rawSheet, "Réponses");

    // Feuille 2 : Classement participants
    if (data.scoreboard && data.scoreboard.length > 0) {
      const scoreSheet = XLSX.utils.json_to_sheet(
        data.scoreboard.map((s: any, i: number) => ({
          Rang: i + 1,
          Participant: s.nickname,
          "Bonnes réponses": s.correct,
          "Total questions": s.total,
          "Taux de réussite": `${s.successRate}%`,
        }))
      );
      XLSX.utils.book_append_sheet(wb, scoreSheet, "Classement");
    }

    // Feuille 3 : Synthèse par question
    if (data.perQuestion && data.perQuestion.length > 0) {
      const questionSheet = XLSX.utils.json_to_sheet(
        data.perQuestion.map((q: any) => ({
          Question: q.question,
          Type: q.type,
          Catégorie: q.category || "",
          "Nb réponses": q.total,
          "Bonnes réponses": q.correct,
          "Taux de réussite": `${q.successRate}%`,
        }))
      );
      XLSX.utils.book_append_sheet(wb, questionSheet, "Par question");
    }

    // Feuille 4 : Synthèse par catégorie
    if (data.categoryStats && data.categoryStats.length > 0) {
      const catSheet = XLSX.utils.json_to_sheet(
        data.categoryStats.map((c: any) => ({
          Catégorie: c.category,
          "Nb réponses": c.total,
          "Bonnes réponses": c.correct,
          "Taux de réussite": `${c.successRate}%`,
        }))
      );
      XLSX.utils.book_append_sheet(wb, catSheet, "Par catégorie");
    }

    // Feuille 0 : Résumé global
    const summary = [
      { Indicateur: "Événement", Valeur: data.eventTitle },
      { Indicateur: "Code", Valeur: data.eventCode },
      { Indicateur: "Nombre de participants", Valeur: data.totalParticipants },
      { Indicateur: "Nombre de questions", Valeur: data.totalQuestions },
      { Indicateur: "Nombre de réponses", Valeur: data.rows.length },
    ];
    if (data.scoreboard && data.scoreboard.length > 0) {
      const avg = Math.round(
        data.scoreboard.reduce((sum: number, s: any) => sum + s.successRate, 0) / data.scoreboard.length
      );
      summary.push({ Indicateur: "Taux de réussite moyen", Valeur: `${avg}%` });
    }
    const summarySheet = XLSX.utils.json_to_sheet(summary);
    XLSX.utils.book_append_sheet(wb, summarySheet, "Résumé");
    // Déplacer "Résumé" en première position
    wb.SheetNames = ["Résumé", ...wb.SheetNames.filter(n => n !== "Résumé")];

    const filename = `${data.eventTitle.replace(/[^a-zA-Z0-9]/g, "_")}_resultats.xlsx`;
    XLSX.writeFile(wb, filename);
  };

  const handleResetProgress = () => {
    if (confirm("⚠️ Supprimer toutes les réponses et participants ?\n\nCette action est irréversible.")) {
      resetProgress.mutate({ id: eventId });
    }
  };

  const resetForm = () => {
    setShowAddQuestion(false); setQuestionTitle(""); setQuestionType("mcq");
    setOptions([{ id: "opt_1", text: "", isCorrect: true }, { id: "opt_2", text: "", isCorrect: false }]);
    setScaleMin(1); setScaleMax(5); setScaleLabel(""); setTimerDuration(30);
    setExplanation(""); setCategory("");
    setBlanks([{ answer: "", synonyms: [] }]);
  };

  // Sprint 3 — Détection auto du nombre de trous {} dans le titre
  // Synchronise la liste de blocs blanks sur le nombre détecté.
  const blankCountInTitle = (questionTitle.match(/\{\}/g) || []).length;
  const syncBlanksWithTitle = () => {
    setBlanks((prev) => {
      const target = Math.max(blankCountInTitle, 1);
      if (prev.length === target) return prev;
      if (prev.length < target) {
        return [...prev, ...Array(target - prev.length).fill(0).map(() => ({ answer: "", synonyms: [] as string[] }))];
      }
      return prev.slice(0, target);
    });
  };

  const handleAddQuestion = () => {
    if (!questionTitle.trim()) {
      alert("Merci de saisir un titre pour la question.");
      return;
    }
    let payload: any = {};
    if (questionType === "mcq") {
      const validOptions = options.filter(o => o.text.trim());
      if (validOptions.length < 2) {
        alert("Un QCM doit avoir au moins 2 options remplies.");
        return;
      }
      if (!validOptions.some(o => o.isCorrect)) {
        alert("Vous devez désigner au moins une option comme bonne réponse (bouton vert ✓).");
        return;
      }
      payload.options = validOptions;
    } else if (questionType === "trueFalse") {
      payload.options = [
        { id: "true", text: "Vrai", isCorrect: false },
        { id: "false", text: "Faux", isCorrect: false },
      ];
      const correct = options[0]?.isCorrect ? "true" : "false";
      payload.options = payload.options.map((o: any) => ({ ...o, isCorrect: o.id === correct }));
      payload.correctAnswerId = correct;
    } else if (questionType === "scale") {
      if (scaleMin >= scaleMax) {
        alert("La valeur minimum du curseur doit être inférieure à la valeur maximum.");
        return;
      }
      payload = { min: scaleMin, max: scaleMax, label: scaleLabel };
    } else if (questionType === "fillBlank") {
      // Validation : au moins un trou, et chaque trou doit avoir une réponse attendue
      if (blankCountInTitle === 0) {
        alert("L'énoncé doit contenir au moins un emplacement {} pour un trou.");
        return;
      }
      if (blanks.length !== blankCountInTitle) {
        alert("Le nombre de blocs de réponse ne correspond pas au nombre de trous dans l'énoncé.");
        return;
      }
      const empty = blanks.findIndex(b => !b.answer.trim());
      if (empty !== -1) {
        alert(`La réponse attendue du trou n°${empty + 1} est vide.`);
        return;
      }
      payload.blanks = blanks.map(b => ({
        answer: b.answer.trim(),
        synonyms: b.synonyms.map(s => s.trim()).filter(s => s.length > 0),
      }));
    }
    if (timerDuration) payload.timerDuration = timerDuration;
    if (explanation.trim()) payload.explanation = explanation.trim();
    if (category.trim()) payload.category = category.trim();
    createQuestion.mutate({ eventId, type: questionType, title: questionTitle, payload });
  };

  const handleEditQuestion = (question: any) => {
    const payload = question.payload ? JSON.parse(question.payload) : {};
    setEditingQuestion(question);
    setEditTimerDuration(payload.timerDuration ?? null);
    setEditExplanation(payload.explanation ?? "");
    setEditCategory(payload.category ?? "");
  };

  const handleSaveEdit = () => {
    if (!editingQuestion) return;
    const payload = editingQuestion.payload ? JSON.parse(editingQuestion.payload) : {};
    if (editTimerDuration) payload.timerDuration = editTimerDuration;
    else delete payload.timerDuration;
    if (editExplanation.trim()) payload.explanation = editExplanation.trim();
    else delete payload.explanation;
    if (editCategory.trim()) payload.category = editCategory.trim();
    else delete payload.category;
    updateQuestion.mutate({ id: editingQuestion.id, payload });
    setEditingQuestion(null);
  };

  const handleMoveUp = (index: number) => {
    const questions = event?.questions || [];
    if (index === 0) return;
    swapOrder.mutate({ idA: questions[index].id, idB: questions[index - 1].id });
  };

  const handleMoveDown = (index: number) => {
    const questions = event?.questions || [];
    if (index === questions.length - 1) return;
    swapOrder.mutate({ idA: questions[index].id, idB: questions[index + 1].id });
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => { importMoodle.mutate({ eventId, xmlContent: event.target?.result as string }); };
    reader.readAsText(file);
  };

  const addOption = () => setOptions([...options, { id: `opt_${Date.now()}`, text: "", isCorrect: false }]);
  const updateOption = (index: number, text: string) => { const n = [...options]; n[index].text = text; setOptions(n); };
  const setCorrectOption = (index: number) => setOptions(options.map((o, i) => ({ ...o, isCorrect: i === index })));
  const removeOption = (index: number) => { if (options.length <= 2) return; setOptions(options.filter((_, i) => i !== index)); };

  const QUESTION_TYPES = [
    { type: "mcq", icon: "📊", label: "QCM", desc: "Choix multiples" },
    { type: "trueFalse", icon: "✓✗", label: "Vrai/Faux", desc: "Deux options" },
    { type: "scale", icon: "📏", label: "Curseur", desc: "Note 1–10" },
    { type: "wordcloud", icon: "☁️", label: "Nuage", desc: "Mots-clés" },
    { type: "open", icon: "💬", label: "Ouverte", desc: "Texte libre" },
    { type: "fillBlank", icon: "✏️", label: "À trous", desc: "Compléter texte" },
  ];

  const TYPE_LABELS: Record<string, string> = {
    mcq: "QCM", trueFalse: "Vrai/Faux", scale: "Curseur",
    wordcloud: "Nuage de mots", open: "Question ouverte", fillBlank: "Texte à trous",
  };
  const TYPE_COLORS: Record<string, string> = {
    mcq: "bg-blue-100 text-blue-700", trueFalse: "bg-teal-100 text-teal-700",
    scale: "bg-orange-100 text-orange-700", wordcloud: "bg-purple-100 text-purple-700",
    open: "bg-green-100 text-green-700", fillBlank: "bg-pink-100 text-pink-700",
  };

  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div></div>;
  if (!event) return <div className="min-h-screen flex items-center justify-center"><p className="text-red-500">Événement non trouvé</p></div>;

  const questions = event.questions || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex flex-wrap gap-y-2 justify-between items-center">
          <div className="flex items-center gap-2 sm:gap-4 min-w-0">
            <button onClick={() => navigate("/dashboard")} className="text-gray-500 hover:text-gray-700 cursor-pointer shrink-0">←</button>
            <h1 className="text-base sm:text-xl font-bold text-gray-900 truncate max-w-[40vw] sm:max-w-none">{event.title}</h1>
            <span className="hidden sm:inline text-sm text-gray-500 shrink-0">Code: {event.code}</span>
            <span className={`text-xs px-2 py-1 rounded-full shrink-0 ${event.status === "draft" ? "bg-gray-100 text-gray-600" : event.status === "live" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
              {event.status === "draft" ? "Brouillon" : event.status === "live" ? "En cours" : "Terminé"}
            </span>
          </div>
          <button onClick={() => navigate(`/presenter/${eventId}`)} className="px-3 sm:px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium cursor-pointer text-sm sm:text-base">
            🚀 <span className="hidden sm:inline">Lancer la présentation →</span><span className="sm:hidden">Lancer</span>
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-3 sm:px-4 py-5 sm:py-8">
        {/* Actions */}
        <div className="flex flex-wrap gap-2 sm:gap-3 mb-5 sm:mb-6">
          <button onClick={() => setShowAddQuestion(true)} className="px-4 sm:px-5 py-2.5 sm:py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium cursor-pointer text-sm sm:text-base">
            + Ajouter une question
          </button>
          <button onClick={() => setShowImport(true)} className="px-4 sm:px-5 py-2.5 sm:py-3 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium cursor-pointer text-sm sm:text-base">
            📥 <span className="hidden sm:inline">Importer Moodle XML</span><span className="sm:hidden">Importer</span>
          </button>
          <button onClick={handleExportExcel} className="px-4 sm:px-5 py-2.5 sm:py-3 border border-green-300 text-green-700 rounded-lg hover:bg-green-50 font-medium cursor-pointer text-sm sm:text-base">
            📊 <span className="hidden sm:inline">Exporter résultats (Excel)</span><span className="sm:hidden">Export</span>
          </button>
          <button onClick={handleResetProgress} disabled={resetProgress.isPending} className="px-4 sm:px-5 py-2.5 sm:py-3 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 font-medium cursor-pointer disabled:opacity-50 text-sm sm:text-base">
            {resetProgress.isPending ? "⏳" : "🔄"} <span className="hidden sm:inline">Réinitialiser la progression</span><span className="sm:hidden">Reset</span>
          </button>
        </div>

        {/* Modal Import */}
        {showImport && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-3">
            <div className="bg-white rounded-2xl p-5 sm:p-8 w-full max-w-md max-h-[90vh] overflow-y-auto">
              <h2 className="text-2xl font-bold mb-4">Importer depuis Moodle</h2>
              <p className="text-gray-600 mb-6">Sélectionnez un fichier XML exporté depuis Moodle.</p>
              <input ref={fileInputRef} type="file" accept=".xml" onChange={handleFileImport} className="hidden" />
              <button onClick={() => fileInputRef.current?.click()} disabled={importMoodle.isPending}
                className="w-full py-4 border-2 border-dashed border-gray-300 rounded-xl hover:border-primary-500 hover:bg-primary-50 transition-colors cursor-pointer">
                {importMoodle.isPending ? "Import en cours..." : "📁 Choisir un fichier XML"}
              </button>
              <button onClick={() => setShowImport(false)} className="w-full mt-4 py-2 text-gray-600 hover:text-gray-800 cursor-pointer">Annuler</button>
            </div>
          </div>
        )}

        {/* Modal Ajouter Question */}
        {showAddQuestion && (
          <div className="fixed inset-0 bg-black/50 flex items-start sm:items-center justify-center z-50 overflow-y-auto p-3 sm:py-8">
            <div className="bg-white rounded-2xl p-4 sm:p-8 w-full max-w-2xl my-auto">
              <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Nouvelle question</h2>

              {/* Type */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-6">
                {QUESTION_TYPES.map(t => (
                  <button key={t.type} onClick={() => {
                    setQuestionType(t.type as any);
                    // Timer par défaut selon le type
                    // Timer 30s par défaut pour tous les types
                    setTimerDuration(30);
                  }}
                    className={`p-3 rounded-xl border-2 transition-colors cursor-pointer text-center ${questionType === t.type ? "border-primary-500 bg-primary-50" : "border-gray-200 hover:border-gray-300"}`}>
                    <div className="text-xl mb-1">{t.icon}</div>
                    <div className="font-medium text-sm">{t.label}</div>
                    <div className="text-xs text-gray-500">{t.desc}</div>
                  </button>
                ))}
              </div>

              {/* Titre */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Question *</label>
                <textarea value={questionTitle} onChange={(e) => setQuestionTitle(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  rows={3} placeholder="Entrez votre question..." />
              </div>

              {/* Options QCM */}
              {questionType === "mcq" && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Options (✓ = bonne réponse)</label>
                  <div className="space-y-3">
                    {options.map((option, index) => (
                      <div key={option.id} className="flex gap-2 items-center">
                        <button onClick={() => setCorrectOption(index)}
                          className={`w-8 h-8 rounded-full flex items-center justify-center cursor-pointer ${option.isCorrect ? "bg-green-500 text-white" : "bg-gray-200 text-gray-500 hover:bg-gray-300"}`}>✓</button>
                        <input type="text" value={option.text} onChange={(e) => updateOption(index, e.target.value)}
                          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                          placeholder={`Option ${index + 1}`} />
                        {options.length > 2 && (
                          <button onClick={() => removeOption(index)} className="text-red-500 hover:text-red-700 px-2 cursor-pointer">✕</button>
                        )}
                      </div>
                    ))}
                  </div>
                  <button onClick={addOption} className="mt-3 text-primary-600 hover:text-primary-700 text-sm font-medium cursor-pointer">+ Ajouter une option</button>
                </div>
              )}

              {/* Vrai/Faux — choix de la bonne réponse */}
              {questionType === "trueFalse" && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Bonne réponse</label>
                  <div className="flex gap-4">
                    <button onClick={() => setOptions([{ id: "opt_1", text: "Vrai", isCorrect: true }, { id: "opt_2", text: "Faux", isCorrect: false }])}
                      className={`flex-1 py-3 rounded-xl font-bold border-2 cursor-pointer ${options[0]?.isCorrect ? "border-green-500 bg-green-50 text-green-700" : "border-gray-200 hover:border-gray-300"}`}>
                      ✓ Vrai
                    </button>
                    <button onClick={() => setOptions([{ id: "opt_1", text: "Vrai", isCorrect: false }, { id: "opt_2", text: "Faux", isCorrect: true }])}
                      className={`flex-1 py-3 rounded-xl font-bold border-2 cursor-pointer ${!options[0]?.isCorrect ? "border-red-500 bg-red-50 text-red-700" : "border-gray-200 hover:border-gray-300"}`}>
                      ✗ Faux
                    </button>
                  </div>
                </div>
              )}

              {/* Scale config */}
              {questionType === "scale" && (
                <div className="mb-6 space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Valeur min</label>
                      <input type="number" value={scaleMin} onChange={e => setScaleMin(Number(e.target.value))} min={0} max={9}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
                    </div>
                    <div className="flex-1">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Valeur max</label>
                      <input type="number" value={scaleMax} onChange={e => setScaleMax(Number(e.target.value))} min={2} max={10}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Libellé (optionnel)</label>
                    <input type="text" value={scaleLabel} onChange={e => setScaleLabel(e.target.value)}
                      placeholder="Ex: De 1 (pas du tout) à 5 (tout à fait)"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
                  </div>
                </div>
              )}

              {/* Sprint 3 — Configuration fillBlank (texte à trous) */}
              {questionType === "fillBlank" && (
                <div className="mb-6">
                  {/* Aide */}
                  <div className="mb-4 p-3 bg-pink-50 border-l-4 border-pink-400 rounded text-sm text-pink-900">
                    <p className="font-semibold mb-1">💡 Comment créer des trous</p>
                    <p>Dans l'énoncé ci-dessus, tapez <code className="px-1 bg-white rounded font-mono">{"{}"}</code> à chaque endroit où le participant devra compléter.</p>
                    <p className="mt-1 text-xs text-pink-800">
                      <strong>Exemple :</strong> « La pédagogie de <code className="px-1 bg-white rounded font-mono">{"{}"}</code> postule que l'apprentissage se fait par <code className="px-1 bg-white rounded font-mono">{"{}"}</code>. »
                    </p>
                  </div>

                  {/* Compteur de trous détectés */}
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">
                      {blankCountInTitle === 0
                        ? "Aucun trou détecté dans l'énoncé"
                        : `${blankCountInTitle} trou${blankCountInTitle > 1 ? "s" : ""} détecté${blankCountInTitle > 1 ? "s" : ""}`}
                    </span>
                    {blankCountInTitle > 0 && blanks.length !== blankCountInTitle && (
                      <button
                        onClick={syncBlanksWithTitle}
                        className="text-xs px-3 py-1 bg-pink-600 text-white rounded hover:bg-pink-700 cursor-pointer"
                      >
                        🔄 Synchroniser ({blanks.length} → {blankCountInTitle})
                      </button>
                    )}
                  </div>

                  {/* Bloc par trou */}
                  {blankCountInTitle > 0 && blanks.slice(0, blankCountInTitle).map((blank, idx) => (
                    <div key={idx} className="mb-4 border-2 border-pink-200 rounded-xl p-4 bg-white">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-bold text-pink-700">Trou n°{idx + 1}</span>
                      </div>

                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Réponse attendue <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={blank.answer}
                        onChange={(e) => {
                          const next = [...blanks];
                          next[idx] = { ...next[idx], answer: e.target.value };
                          setBlanks(next);
                        }}
                        placeholder="Ex: Dewey"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 mb-3"
                      />

                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Synonymes acceptés <span className="text-gray-400 font-normal">(facultatif)</span>
                      </label>
                      <p className="text-xs text-gray-500 mb-2">
                        Toutes les réponses seront comparées sans tenir compte de la casse, des accents et des espaces autour.
                      </p>

                      {blank.synonyms.map((syn, synIdx) => (
                        <div key={synIdx} className="flex gap-2 mb-2">
                          <input
                            type="text"
                            value={syn}
                            onChange={(e) => {
                              const next = [...blanks];
                              const newSyn = [...next[idx].synonyms];
                              newSyn[synIdx] = e.target.value;
                              next[idx] = { ...next[idx], synonyms: newSyn };
                              setBlanks(next);
                            }}
                            placeholder={`Synonyme ${synIdx + 1}`}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500"
                          />
                          <button
                            onClick={() => {
                              const next = [...blanks];
                              next[idx] = {
                                ...next[idx],
                                synonyms: next[idx].synonyms.filter((_, i) => i !== synIdx),
                              };
                              setBlanks(next);
                            }}
                            className="px-3 py-2 text-red-500 hover:bg-red-50 rounded-lg cursor-pointer"
                            title="Supprimer ce synonyme"
                          >
                            ✕
                          </button>
                        </div>
                      ))}

                      <button
                        onClick={() => {
                          const next = [...blanks];
                          next[idx] = { ...next[idx], synonyms: [...next[idx].synonyms, ""] };
                          setBlanks(next);
                        }}
                        className="text-sm text-pink-600 hover:text-pink-700 font-medium cursor-pointer"
                      >
                        + Ajouter un synonyme
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Timer optionnel */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">⏱ Timer (optionnel)</label>
                <div className="flex gap-2 flex-wrap">
                  {[null, 30, 45, 60, 90, 120].map(v => (
                    <button key={String(v)} onClick={() => setTimerDuration(v)}
                      className={`px-4 py-2 rounded-lg border-2 text-sm cursor-pointer ${timerDuration === v ? "border-primary-500 bg-primary-50 text-primary-700" : "border-gray-200 hover:border-gray-300"}`}>
                      {v === null ? "Sans timer" : `${v}s`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Catégorie/Étiquette (facultatif) */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  🏷️ Catégorie <span className="text-gray-400 font-normal">(facultatif)</span>
                </label>
                <input type="text" value={category} onChange={e => setCategory(e.target.value)}
                  placeholder="Ex: CP4, AT2, Niveau 1, Bloom-Appliquer..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
                <p className="text-xs text-gray-500 mt-1">Permet de regrouper les statistiques par thème/compétence dans l'export.</p>
              </div>

              {/* Explication pédagogique (facultatif) */}
              {(questionType === "mcq" || questionType === "trueFalse") && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    💡 Explication pédagogique <span className="text-gray-400 font-normal">(facultatif)</span>
                  </label>
                  <textarea value={explanation} onChange={e => setExplanation(e.target.value)}
                    rows={3} placeholder="Explication affichée au participant après sa réponse (ex: « La bonne réponse est B car... »)"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
                  <p className="text-xs text-gray-500 mt-1">Transforme le quiz en outil formatif. Laissez vide si vous ne souhaitez pas afficher d'explication.</p>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3">
                <button onClick={resetForm} className="flex-1 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">Annuler</button>
                <button onClick={handleAddQuestion} disabled={createQuestion.isPending || !questionTitle.trim()}
                  className="flex-1 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 cursor-pointer">
                  {createQuestion.isPending ? "Création..." : "Créer la question"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Liste des questions */}
        {questions.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl">
            <p className="text-gray-500 text-lg">Aucune question pour le moment</p>
            <p className="text-gray-400 mt-2">Ajoutez votre première question ou importez depuis Moodle</p>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-gray-500">{questions.length} question(s) — réordonnez avec ↑ ↓</p>
            {questions.map((question, index) => {
              const payload = question.payload ? JSON.parse(question.payload) : {};
              return (
                <div key={question.id} className="bg-white rounded-xl p-5 shadow-sm flex gap-4">
                  {/* Boutons réordonnancement */}
                  <div className="flex flex-col gap-1 shrink-0">
                    <button onClick={() => handleMoveUp(index)} disabled={index === 0}
                      className="w-7 h-7 flex items-center justify-center bg-gray-100 hover:bg-gray-200 rounded disabled:opacity-30 cursor-pointer text-sm">↑</button>
                    <span className="w-7 h-7 flex items-center justify-center text-sm font-bold text-gray-400">{index + 1}</span>
                    <button onClick={() => handleMoveDown(index)} disabled={index === questions.length - 1}
                      className="w-7 h-7 flex items-center justify-center bg-gray-100 hover:bg-gray-200 rounded disabled:opacity-30 cursor-pointer text-sm">↓</button>
                  </div>

                  {/* Contenu */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <span className={`inline-block px-2 py-1 rounded text-xs font-medium mb-2 ${TYPE_COLORS[question.type] || "bg-gray-100 text-gray-700"}`}>
                          {TYPE_LABELS[question.type] || question.type}
                          {payload.timerDuration && <span className="ml-2 text-xs opacity-70">⏱ {payload.timerDuration}s</span>}
                        </span>
                        {payload.category && (
                          <span className="ml-2 inline-block px-2 py-1 rounded text-xs font-medium bg-indigo-100 text-indigo-700 mb-2">
                            🏷️ {payload.category}
                          </span>
                        )}
                        <h3 className="text-base font-medium text-gray-900">{question.title}</h3>
                        {(question.type === "mcq" || question.type === "trueFalse") && payload.options && (
                          <div className="mt-2 space-y-0.5">
                            {payload.options.map((opt: any) => (
                              <div key={opt.id} className={`text-sm ${opt.isCorrect ? "text-green-600 font-medium" : "text-gray-500"}`}>
                                {opt.isCorrect ? "✓" : "○"} {opt.text}
                              </div>
                            ))}
                          </div>
                        )}
                        {payload.explanation && (
                          <p className="text-xs text-blue-600 mt-2 italic">💡 {payload.explanation}</p>
                        )}
                        {question.type === "scale" && (
                          <p className="text-sm text-gray-500 mt-1">Échelle : {payload.min ?? 1} → {payload.max ?? 5}</p>
                        )}
                        {question.type === "fillBlank" && payload.blanks && (
                          <div className="mt-2 space-y-0.5">
                            {payload.blanks.map((b: any, i: number) => (
                              <div key={i} className="text-sm text-pink-700">
                                <span className="font-mono bg-pink-50 px-1 rounded text-xs mr-1">Trou {i + 1}</span>
                                <span className="font-medium">{b.answer}</span>
                                {b.synonyms && b.synonyms.length > 0 && (
                                  <span className="text-xs text-gray-500 ml-1">
                                    (ou {b.synonyms.join(", ")})
                                  </span>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button onClick={() => handleEditQuestion(question)}
                          className="text-blue-400 hover:text-blue-600 cursor-pointer" title="Modifier">✏️</button>
                        <button onClick={() => { if (confirm("Supprimer cette question ?")) deleteQuestion.mutate({ id: question.id }); }}
                          className="text-red-400 hover:text-red-600 cursor-pointer">🗑️</button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Modal édition */}
        {editingQuestion && (
          <div className="fixed inset-0 bg-black/50 flex items-start sm:items-center justify-center z-50 overflow-y-auto p-3 sm:py-8">
            <div className="bg-white rounded-2xl p-4 sm:p-8 w-full max-w-lg my-auto">
              <h2 className="text-lg sm:text-xl font-bold mb-1">Modifier la question</h2>
              <p className="text-gray-500 text-sm mb-4 sm:mb-6 truncate">« {editingQuestion.title} »</p>

              <label className="block text-sm font-medium text-gray-700 mb-2">⏱ Timer</label>
              <div className="flex gap-2 flex-wrap mb-6">
                {[null, 20, 30, 45, 60, 90, 120].map(v => (
                  <button key={String(v)} onClick={() => setEditTimerDuration(v)}
                    className={`px-4 py-2 rounded-lg border-2 text-sm cursor-pointer ${editTimerDuration === v ? "border-primary-500 bg-primary-50 text-primary-700 font-semibold" : "border-gray-200 hover:border-gray-300"}`}>
                    {v === null ? "Sans timer" : `${v}s`}
                  </button>
                ))}
              </div>

              <label className="block text-sm font-medium text-gray-700 mb-2">
                🏷️ Catégorie <span className="text-gray-400 font-normal">(facultatif)</span>
              </label>
              <input type="text" value={editCategory} onChange={e => setEditCategory(e.target.value)}
                placeholder="Ex: CP4, AT2, Bloom-Appliquer..."
                className="w-full px-4 py-2 mb-6 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />

              {(editingQuestion.type === "mcq" || editingQuestion.type === "trueFalse") && (
                <>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    💡 Explication pédagogique <span className="text-gray-400 font-normal">(facultatif)</span>
                  </label>
                  <textarea value={editExplanation} onChange={e => setEditExplanation(e.target.value)}
                    rows={3} placeholder="Affichée au participant après sa réponse..."
                    className="w-full px-4 py-2 mb-6 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
                </>
              )}

              <div className="flex gap-3">
                <button onClick={() => setEditingQuestion(null)}
                  className="flex-1 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">Annuler</button>
                <button onClick={handleSaveEdit} disabled={updateQuestion.isPending}
                  className="flex-1 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 cursor-pointer disabled:opacity-50">
                  {updateQuestion.isPending ? "Sauvegarde..." : "Enregistrer"}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
