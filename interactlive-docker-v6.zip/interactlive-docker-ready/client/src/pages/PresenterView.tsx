import { useEffect, useState, useMemo } from "react";
import { QRCodeSVG } from "qrcode.react";
import { trpc } from "../lib/trpc";
import { useSocket } from "../hooks/useSocket";
import { navigate } from "../App";

const COLORS = ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#06b6d4"];
const WORD_COLORS = [
  "#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#06b6d4",
  "#ec4899", "#14b8a6", "#f97316", "#6366f1", "#84cc16", "#a855f7",
  "#e11d48", "#0ea5e9", "#22c55e", "#eab308",
];

export default function PresenterView({ eventId }: { eventId: number }) {
  const { data: event, refetch } = trpc.event.get.useQuery({ id: eventId });
  const { data: systemInfo } = trpc.system.getLocalIP.useQuery();
  const updateEvent = trpc.event.update.useMutation();

  const [localState, setLocalState] = useState({
    currentQuestion: 0,
    showResults: false,
    votingOpen: true,
    status: "waiting" as string,
    timerEndAt: null as number | null,
    timerDuration: null as number | null,
  });

  const [showQRModal, setShowQRModal] = useState(false);
  const [showVotes, setShowVotes] = useState(false);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [isQuizDone, setIsQuizDone] = useState(false);
  const [timerRemaining, setTimerRemaining] = useState<number | null>(null);

  // Sprint 2 : mode plein écran + aide raccourcis clavier
  const [fullscreenMode, setFullscreenMode] = useState(false);
  const [showShortcutsHelp, setShowShortcutsHelp] = useState(false);

  // Countdown du timer — démarre depuis timerDuration pour éviter l'écart d'horloge
  useEffect(() => {
    if (!localState.timerEndAt || !localState.timerDuration) {
      setTimerRemaining(null);
      return;
    }
    setTimerRemaining(localState.timerDuration);
    let current = localState.timerDuration;
    const interval = setInterval(() => {
      current -= 1;
      if (current <= 0) {
        setTimerRemaining(0);
        clearInterval(interval);
      } else {
        setTimerRemaining(current);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [localState.timerEndAt]);

  const { data: scoreboard } = trpc.event.getScoreboard.useQuery(
    { id: eventId },
    { enabled: showScoreboard, retry: false }
  );

  const {
    isConnected,
    eventState,
    liveResults,
    participantCount,
    presenterJoin,
    startEvent,
    nextQuestion,
    previousQuestion,
    toggleResults,
    toggleVoting,
    endEvent,
    startTimer,
    stopTimer,
  } = useSocket();

  // Rejoindre la room au montage
  useEffect(() => {
    if (event?.code) {
      presenterJoin(event.code);
    }
  }, [event?.code, presenterJoin]);

  // Initialiser depuis la DB dès le chargement (gère la reprise de présentation)
  useEffect(() => {
    if (event) {
      setLocalState({
        currentQuestion: event.currentQuestion || 0,
        showResults: event.showResults || false,
        votingOpen: event.votingOpen ?? true,
        status: event.status,
        timerEndAt: null,
        timerDuration: null,
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [event?.id]);

  // Le socket override l'état DB en temps réel
  useEffect(() => {
    if (eventState) {
      setLocalState(eventState);
    }
  }, [eventState]);

  // Reset showVotes quand la question change
  useEffect(() => {
    setShowVotes(false);
  }, [localState.currentQuestion]);

  const questions = event?.questions || [];
  const currentQuestionIndex = localState.currentQuestion;
  const currentQuestion = questions[currentQuestionIndex];
  const payload = currentQuestion?.payload ? JSON.parse(currentQuestion.payload) : {};
  const options = payload.options || [];
  const correctAnswerId = payload.correctAnswerId || options.find((o: any) => o.isCorrect)?.id;

  // URL de participation :
  // - Si le serveur renvoie une publicUrl (PUBLIC_URL configurée), on l'utilise directement
  // - Sinon, on utilise l'IP détectée + port
  // - Sinon fallback sur l'URL courante
  const participationUrl = useMemo(() => {
    if (!event?.code) return "";

    // Priorité 1 : publicUrl renvoyée par le serveur (PUBLIC_URL configurée)
    if (systemInfo?.publicUrl) {
      return `${systemInfo.publicUrl}/join?code=${event.code}`;
    }

    // Priorité 2 : IP détectée + port
    if (systemInfo?.ip && systemInfo.ip !== "localhost") {
      return `http://${systemInfo.ip}:${systemInfo.port}/join?code=${event.code}`;
    }

    // Priorité 3 : l'URL courante dans le navigateur
    return `${window.location.origin}/join?code=${event.code}`;
  }, [event?.code, systemInfo]);

  // Nombre total de réponses pour la question courante
  const totalAnswers = useMemo(() => {
    if (liveResults?.questionId === currentQuestion?.id) {
      return liveResults.totalAnswers || 0;
    }
    return 0;
  }, [liveResults, currentQuestion]);

  // Calculer les résultats QCM
  const mcqResults = useMemo(() => {
    if (!liveResults || !currentQuestion || liveResults.questionId !== currentQuestion.id) {
      return options.map((opt: any) => ({
        ...opt,
        count: 0,
        percentage: 0,
        isCorrect: opt.id === correctAnswerId || opt.isCorrect === true,
      }));
    }

    if (liveResults.type === "wordcloud" || liveResults.type === "open") {
      return options.map((opt: any) => ({
        ...opt,
        count: 0,
        percentage: 0,
        isCorrect: opt.id === correctAnswerId || opt.isCorrect === true,
      }));
    }

    const results = liveResults.results as Record<string, number>;
    const total = liveResults.totalAnswers || 1;
    return options.map((opt: any) => ({
      ...opt,
      count: results[opt.id] || 0,
      percentage: Math.round(((results[opt.id] || 0) / total) * 100),
      isCorrect: opt.id === correctAnswerId || opt.isCorrect === true,
    }));
  }, [liveResults, currentQuestion, options, correctAnswerId]);

  // Calculer les mots du nuage
  const wordCloudData = useMemo(() => {
    if (!liveResults || !currentQuestion || liveResults.questionId !== currentQuestion.id) {
      return [];
    }
    if (liveResults.type !== "wordcloud") return [];

    const results = liveResults.results as Record<string, number>;
    const words = Object.entries(results).map(([word, count]) => ({ word, count: count as number }));
    words.sort((a, b) => b.count - a.count);
    return words;
  }, [liveResults, currentQuestion]);

  // Calculer les réponses ouvertes
  const openAnswers = useMemo(() => {
    if (!liveResults || !currentQuestion || liveResults.questionId !== currentQuestion.id) {
      return [];
    }
    if (liveResults.type !== "open") return [];
    return liveResults.results as unknown as string[];
  }, [liveResults, currentQuestion]);

  // Scale data
  const scaleData = useMemo(() => {
    if (!liveResults || !currentQuestion || liveResults.questionId !== currentQuestion.id) return null;
    if ((liveResults as any).type !== "scale") return null;
    const results = liveResults.results as Record<string, number>;
    const payload = currentQuestion?.payload ? JSON.parse(currentQuestion.payload) : {};
    const min = payload.min ?? 1;
    const max = payload.max ?? 5;
    const avg = (liveResults as any).average;
    return { results, min, max, avg, total: liveResults.totalAnswers };
  }, [liveResults, currentQuestion]);

  // Sprint 3 — fillBlank data (résultats agrégés par trou + par participant)
  const fillBlankData = useMemo(() => {
    if (!liveResults || !currentQuestion || liveResults.questionId !== currentQuestion.id) return null;
    if ((liveResults as any).type !== "fillBlank") return null;
    const data = liveResults as any;
    return {
      blanksCount: data.blanksCount as number,
      perBlank: data.perBlank as Array<{ answer: string; synonyms: string[]; correct: number; totalAnswered: number; wrongAnswers: { text: string; count: number }[] }>,
      perParticipant: data.perParticipant as Array<{ nickname: string; answers: { userAnswer: string; isCorrect: boolean }[]; score: number; total: number }>,
      totalAnswers: data.totalAnswers as number,
    };
  }, [liveResults, currentQuestion]);

  // Vue active pour fillBlank : par trou ou par participant
  const [fillBlankView, setFillBlankView] = useState<"perBlank" | "perParticipant">("perBlank");

  const handleStart = () => {
    if (event?.code) {
      startEvent(event.code);
      updateEvent.mutate({ id: eventId, status: "live" });
      setLocalState((prev) => ({ ...prev, status: "live" }));
      // Timer 30s par défaut pour toutes les questions si non défini
      const firstQ = questions[localState.currentQuestion];
      const firstPayload = firstQ?.payload ? JSON.parse(firstQ.payload) : {};
      const duration = firstPayload.timerDuration ?? 30;
      if (duration) startTimer(event.code, duration * 1000);
    }
  };

  const handleResume = () => {
    if (event?.code) {
      startEvent(event.code);
      updateEvent.mutate({ id: eventId, status: "live" });
      setLocalState((prev) => ({ ...prev, status: "live" }));
      const q = questions[localState.currentQuestion];
      const qPayload = q?.payload ? JSON.parse(q.payload) : {};
      const duration = qPayload.timerDuration ?? 30;
      if (duration) startTimer(event.code, duration * 1000);
    }
  };

  const handlePrevious = () => {
    if (event?.code && currentQuestionIndex > 0) {
      previousQuestion(event.code);
      const prevQ = questions[currentQuestionIndex - 1];
      const prevPayload = prevQ?.payload ? JSON.parse(prevQ.payload) : {};
      const prevDuration = prevPayload.timerDuration ?? 30;
      if (prevDuration) startTimer(event.code, prevDuration * 1000);
      else stopTimer(event.code);
      setLocalState((prev) => ({
        ...prev,
        currentQuestion: prev.currentQuestion - 1,
        showResults: false,
      }));
    }
  };

  const handleNext = () => {
    if (event?.code && currentQuestionIndex < questions.length - 1) {
      nextQuestion(event.code);
      const nextQ = questions[currentQuestionIndex + 1];
      const nextPayload = nextQ?.payload ? JSON.parse(nextQ.payload) : {};
      const nextDuration = nextPayload.timerDuration ?? 30;
      if (nextDuration) startTimer(event.code, nextDuration * 1000);
      else stopTimer(event.code);
      setLocalState((prev) => ({
        ...prev,
        currentQuestion: prev.currentQuestion + 1,
        showResults: false,
      }));
    }
  };

  const handleToggleVoting = () => {
    if (event?.code) {
      toggleVoting(event.code);
      setLocalState((prev) => ({ ...prev, votingOpen: !prev.votingOpen }));
    }
  };

  const handleToggleResults = () => {
    if (event?.code) {
      toggleResults(event.code);
      setLocalState((prev) => ({ ...prev, showResults: !prev.showResults }));
    }
  };

  const handleStartTimer = (seconds: number) => {
    if (event?.code) startTimer(event.code, seconds * 1000);
  };

  const handleStopTimer = () => {
    if (event?.code) stopTimer(event.code);
  };

  const handleFinishQuiz = () => {
    setIsQuizDone(true);
    setShowScoreboard(false);
    // Notifier les participants que le quiz est terminé
    if (event?.code) {
      endEvent(event.code);
      updateEvent.mutate({ id: eventId, status: "finished" });
    }
  };

  const handleEnd = () => {
    if (event?.code && confirm("Terminer l'événement ? Vous pourrez le reprendre plus tard.")) {
      endEvent(event.code);
      updateEvent.mutate({ id: eventId, status: "finished" });
      navigate("/dashboard");
    }
  };

  // ============================================
  // Sprint 2 : Mode plein écran + raccourcis clavier
  // ============================================

  // Bascule fullscreen navigateur + état local
  const toggleFullscreen = () => {
    const newState = !fullscreenMode;
    setFullscreenMode(newState);
    // On tente aussi le fullscreen natif du navigateur (F11 simulé)
    try {
      if (newState && !document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
      } else if (!newState && document.fullscreenElement) {
        document.exitFullscreen?.().catch(() => {});
      }
    } catch {
      // Fullscreen API non disponible : on garde juste l'état local
    }
  };

  // Sortir du plein écran si l'utilisateur utilise la touche Échap du navigateur
  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement && fullscreenMode) {
        setFullscreenMode(false);
      }
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, [fullscreenMode]);

  // Raccourcis clavier
  // Actifs uniquement en mode live (quand une question est active) ou en attente
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignorer si l'utilisateur tape dans un input, textarea, ou contentEditable
      const target = e.target as HTMLElement;
      const isTyping =
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.isContentEditable;
      if (isTyping) return;

      // Ignorer si une modale est ouverte (QR code, scoreboard final, etc.)
      if (showQRModal || isQuizDone) {
        // Sauf Échap pour fermer la modale QR
        if (e.key === "Escape" && showQRModal) {
          setShowQRModal(false);
        }
        return;
      }

      // Si l'aide des raccourcis est ouverte, Échap la ferme
      if (showShortcutsHelp) {
        if (e.key === "Escape" || e.key === "?") {
          e.preventDefault();
          setShowShortcutsHelp(false);
        }
        return;
      }

      // Raccourcis disponibles uniquement quand l'événement est en cours (live)
      // Certains aussi en waiting/finished (F, ?, Échap)
      const qIndex = localState.currentQuestion;
      const lastIndex = questions.length - 1;

      switch (e.key) {
        case " ":
        case "ArrowRight":
          // Question suivante — seulement en live et si pas dernière question
          if (isLive && qIndex < lastIndex) {
            e.preventDefault();
            handleNext();
          }
          break;

        case "ArrowLeft":
          // Question précédente
          if (isLive && qIndex > 0) {
            e.preventDefault();
            handlePrevious();
          }
          break;

        case "r":
        case "R":
          // Toggle résultats
          if (isLive) {
            e.preventDefault();
            handleToggleResults();
          }
          break;

        case "v":
        case "V":
          // Toggle votes ouverts/fermés
          if (isLive) {
            e.preventDefault();
            handleToggleVoting();
          }
          break;

        case "f":
        case "F":
          // Toggle plein écran (toujours disponible)
          e.preventDefault();
          toggleFullscreen();
          break;

        case "Escape":
          // Sortir du plein écran
          if (fullscreenMode) {
            e.preventDefault();
            toggleFullscreen();
          }
          break;

        case "?":
          // Afficher l'aide
          e.preventDefault();
          setShowShortcutsHelp(true);
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    localState.currentQuestion,
    localState.status,
    questions.length,
    fullscreenMode,
    showQRModal,
    isQuizDone,
    showShortcutsHelp,
  ]);

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
      </div>
    );
  }

  const isWaiting = localState.status === "waiting" || localState.status === "draft";
  const isLive = localState.status === "live";
  const isFinished = localState.status === "finished";

  return (
    <div
      className={`${
        fullscreenMode
          ? "fixed inset-0 z-50 bg-gray-900 overflow-auto"
          : "min-h-screen"
      } bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white`}
    >
      {/* Header (masqué en mode plein écran) */}
      {!fullscreenMode && (
        <header className="bg-black/30 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2 sm:py-3 flex flex-wrap gap-y-2 justify-between items-center">
            <div className="flex items-center gap-2 sm:gap-4 min-w-0">
              <button
                onClick={() => navigate("/dashboard")}
                className="text-white/70 hover:text-white cursor-pointer text-sm sm:text-base shrink-0"
              >
                ←
              </button>
              <h1 className="text-base sm:text-xl font-bold truncate max-w-[40vw] sm:max-w-none">
                {event.title}
              </h1>
              <span
                className={`px-2 sm:px-3 py-1 rounded-full text-xs shrink-0 ${
                  isConnected ? "bg-green-500" : "bg-red-500"
                }`}
              >
                {isConnected ? "●" : "○"}<span className="hidden sm:inline ml-1">{isConnected ? "Connecté" : "Déconnecté"}</span>
              </span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-4 flex-wrap">
              <span className="text-white/70 text-sm sm:text-base">
                👥 {participantCount}
              </span>
              {isLive && (
                <button
                  onClick={() => setShowQRModal(true)}
                  className="px-2.5 sm:px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm transition-colors cursor-pointer"
                  title="Afficher le QR Code"
                >
                  📱<span className="hidden sm:inline ml-1">QR Code</span>
                </button>
              )}
              <button
                onClick={() => setShowShortcutsHelp(true)}
                className="px-2.5 sm:px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm transition-colors cursor-pointer"
                title="Raccourcis clavier (?)"
              >
                ⌨️
              </button>
              <button
                onClick={toggleFullscreen}
                className="px-2.5 sm:px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm transition-colors cursor-pointer"
                title="Mode présentation (F)"
              >
                🖥️
              </button>
              {isLive && (
                <button
                  onClick={handleEnd}
                  className="px-3 sm:px-4 py-2 bg-red-500 hover:bg-red-600 rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <span className="hidden sm:inline">Terminer</span>
                  <span className="sm:hidden">⏹</span>
                </button>
              )}
            </div>
          </div>
        </header>
      )}

      {/* Bandeau minimal en mode plein écran (bouton Quitter + participants) */}
      {fullscreenMode && (
        <div className="fixed top-3 right-3 sm:top-4 sm:right-4 z-50 flex items-center gap-2 sm:gap-3 bg-black/60 backdrop-blur-sm rounded-full px-3 sm:px-4 py-1.5 sm:py-2">
          <span className="text-white/90 text-xs sm:text-sm">
            👥 {participantCount}
          </span>
          <button
            onClick={toggleFullscreen}
            className="px-2 sm:px-3 py-1 bg-white/10 hover:bg-white/20 rounded-full text-xs sm:text-sm transition-colors cursor-pointer"
            title="Quitter le plein écran (Échap)"
          >
            ✕<span className="hidden sm:inline ml-1">Quitter</span>
          </button>
        </div>
      )}

      <main className={`mx-auto px-3 sm:px-4 ${fullscreenMode ? "max-w-full py-3 sm:py-4" : "max-w-6xl py-4 sm:py-8"}`}>
        {/* ============================== */}
        {/* ÉCRAN D'ATTENTE                */}
        {/* ============================== */}
        {isWaiting && (
          <div className="text-center py-12">
            <h2 className="text-4xl font-bold mb-8">
              En attente des participants...
            </h2>

            <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 max-w-lg mx-auto">
              <p className="text-xl mb-4">Rejoignez avec le code :</p>
              <div className="text-6xl font-mono font-bold text-primary-400 mb-6">
                {event.code}
              </div>

              {participationUrl && (
                <>
                  <div
                    className="bg-white rounded-2xl p-4 inline-block mb-4 cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setShowQRModal(true)}
                    title="Cliquer pour agrandir"
                  >
                    <QRCodeSVG value={participationUrl} size={200} />
                  </div>

                  <p className="text-white/70 text-sm mb-1">
                    Scannez le QR code ou allez sur :
                  </p>
                  <p className="text-primary-300 text-sm font-mono mb-8 break-all">
                    {participationUrl}
                  </p>
                </>
              )}

              <button
                onClick={handleStart}
                disabled={questions.length === 0}
                className="px-8 py-4 bg-primary-600 hover:bg-primary-700 rounded-xl text-xl font-semibold disabled:opacity-50 transition-colors cursor-pointer"
              >
                🚀 Démarrer ({questions.length} questions)
              </button>
            </div>
          </div>
        )}

        {/* ============================== */}
        {/* ÉCRAN ÉVÉNEMENT TERMINÉ        */}
        {/* ============================== */}
        {isFinished && !isQuizDone && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-white/10 rounded-full mx-auto mb-6 flex items-center justify-center">
              <span className="text-5xl">🏁</span>
            </div>
            <h2 className="text-4xl font-bold mb-4">Événement terminé</h2>
            <p className="text-white/70 mb-8 text-lg">
              L'événement a été mis en pause. Vous pouvez le reprendre là où il en était.
            </p>
            <div className="flex justify-center gap-4">
              <button
                onClick={handleResume}
                className="px-8 py-4 bg-green-600 hover:bg-green-700 rounded-xl text-xl font-semibold transition-colors cursor-pointer"
              >
                ▶️ Reprendre la présentation
              </button>
              <button
                onClick={() => navigate("/dashboard")}
                className="px-8 py-4 bg-white/10 hover:bg-white/20 rounded-xl text-xl font-semibold transition-colors cursor-pointer"
              >
                Retour au dashboard
              </button>
            </div>
          </div>
        )}

        {/* ============================== */}
        {/* VUE LIVE                       */}
        {/* ============================== */}
        {isLive && currentQuestion && !isQuizDone && (
          <div className="space-y-4">
            {/* Titre de la question */}
            <div className="text-center">
              <div className="flex items-center justify-between max-w-2xl mx-auto mb-2 text-white/50 text-sm">
                <span>Question {currentQuestionIndex + 1} / {questions.length}</span>
                {payload.category && (
                  <span className="px-2 py-0.5 bg-indigo-500/30 text-indigo-200 rounded-full text-xs">
                    🏷️ {payload.category}
                  </span>
                )}
                <span>{Math.round(((currentQuestionIndex + 1) / questions.length) * 100)}%</span>
              </div>
              <div className="w-full max-w-2xl mx-auto h-1.5 bg-white/10 rounded-full overflow-hidden mb-3">
                <div
                  className="h-full bg-primary-400 rounded-full transition-all duration-500"
                  style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
                />
              </div>
              <h2 className="text-3xl font-bold mt-1">
                {currentQuestion.title}
              </h2>
              <div className="flex items-center justify-center gap-3 mt-1">
                <span
                  className={`inline-block px-3 py-1 rounded-full text-xs ${
                    currentQuestion.type === "mcq" ? "bg-blue-500/30 text-blue-300"
                    : currentQuestion.type === "trueFalse" ? "bg-teal-500/30 text-teal-300"
                    : currentQuestion.type === "scale" ? "bg-orange-500/30 text-orange-300"
                    : currentQuestion.type === "wordcloud" ? "bg-purple-500/30 text-purple-300"
                    : "bg-green-500/30 text-green-300"
                  }`}
                >
                  {currentQuestion.type === "mcq" ? "QCM"
                    : currentQuestion.type === "trueFalse" ? "Vrai/Faux"
                    : currentQuestion.type === "scale" ? "Curseur"
                    : currentQuestion.type === "wordcloud" ? "Nuage de mots"
                    : "Question ouverte"}
                </span>
                <span className="text-white/40 text-xs">
                  {totalAnswers} réponse(s) sur {participantCount} participant(s)
                </span>
              </div>
            </div>

            {/* Timer display */}
            {timerRemaining !== null && (
              <div className="flex justify-center mb-2">
                <div className={`px-6 py-2 rounded-full text-2xl font-mono font-bold ${timerRemaining <= 5 ? "bg-red-500 animate-pulse" : "bg-white/20"}`}>
                  ⏱ {timerRemaining}s
                </div>
              </div>
            )}

            {/* Boutons d'action centrés */}
            <div className="flex justify-center gap-3 flex-wrap">
              <button
                onClick={handleToggleVoting}
                className={`px-4 py-2 rounded-xl text-sm transition-colors cursor-pointer ${
                  localState.votingOpen
                    ? "bg-green-500 hover:bg-green-600"
                    : "bg-red-500 hover:bg-red-600"
                }`}
              >
                {localState.votingOpen
                  ? "\uD83D\uDD13 Votes ouverts"
                  : "\uD83D\uDD12 Votes fermés"}
              </button>
              <button
                onClick={handleToggleResults}
                className={`px-4 py-2 rounded-xl text-sm transition-colors cursor-pointer ${
                  localState.showResults
                    ? "bg-primary-500 hover:bg-primary-600"
                    : "bg-white/10 hover:bg-white/20"
                }`}
              >
                {localState.showResults
                  ? "\uD83D\uDCCA Masquer résultats"
                  : "\uD83D\uDCCA Afficher résultats"}
              </button>
              <button
                onClick={() => setShowVotes(!showVotes)}
                className={`px-4 py-2 rounded-xl text-sm transition-colors cursor-pointer ${
                  showVotes
                    ? "bg-white/20 hover:bg-white/30"
                    : "bg-white/10 hover:bg-white/20"
                }`}
              >
                {showVotes ? "\uD83D\uDC41\uFE0F Masquer les votes" : "\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8\uFE0F Afficher les votes"}
              </button>
              {/* Stop timer manuel si besoin */}
              {timerRemaining !== null && (
                <button onClick={handleStopTimer}
                  className="px-3 py-2 bg-gray-500 hover:bg-gray-600 rounded-xl text-sm cursor-pointer">
                  ⏹ Stop timer
                </button>
              )}
            </div>

            {/* ===== LAYOUT PRINCIPAL : NAV GAUCHE + CONTENU + NAV DROITE ===== */}
            <div className="flex items-stretch gap-4">
              {/* Bouton Précédent - côté gauche */}
              <div className="flex items-center shrink-0">
                <button
                  onClick={handlePrevious}
                  disabled={currentQuestionIndex === 0}
                  className="px-4 py-6 bg-white/10 hover:bg-white/20 rounded-xl disabled:opacity-30 transition-colors cursor-pointer text-lg"
                  title="Question précédente"
                >
                  ←
                </button>
              </div>

              {/* Contenu central */}
              <div className="flex-1">

            {/* ===== RÉSULTATS QCM / VRAI-FAUX ===== */}
            {(currentQuestion.type === "mcq" || currentQuestion.type === "trueFalse") && (
              <div className="space-y-3">
                {/* Compteur réponses / participants */}
                <div className="flex items-center gap-3 mb-1">
                  <div className="bg-white/10 rounded-full px-4 py-1.5 text-sm">
                    📊 <strong>{totalAnswers}</strong> / {participantCount} ont répondu
                  </div>
                  {participantCount > 0 && (
                    <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary-500 rounded-full transition-all duration-500"
                        style={{ width: `${Math.round((totalAnswers / Math.max(participantCount, 1)) * 100)}%` }}
                      />
                    </div>
                  )}
                </div>

                {mcqResults.map((opt: any, index: number) => {
                  let barColor = COLORS[index % COLORS.length];
                  let badgeColor = COLORS[index % COLORS.length];
                  let borderClass = "";
                  let iconIndicator = null;

                  if (localState.showResults) {
                    if (opt.isCorrect) {
                      barColor = "#22c55e";
                      badgeColor = "#22c55e";
                      borderClass = "ring-4 ring-green-500/50";
                      iconIndicator = (
                        <span className="text-2xl ml-2">✓</span>
                      );
                    } else {
                      barColor = "#ef4444";
                      badgeColor = "#ef4444";
                      borderClass = "ring-2 ring-red-500/30";
                      iconIndicator = (
                        <span className="text-xl ml-2 text-red-400">✗</span>
                      );
                    }
                  }

                  return (
                    <div
                      key={opt.id}
                      className={`relative p-4 rounded-2xl transition-all duration-300 ${
                        localState.showResults
                          ? opt.isCorrect
                            ? "bg-green-500/10"
                            : "bg-red-500/10"
                          : "bg-white/5"
                      } ${borderClass}`}
                    >
                      <div className="flex items-center gap-4">
                        <span
                          className="w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold text-white shrink-0 transition-colors duration-300"
                          style={{ backgroundColor: badgeColor }}
                        >
                          {String.fromCharCode(65 + index)}
                        </span>
                        <div className="flex-1">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium text-lg flex items-center">
                              {opt.text}
                              {localState.showResults && iconIndicator}
                            </span>
                            {/* Afficher les votes seulement si showVotes est true */}
                            {showVotes && (
                              <span className="text-white/70 font-mono">
                                {opt.count} vote{opt.count !== 1 ? "s" : ""}
                                {localState.showResults &&
                                  ` (${opt.percentage}%)`}
                              </span>
                            )}
                          </div>
                          {/* Barre de progression seulement si showVotes est true */}
                          {showVotes && (
                            <div className="h-8 bg-white/10 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all duration-700 ease-out"
                                style={{
                                  width: localState.showResults
                                    ? `${Math.max(opt.percentage, 2)}%`
                                    : `${Math.min(opt.count * 5, 100)}%`,
                                  backgroundColor: barColor,
                                }}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {localState.showResults && (
                  <div className="flex justify-center gap-6 mt-6 text-sm text-white/70">
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 bg-green-500 rounded"></span>
                      Bonne réponse
                    </span>
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 bg-red-500 rounded"></span>
                      Mauvaise réponse
                    </span>
                  </div>
                )}

                {/* Explication pédagogique (mode révision) */}
                {localState.showResults && payload.explanation && (
                  <div className="mt-4 max-w-2xl mx-auto bg-yellow-500/10 border-l-4 border-yellow-400 rounded-xl p-4">
                    <p className="text-yellow-300 text-xs font-bold mb-1">💡 EXPLICATION</p>
                    <p className="text-white/90">{payload.explanation}</p>
                  </div>
                )}
              </div>
            )}

            {/* ===== CURSEUR (scale) ===== */}
            {currentQuestion.type === "scale" && (
              <div className="bg-white/5 rounded-3xl p-6 space-y-4">
                <div className="text-center">
                  <p className="text-white/50 text-sm mb-1">{scaleData?.total ?? 0} réponse(s) sur {participantCount} participant(s)</p>
                  {scaleData?.avg !== null && scaleData?.avg !== undefined && (
                    <p className="text-5xl font-bold text-yellow-300">{scaleData.avg}<span className="text-2xl text-white/50"> / {scaleData.max}</span></p>
                  )}
                </div>
                {scaleData && (
                  <div className="space-y-2">
                    {Array.from({ length: scaleData.max - scaleData.min + 1 }, (_, i) => i + scaleData.min).map(v => {
                      const count = scaleData.results[String(v)] || 0;
                      const pct = scaleData.total > 0 ? Math.round((count / scaleData.total) * 100) : 0;
                      return (
                        <div key={v} className="flex items-center gap-3">
                          <span className="w-8 text-right text-white/70 text-sm">{v}</span>
                          <div className="flex-1 h-8 bg-white/10 rounded-full overflow-hidden">
                            <div className="h-full bg-yellow-400 rounded-full transition-all duration-700" style={{ width: `${Math.max(pct, 2)}%` }} />
                          </div>
                          <span className="w-14 text-sm text-white/70">{count} ({pct}%)</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* ===== NUAGE DE MOTS (adaptatif à la fenêtre) ===== */}
            {currentQuestion.type === "wordcloud" && (
              <div
                className="relative bg-white/5 backdrop-blur-sm rounded-3xl p-6 flex items-center justify-center overflow-hidden"
                style={{ height: "calc(100vh - 300px)", minHeight: "250px", maxHeight: "600px" }}
              >
                {wordCloudData.length === 0 ? (
                  <div className="text-center">
                    <div className="text-6xl mb-4">☁️</div>
                    <p className="text-white/50 text-xl">
                      En attente des mots des participants...
                    </p>
                    <p className="text-white/30 text-sm mt-2">
                      {totalAnswers} réponse(s) sur {participantCount} participant(s)
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2 justify-center items-center w-full h-full overflow-auto p-4" style={{ alignContent: "center" }}>
                    {wordCloudData.map((item, index) => {
                      const maxCount = wordCloudData[0]?.count || 1;
                      const ratio = item.count / maxCount;
                      // Taille adaptative : plus petite base, s'adapte mieux
                      const fontSize = Math.max(14, Math.round(14 + ratio * 48));
                      const color = WORD_COLORS[index % WORD_COLORS.length];

                      return (
                        <span
                          key={item.word}
                          className="inline-block transition-all duration-500 hover:scale-110 cursor-default whitespace-nowrap"
                          style={{
                            fontSize: `${fontSize}px`,
                            color,
                            fontWeight: ratio > 0.5 ? "bold" : "normal",
                            opacity: 0.6 + ratio * 0.4,
                            transform: `rotate(${
                              index % 3 === 0
                                ? 0
                                : index % 3 === 1
                                ? -5
                                : 5
                            }deg)`,
                            padding: "2px 6px",
                            lineHeight: 1.2,
                          }}
                          title={`${item.word}: ${item.count} fois`}
                        >
                          {item.word}
                        </span>
                      );
                    })}
                  </div>
                )}

                {wordCloudData.length > 0 && (
                  <div className="absolute bottom-3 right-4 text-white/30 text-sm">
                    {totalAnswers} réponse(s) sur {participantCount} • {wordCloudData.length} mot(s) unique(s)
                  </div>
                )}
              </div>
            )}

            {/* ===== QUESTIONS OUVERTES ===== */}
            {currentQuestion.type === "open" && (
              <div className="space-y-4 max-w-3xl mx-auto">
                {openAnswers.length === 0 ? (
                  <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 min-h-[300px] flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-6xl mb-4">💬</div>
                      <p className="text-white/50 text-xl">
                        En attente des réponses...
                      </p>
                      <p className="text-white/30 text-sm mt-2">
                        {totalAnswers} réponse(s) sur {participantCount} participant(s)
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {openAnswers.map((answer: string, index: number) => (
                      <div
                        key={index}
                        className="bg-white/10 backdrop-blur-sm rounded-xl p-4 transition-all hover:bg-white/15"
                        style={{
                          borderLeft: `4px solid ${
                            COLORS[index % COLORS.length]
                          }`,
                        }}
                      >
                        <p className="text-white">{answer}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ===== Sprint 3 — QUESTIONS À TROUS ===== */}
            {currentQuestion.type === "fillBlank" && (
              <div className="max-w-4xl mx-auto">
                {!fillBlankData || fillBlankData.totalAnswers === 0 ? (
                  <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 min-h-[300px] flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-6xl mb-4">✏️</div>
                      <p className="text-white/50 text-xl">En attente des réponses…</p>
                      <p className="text-white/30 text-sm mt-2">
                        {totalAnswers} réponse(s) sur {participantCount} participant(s)
                      </p>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Toggle vue */}
                    <div className="flex justify-center gap-2 mb-6">
                      <button
                        onClick={() => setFillBlankView("perBlank")}
                        className={`px-4 py-2 rounded-lg font-medium transition-colors cursor-pointer ${
                          fillBlankView === "perBlank"
                            ? "bg-white text-purple-700"
                            : "bg-white/10 text-white hover:bg-white/20"
                        }`}
                      >
                        📊 Vue par trou
                      </button>
                      <button
                        onClick={() => setFillBlankView("perParticipant")}
                        className={`px-4 py-2 rounded-lg font-medium transition-colors cursor-pointer ${
                          fillBlankView === "perParticipant"
                            ? "bg-white text-purple-700"
                            : "bg-white/10 text-white hover:bg-white/20"
                        }`}
                      >
                        👥 Vue par participant
                      </button>
                    </div>

                    {/* Vue par trou */}
                    {fillBlankView === "perBlank" && (
                      <div className="space-y-4">
                        {fillBlankData.perBlank.map((blank, idx) => {
                          const pct = blank.totalAnswered > 0
                            ? Math.round((blank.correct / blank.totalAnswered) * 100)
                            : 0;
                          return (
                            <div key={idx} className="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
                              <div className="flex items-center justify-between mb-3">
                                <div>
                                  <span className="text-pink-300 font-mono text-sm">Trou {idx + 1}</span>
                                  <h3 className="text-white text-xl font-bold">
                                    Réponse attendue : <span className="text-green-300">{blank.answer}</span>
                                  </h3>
                                  {blank.synonyms.length > 0 && (
                                    <p className="text-white/50 text-xs mt-1">
                                      Synonymes acceptés : {blank.synonyms.join(", ")}
                                    </p>
                                  )}
                                </div>
                                <div className="text-right">
                                  <div className="text-3xl font-bold text-white">{pct}%</div>
                                  <div className="text-white/50 text-sm">
                                    {blank.correct} / {blank.totalAnswered} bonnes
                                  </div>
                                </div>
                              </div>
                              {/* Barre de progression */}
                              <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden mb-3">
                                <div
                                  className="h-full bg-gradient-to-r from-green-500 to-emerald-400 transition-all"
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                              {/* Mauvaises réponses les plus fréquentes */}
                              {blank.wrongAnswers.length > 0 && (
                                <div className="mt-3">
                                  <p className="text-white/60 text-xs uppercase tracking-wide mb-2">
                                    Erreurs fréquentes
                                  </p>
                                  <div className="flex flex-wrap gap-2">
                                    {blank.wrongAnswers.slice(0, 6).map((wrong, wi) => (
                                      <span
                                        key={wi}
                                        className="inline-flex items-center gap-1 px-3 py-1 bg-red-500/20 text-red-200 rounded-full text-sm"
                                      >
                                        ✗ {wrong.text}
                                        {wrong.count > 1 && (
                                          <span className="text-red-300/70 text-xs">×{wrong.count}</span>
                                        )}
                                      </span>
                                    ))}
                                    {blank.wrongAnswers.length > 6 && (
                                      <span className="text-white/40 text-xs self-center">
                                        +{blank.wrongAnswers.length - 6} autres
                                      </span>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Vue par participant */}
                    {fillBlankView === "perParticipant" && (
                      <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 max-h-[60vh] overflow-y-auto">
                        <table className="w-full text-white">
                          <thead className="text-white/70 text-sm border-b border-white/20">
                            <tr>
                              <th className="text-left py-3 px-2">Participant</th>
                              {fillBlankData.perBlank.map((_, i) => (
                                <th key={i} className="text-center py-3 px-2">Trou {i + 1}</th>
                              ))}
                              <th className="text-right py-3 px-2">Score</th>
                            </tr>
                          </thead>
                          <tbody>
                            {fillBlankData.perParticipant
                              .sort((a, b) => b.score - a.score)
                              .map((p, i) => (
                                <tr key={i} className="border-b border-white/10 hover:bg-white/5">
                                  <td className="py-3 px-2 font-medium">{p.nickname}</td>
                                  {p.answers.map((a, ai) => (
                                    <td key={ai} className="text-center py-3 px-2">
                                      {a.userAnswer ? (
                                        <span
                                          className={
                                            a.isCorrect
                                              ? "text-green-300"
                                              : "text-red-300"
                                          }
                                          title={a.userAnswer}
                                        >
                                          {a.isCorrect ? "✓" : "✗"} <span className="text-xs opacity-70">{a.userAnswer}</span>
                                        </span>
                                      ) : (
                                        <span className="text-white/30">—</span>
                                      )}
                                    </td>
                                  ))}
                                  <td className="text-right py-3 px-2 font-bold">
                                    {p.score}/{p.total}
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

              </div>{/* fin contenu central */}

              {/* Bouton Suivant ou Terminer - côté droit */}
              <div className="flex items-center shrink-0">
                {currentQuestionIndex < questions.length - 1 ? (
                  <button
                    onClick={handleNext}
                    className="px-4 py-6 bg-primary-600 hover:bg-primary-700 rounded-xl transition-colors cursor-pointer text-lg"
                    title="Question suivante"
                  >
                    →
                  </button>
                ) : (
                  <button
                    onClick={handleFinishQuiz}
                    className="px-4 py-4 bg-green-600 hover:bg-green-700 rounded-xl transition-colors cursor-pointer text-base font-semibold"
                    title="Terminer le quiz et afficher le classement"
                  >
                    🏁 Terminer
                  </button>
                )}
              </div>
            </div>{/* fin layout principal */}
          </div>
        )}

        {/* Fin du quiz (bouton Terminer cliqué sur dernière question) */}
        {isQuizDone && (
          <div className="text-center py-12">
            <h2 className="text-4xl font-bold mb-4">
              🎉 Quiz Terminé !
            </h2>
            <p className="text-white/70 mb-8">
              Merci à tous les participants
            </p>
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => setShowScoreboard(!showScoreboard)}
                className="px-8 py-4 bg-green-600 hover:bg-green-700 rounded-xl text-xl font-semibold transition-colors cursor-pointer"
              >
                {showScoreboard ? "❌ Masquer" : "🏆 Afficher le classement"}
              </button>
              <button
                onClick={() => navigate("/dashboard")}
                className="px-8 py-4 bg-primary-600 hover:bg-primary-700 rounded-xl text-xl font-semibold transition-colors cursor-pointer"
              >
                Retour au dashboard
              </button>
            </div>

            {/* Classement */}
            {showScoreboard && scoreboard && (
              <div className="mt-8 max-w-2xl mx-auto">
                <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-6">
                  <h3 className="text-2xl font-bold mb-6 text-center">
                    🏆 Classement Final
                  </h3>
                  <div className="space-y-3">
                    {scoreboard.scoreboard.map((entry, index) => (
                      <div
                        key={index}
                        className="bg-white/10 backdrop-blur-sm rounded-xl p-4 flex items-center gap-4"
                        style={{
                          borderLeft: index < 3 ? `4px solid ${index === 0 ? "#FFD700" : index === 1 ? "#C0C0C0" : "#CD7F32"}` : "none",
                        }}
                      >
                        <span className="text-3xl font-bold w-12 text-center">
                          {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}.`}
                        </span>
                        <div className="flex-1">
                          <p className="font-bold text-lg">{entry.nickname}</p>
                          <p className="text-white/70 text-sm">
                            {entry.score} / {entry.totalQuestions} bonnes réponses
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold">
                            {entry.totalQuestions > 0 ? Math.round((entry.score / entry.totalQuestions) * 100) : 0}%
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                  {scoreboard.scoreboard.length === 0 && (
                    <p className="text-white/50 text-center py-8">
                      Aucun participant n'a répondu aux questions QCM
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* ============================== */}
      {/* MODAL QR CODE PLEIN ÉCRAN      */}
      {/* ============================== */}
      {showQRModal && (
        <div
          className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 cursor-pointer"
          onClick={() => setShowQRModal(false)}
        >
          <div className="text-center" onClick={(e) => e.stopPropagation()}>
            <div className="bg-white rounded-3xl p-8 inline-block mb-6">
              <QRCodeSVG value={participationUrl} size={400} />
            </div>
            <p className="text-white text-2xl font-bold mb-2">
              Code : {event.code}
            </p>
            <p className="text-white/70 font-mono text-lg break-all max-w-lg mx-auto">
              {participationUrl}
            </p>
            <button
              onClick={() => setShowQRModal(false)}
              className="mt-6 px-6 py-3 bg-white/20 hover:bg-white/30 rounded-xl text-white cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

      {/* ============================== */}
      {/* AIDE RACCOURCIS CLAVIER (Sprint 2) */}
      {/* ============================== */}
      {showShortcutsHelp && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-[60] p-4"
          onClick={() => setShowShortcutsHelp(false)}
        >
          <div
            className="bg-white text-gray-900 rounded-2xl p-8 max-w-md w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">⌨️ Raccourcis clavier</h2>
              <button
                onClick={() => setShowShortcutsHelp(false)}
                className="text-gray-400 hover:text-gray-900 text-2xl leading-none cursor-pointer"
                title="Fermer (Échap)"
              >
                ×
              </button>
            </div>
            <div className="space-y-3">
              <ShortcutRow keys={["Espace", "→"]} label="Question suivante" />
              <ShortcutRow keys={["←"]} label="Question précédente" />
              <ShortcutRow keys={["R"]} label="Afficher / masquer les résultats" />
              <ShortcutRow keys={["V"]} label="Ouvrir / fermer les votes" />
              <ShortcutRow keys={["F"]} label="Mode présentation (plein écran)" />
              <ShortcutRow keys={["Échap"]} label="Quitter le plein écran" />
              <ShortcutRow keys={["?"]} label="Afficher cette aide" />
            </div>
            <div className="mt-6 pt-4 border-t border-gray-200 text-sm text-gray-600">
              💡 Les raccourcis sont désactivés quand tu tapes dans un champ de texte.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Composant auxiliaire pour afficher une ligne de raccourci
function ShortcutRow({ keys, label }: { keys: string[]; label: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-gray-700">{label}</span>
      <div className="flex items-center gap-1">
        {keys.map((k, i) => (
          <span key={i} className="flex items-center gap-1">
            {i > 0 && <span className="text-gray-400 text-xs">ou</span>}
            <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-semibold text-gray-800 shadow-sm">
              {k}
            </kbd>
          </span>
        ))}
      </div>
    </div>
  );
}
