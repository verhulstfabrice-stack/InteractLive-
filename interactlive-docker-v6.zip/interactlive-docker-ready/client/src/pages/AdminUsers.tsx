import { useState } from "react";
import { trpc } from "../lib/trpc";
import { navigate } from "../App";

type StatusFilter = "all" | "pending" | "approved" | "blocked";

export default function AdminUsers() {
  const { data: currentUser } = trpc.auth.me.useQuery();
  const { data: users, isLoading, error } = trpc.admin.listUsers.useQuery();
  const utils = trpc.useUtils();

  const [filter, setFilter] = useState<StatusFilter>("all");
  const [search, setSearch] = useState("");

  const invalidate = () => {
    utils.admin.listUsers.invalidate();
    utils.admin.pendingCount.invalidate();
  };

  const approveMutation = trpc.admin.approveUser.useMutation({
    onSuccess: invalidate,
    onError: (e) => alert(`Erreur : ${e.message}`),
  });

  const blockMutation = trpc.admin.blockUser.useMutation({
    onSuccess: invalidate,
    onError: (e) => alert(`Erreur : ${e.message}`),
  });

  const deleteMutation = trpc.admin.deleteUser.useMutation({
    onSuccess: invalidate,
    onError: (e) => alert(`Erreur : ${e.message}`),
  });

  const promoteMutation = trpc.admin.promoteToAdmin.useMutation({
    onSuccess: invalidate,
    onError: (e) => alert(`Erreur : ${e.message}`),
  });

  const demoteMutation = trpc.admin.demoteFromAdmin.useMutation({
    onSuccess: invalidate,
    onError: (e) => alert(`Erreur : ${e.message}`),
  });

  // Redirection si non-admin
  if (currentUser && currentUser.role !== "admin") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md text-center shadow-sm">
          <div className="text-5xl mb-4">🔒</div>
          <h1 className="text-2xl font-bold mb-2">Accès réservé</h1>
          <p className="text-gray-600 mb-6">
            Cette page est réservée aux administrateurs.
          </p>
          <button
            onClick={() => navigate("/dashboard")}
            className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium"
          >
            Retour au tableau de bord
          </button>
        </div>
      </div>
    );
  }

  // Filtrage
  const filteredUsers = (users || []).filter((u) => {
    if (filter !== "all" && u.status !== filter) return false;
    if (search && !`${u.name} ${u.email}`.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    return true;
  });

  const statusBadge = (status: string) => {
    if (status === "pending") {
      return (
        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-amber-100 text-amber-800">
          ⏳ En attente
        </span>
      );
    }
    if (status === "approved") {
      return (
        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
          ✓ Approuvé
        </span>
      );
    }
    if (status === "blocked") {
      return (
        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
          ⛔ Bloqué
        </span>
      );
    }
    return <span>{status}</span>;
  };

  const roleBadge = (role: string) => {
    if (role === "admin") {
      return (
        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
          👑 Admin
        </span>
      );
    }
    return (
      <span className="px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-700">
        Utilisateur
      </span>
    );
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("fr-FR", {
      dateStyle: "short",
      timeStyle: "short",
    }).format(new Date(date));
  };

  const stats = {
    total: users?.length ?? 0,
    pending: users?.filter((u) => u.status === "pending").length ?? 0,
    approved: users?.filter((u) => u.status === "approved").length ?? 0,
    blocked: users?.filter((u) => u.status === "blocked").length ?? 0,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="text-gray-500 hover:text-gray-900"
            >
              ← Retour
            </button>
            <h1 className="text-2xl font-bold text-gray-900">👥 Gestion des utilisateurs</h1>
          </div>
          <span className="text-gray-600">{currentUser?.email}</span>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <button
            onClick={() => setFilter("all")}
            className={`p-4 rounded-xl text-left transition ${
              filter === "all" ? "bg-primary-600 text-white" : "bg-white"
            }`}
          >
            <div className="text-3xl font-bold">{stats.total}</div>
            <div className="text-sm opacity-80">Total</div>
          </button>
          <button
            onClick={() => setFilter("pending")}
            className={`p-4 rounded-xl text-left transition ${
              filter === "pending" ? "bg-amber-500 text-white" : "bg-white"
            }`}
          >
            <div className="text-3xl font-bold">{stats.pending}</div>
            <div className="text-sm opacity-80">En attente</div>
          </button>
          <button
            onClick={() => setFilter("approved")}
            className={`p-4 rounded-xl text-left transition ${
              filter === "approved" ? "bg-green-600 text-white" : "bg-white"
            }`}
          >
            <div className="text-3xl font-bold">{stats.approved}</div>
            <div className="text-sm opacity-80">Approuvés</div>
          </button>
          <button
            onClick={() => setFilter("blocked")}
            className={`p-4 rounded-xl text-left transition ${
              filter === "blocked" ? "bg-red-600 text-white" : "bg-white"
            }`}
          >
            <div className="text-3xl font-bold">{stats.blocked}</div>
            <div className="text-sm opacity-80">Bloqués</div>
          </button>
        </div>

        {/* Recherche */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="🔍 Rechercher par nom ou email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary-500"
          />
        </div>

        {/* Alerte pour les comptes en attente */}
        {stats.pending > 0 && filter !== "pending" && (
          <div className="mb-4 p-4 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between">
            <div>
              <strong className="text-amber-900">
                {stats.pending} compte{stats.pending > 1 ? "s" : ""} en attente de validation
              </strong>
              <p className="text-sm text-amber-800 mt-1">
                Ces utilisateurs ne peuvent pas accéder à l'application tant qu'ils ne sont pas approuvés.
              </p>
            </div>
            <button
              onClick={() => setFilter("pending")}
              className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 font-medium whitespace-nowrap"
            >
              Voir les demandes
            </button>
          </div>
        )}

        {/* Liste */}
        {isLoading && (
          <div className="bg-white rounded-2xl p-12 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-4 border-primary-500 border-t-transparent mx-auto mb-4"></div>
            <p className="text-gray-500">Chargement...</p>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-red-800">
            Erreur : {error.message}
          </div>
        )}

        {!isLoading && !error && filteredUsers.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center">
            <div className="text-5xl mb-4">🔍</div>
            <p className="text-gray-500">Aucun utilisateur ne correspond aux filtres.</p>
          </div>
        )}

        {!isLoading && filteredUsers.length > 0 && (
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">Utilisateur</th>
                  <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">Rôle</th>
                  <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">Statut</th>
                  <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">Événements</th>
                  <th className="text-left px-4 py-3 text-sm font-semibold text-gray-700">Inscrit le</th>
                  <th className="text-right px-4 py-3 text-sm font-semibold text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((u) => {
                  const isSelf = u.id === currentUser?.id;
                  const isPending = u.status === "pending";
                  const isApproved = u.status === "approved";
                  const isBlocked = u.status === "blocked";
                  const isAdmin = u.role === "admin";

                  return (
                    <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-900">
                          {u.name}
                          {isSelf && <span className="ml-2 text-xs text-gray-500">(vous)</span>}
                        </div>
                        <div className="text-sm text-gray-500">{u.email}</div>
                      </td>
                      <td className="px-4 py-3">{roleBadge(u.role)}</td>
                      <td className="px-4 py-3">{statusBadge(u.status)}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">{u._count.events}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{formatDate(u.createdAt)}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2 justify-end flex-wrap">
                          {isPending && !isSelf && (
                            <button
                              onClick={() => approveMutation.mutate({ userId: u.id })}
                              disabled={approveMutation.isPending}
                              className="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 font-medium disabled:opacity-50"
                            >
                              ✓ Approuver
                            </button>
                          )}

                          {isApproved && !isSelf && (
                            <button
                              onClick={() => {
                                if (confirm(`Bloquer l'accès de ${u.email} ?`)) {
                                  blockMutation.mutate({ userId: u.id });
                                }
                              }}
                              disabled={blockMutation.isPending}
                              className="px-3 py-1.5 bg-red-100 text-red-700 text-sm rounded-lg hover:bg-red-200 font-medium disabled:opacity-50"
                            >
                              ⛔ Bloquer
                            </button>
                          )}

                          {isBlocked && !isSelf && (
                            <button
                              onClick={() => approveMutation.mutate({ userId: u.id })}
                              disabled={approveMutation.isPending}
                              className="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 font-medium disabled:opacity-50"
                            >
                              ✓ Réactiver
                            </button>
                          )}

                          {isApproved && !isAdmin && !isSelf && (
                            <button
                              onClick={() => promoteMutation.mutate({ userId: u.id })}
                              disabled={promoteMutation.isPending}
                              className="px-3 py-1.5 bg-purple-100 text-purple-700 text-sm rounded-lg hover:bg-purple-200 font-medium disabled:opacity-50"
                              title="Promouvoir administrateur"
                            >
                              👑 Promouvoir
                            </button>
                          )}

                          {isAdmin && !isSelf && (
                            <button
                              onClick={() => {
                                if (confirm(`Retirer les droits d'administration de ${u.email} ?`)) {
                                  demoteMutation.mutate({ userId: u.id });
                                }
                              }}
                              disabled={demoteMutation.isPending}
                              className="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200 font-medium disabled:opacity-50"
                              title="Retirer les droits admin"
                            >
                              Rétrograder
                            </button>
                          )}

                          {!isSelf && (
                            <button
                              onClick={() => {
                                if (
                                  confirm(
                                    `Supprimer définitivement le compte de ${u.email} ?\n` +
                                    `Cela supprimera aussi ses ${u._count.events} événement(s) et toutes les réponses associées.`
                                  )
                                ) {
                                  deleteMutation.mutate({ userId: u.id });
                                }
                              }}
                              disabled={deleteMutation.isPending}
                              className="px-3 py-1.5 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 font-medium disabled:opacity-50"
                              title="Supprimer le compte"
                            >
                              🗑️
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}
