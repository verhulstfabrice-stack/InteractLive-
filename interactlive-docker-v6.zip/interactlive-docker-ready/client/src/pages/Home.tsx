import { navigate } from "../App";
import { trpc } from "../lib/trpc";

export default function Home() {
  const { data: user } = trpc.auth.me.useQuery();

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary-600">⚡ InteractLive</h1>
          <div className="flex gap-4">
            <button
              onClick={() => navigate("/join")}
              className="px-4 py-2 text-gray-700 hover:text-primary-600 font-medium"
            >
              Rejoindre
            </button>
            {user ? (
              <button
                onClick={() => navigate("/dashboard")}
                className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium"
              >
                Dashboard →
              </button>
            ) : (
              <button
                onClick={() => navigate("/login")}
                className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium"
              >
                Connexion
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <main className="max-w-6xl mx-auto px-4 py-20 text-center">
        <div className="inline-block px-4 py-2 bg-primary-100 text-primary-700 rounded-full text-sm font-medium mb-6">
          ⚡ Plateforme d'interaction en temps réel
        </div>
        
        <h2 className="text-5xl font-bold text-gray-900 mb-4">
          Engagez votre audience
          <br />
          <span className="text-primary-600">en temps réel</span>
        </h2>
        
        <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
          Créez des sondages interactifs, des nuages de mots et des questions ouvertes.
          Vos participants répondent instantanément depuis leur smartphone.
        </p>

        <div className="flex gap-4 justify-center">
          <button
            onClick={() => navigate(user ? "/dashboard" : "/login")}
            className="px-8 py-4 bg-primary-600 text-white rounded-xl hover:bg-primary-700 font-semibold text-lg shadow-lg shadow-primary-500/30"
          >
            Commencer gratuitement →
          </button>
          <button
            onClick={() => navigate("/join")}
            className="px-8 py-4 bg-white text-gray-700 rounded-xl hover:bg-gray-50 font-semibold text-lg border border-gray-200"
          >
            Rejoindre un événement
          </button>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="bg-white rounded-2xl p-8 shadow-sm">
            <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center text-2xl mb-4 mx-auto">
              📊
            </div>
            <h3 className="text-xl font-semibold mb-2">QCM Interactifs</h3>
            <p className="text-gray-600">
              Créez des questions à choix multiples avec résultats en temps réel
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-sm">
            <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center text-2xl mb-4 mx-auto">
              ☁️
            </div>
            <h3 className="text-xl font-semibold mb-2">Nuages de mots</h3>
            <p className="text-gray-600">
              Collectez les idées de votre audience sous forme visuelle
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-sm">
            <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center text-2xl mb-4 mx-auto">
              💬
            </div>
            <h3 className="text-xl font-semibold mb-2">Questions ouvertes</h3>
            <p className="text-gray-600">
              Recueillez des réponses détaillées de vos participants
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
