import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ParticipantSession {
  sessionId: string;
  participantId: number;
  nickname: string;
  eventId: number;
  eventCode: string;
}

interface StoreState {
  participantSession: ParticipantSession | null;
  setParticipantSession: (session: ParticipantSession | null) => void;
  clearSession: () => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      participantSession: null,
      setParticipantSession: (session) => set({ participantSession: session }),
      clearSession: () => set({ participantSession: null }),
    }),
    {
      name: "interactlive-storage",
    }
  )
);
