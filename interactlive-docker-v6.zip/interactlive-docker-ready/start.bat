@echo off
title InteractLive - Serveur Local
color 0A

echo.
echo ========================================
echo    InteractLive - Demarrage
echo ========================================
echo.

:: Verifier si Node.js est installe
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERREUR] Node.js n'est pas installe!
    echo Telechargez-le sur: https://nodejs.org/
    pause
    exit /b 1
)

:: Verifier si les dependances sont installees
if not exist "node_modules" (
    echo [INFO] Dependances non trouvees, installation en cours...
    echo [INFO] Cela peut prendre 1-2 minutes...
    call npm install
    if %ERRORLEVEL% NEQ 0 (
        echo [ERREUR] Echec de l'installation
        pause
        exit /b 1
    )
    echo [INFO] Generation du client Prisma...
    call node_modules\.bin\prisma generate
)

:: Verifier si la base de donnees existe
if not exist "data" mkdir data
if not exist "data\interactlive.db" (
    echo [INFO] Initialisation de la base de donnees...
    call node_modules\.bin\prisma generate
    call node_modules\.bin\prisma db push
)

:: Demarrer le serveur
echo.
echo [INFO] Demarrage du serveur...
echo [INFO] Le navigateur va s'ouvrir automatiquement...
echo.

:: Ouvrir le navigateur apres 5 secondes
start /b cmd /c "timeout /t 5 /nobreak >nul && start http://localhost:3000"

:: Lancer le serveur (API + Frontend)
call npm run dev

pause
