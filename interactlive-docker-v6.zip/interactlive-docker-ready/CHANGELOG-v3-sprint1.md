# 🎯 v3 — Sprint 1 : Système de rôles et validation des comptes

## Ce qui change concrètement

### Pour toi (admin)
- Au premier démarrage de la v3, **ton compte existant `verhulst.fabrice@gmail.com` est automatiquement détecté comme admin approuvé** (c'est le seul compte déjà créé).
- Un nouveau bouton **"👥 Utilisateurs"** apparaît en haut de ton dashboard.
- Un **badge rouge** t'indique combien de demandes de compte sont en attente.
- Sur la page `/admin/users`, tu peux : approuver, bloquer, réactiver, supprimer des comptes, promouvoir quelqu'un admin, ou le rétrograder.

### Pour un nouveau visiteur qui s'inscrit
- Il entre son email et mot de passe sur `/login` comme avant.
- Mais au lieu d'être connecté, il voit maintenant un **message orange** :
  > ⏳ **Compte en attente de validation**
  > Votre demande a bien été enregistrée. Un administrateur doit approuver votre compte avant que vous puissiez vous connecter.
- Son compte est créé mais avec le statut `pending`.
- Il ne peut pas se connecter tant que tu ne l'as pas approuvé.

### Pour un compte bloqué
- À la connexion, il voit :
  > ⛔ **Compte bloqué**
  > L'accès à votre compte a été suspendu. Contactez l'administrateur pour plus d'informations.

---

## Migration base de données

Le schéma Prisma a été modifié : ajout du champ `status` à la table `User`.

**Valeur par défaut : `pending`**.

⚠️ Au premier démarrage, les comptes **déjà existants** dans la base seront en statut `pending`. Pour débloquer ça, il y a **une action à faire une seule fois** (voir le guide de déploiement ci-dessous).

---

## Nouvelles routes API (admin uniquement)

- `admin.listUsers` — liste tous les utilisateurs avec leur statut et nombre d'événements
- `admin.pendingCount` — nombre de comptes en attente (pour badge)
- `admin.approveUser` — approuver un compte
- `admin.blockUser` — bloquer un compte
- `admin.deleteUser` — supprimer un compte (+ ses événements)
- `admin.promoteToAdmin` — promouvoir en admin
- `admin.demoteFromAdmin` — rétrograder un admin (impossible s'il n'y a qu'un admin)

---

## Sécurités mises en place

- Un admin ne peut **pas** se bloquer, se supprimer ou se rétrograder lui-même (risque de se déconnecter de son propre système)
- On ne peut **pas** rétrograder le dernier admin (sinon personne ne peut plus gérer les utilisateurs)
- Le champ `status` est vérifié à **chaque requête API protégée** : si ton statut change pendant ta session, tu es effectivement bloqué au prochain clic
- Un utilisateur `pending` voit une erreur explicite "Votre compte est en attente de validation"

---

## Aucun patch de sécurité antérieur n'a été cassé

- ✅ `trust proxy` toujours actif
- ✅ Cookies `Secure` en production
- ✅ CORS restreint via `ALLOWED_ORIGINS`
- ✅ Mots de passe obligatoires en production
- ✅ `PUBLIC_URL` toujours pris en compte pour le QR code
