# ✏️ v6 — Sprint 3 : Questions à trous

## Ce qui est nouveau

### Un nouveau type de question : "Texte à trous"

Dans l'éditeur de questions, un nouveau bouton **✏️ À trous** apparaît à côté
des types existants (QCM, Vrai/Faux, Curseur, Nuage, Ouverte).

**Principe** : tu écris une phrase, tu places des trous avec la syntaxe `{}`,
et pour chaque trou tu indiques la réponse attendue + des synonymes acceptés.

### Exemple concret pour la TP FPA

**Énoncé que tu tapes dans l'éditeur :**

> La pédagogie de `{}` postule que l'apprentissage se fait par `{}` et l'expérience.

**L'éditeur détecte automatiquement 2 trous** et affiche 2 cartes en dessous :

```
┌─ Trou n°1 ─────────────────────────────┐
│ Réponse attendue : [Dewey         ]    │
│ Synonymes :                             │
│   [John Dewey         ] [✕]            │
│   [J. Dewey           ] [✕]            │
│   [+ Ajouter un synonyme]               │
└─────────────────────────────────────────┘

┌─ Trou n°2 ─────────────────────────────┐
│ Réponse attendue : [action        ]    │
│ Synonymes :                             │
│   [l'action           ] [✕]            │
│   [+ Ajouter un synonyme]               │
└─────────────────────────────────────────┘
```

### Côté participant : interface naturelle

Le participant voit :

> La pédagogie de [______] postule que l'apprentissage se fait par [______] et l'expérience.

Les `[______]` sont des mini-champs inline, qui s'élargissent au fur et à mesure
de la saisie. Le bouton "Envoyer mes réponses" n'apparaît que quand tous les
trous sont remplis.

### Validation tolérante (insensible à la casse, accents, espaces)

Toutes ces réponses sont considérées correctes pour le mot "Dewey" :
- `Dewey` ✓
- `dewey` ✓ (insensible à la casse)
- `DEWEY` ✓
- ` Dewey ` ✓ (espaces ignorés)
- `John Dewey` ✓ (synonyme)
- `john dewey` ✓ (synonyme + casse)

Pour un mot avec accent (ex. réponse attendue `réflexion`) :
- `réflexion` ✓
- `reflexion` ✓ (accent ignoré)
- `Réflexion` ✓

**Mode strict orthographique** : `Dewy`, `Devvey`, `Deweuy`... sont rejetés.
Si tu veux accepter ces variantes, ajoute-les comme synonymes.

### Côté présentateur : 2 vues complémentaires

Les résultats live affichent un toggle **"📊 Vue par trou"** ou **"👥 Vue par participant"**.

#### Vue par trou
Pour chaque trou : pourcentage de bonnes réponses, barre de progression, et
**top des erreurs fréquentes** (très utile pour analyser les confusions
classiques de la cohorte). Exemple :

```
Trou 1 — Réponse attendue : Dewey
[████████████░░░░░░░░░░] 60% (9 / 15 bonnes)
Erreurs fréquentes : ✗ Piaget ×3   ✗ Bruner ×2   ✗ Bloom ×1
```

Cette vue est **précieuse pédagogiquement** : tu peux immédiatement voir si
une majorité s'est trompée sur un même concept, et y consacrer un temps de
clarification.

#### Vue par participant
Tableau récapitulatif avec, pour chaque apprenant, ses réponses précises et
son score :

```
Participant  | Trou 1   | Trou 2     | Score
─────────────┼──────────┼────────────┼─────
Marie        | ✓ Dewey  | ✓ action   | 2/2
Paul         | ✗ Piaget | ✓ action   | 1/2
Léa          | ✓ Dewey  | ✗ pratique | 1/2
```

Utile pour identifier qui a besoin d'aide individuelle.

---

## 🎯 Cas d'usage typiques pour ta TP FPA

**Questions sur les théoriciens (CP1, CP9...)** :
> Le pédagogue suisse `{Piaget}` a théorisé les `{stades}` du développement cognitif.

**Questions sur le REAC FPA** :
> L'AT `{1}` concerne la `{conception}` de séquences pédagogiques.

**Questions sur la taxonomie de Bloom** :
> Le niveau le plus haut de la taxonomie révisée est `{créer}` (ou Création).

**Questions sur les méthodes d'évaluation** :
> Une évaluation faite avant la formation est dite `{diagnostique}`, pendant elle
> est `{formative}`, et après elle est `{sommative}`.

---

## Aucune régression

- ✅ Tous les types de questions existants fonctionnent comme avant
- ✅ Tous les patches de sécurité v3, v4 conservés
- ✅ Tous les raccourcis clavier v5 (Espace, F, R, V, ?...) fonctionnent aussi
  pour les questions à trous
- ✅ Le mode plein écran s'active sur ce type de question

## Impact technique

- **Pas de migration DB** : on stocke la définition des trous dans le champ
  `payload` JSON existant
- **Pas de nouvelle dépendance npm**
- **Build Docker** : ~2 min grâce au cache

---

## Limites connues / à améliorer plus tard

- **Export Excel** : la v6 inclut déjà les questions à trous dans l'export
  basique, mais l'export PDF (Sprint 4 / v7) sera plus visuel
- **Import Moodle XML** : les questions à trous Moodle (type `cloze`) ne sont
  pas encore importées automatiquement. À faire dans un sprint dédié si tu en
  as besoin
- **Interface mobile** : les mini-champs inline sont optimisés pour
  smartphone, mais sur les très petites largeurs (< 360 px), la phrase peut
  passer à la ligne au milieu d'un mot. Acceptable mais pas parfait

## Prochain sprint

**Sprint 4 (v7)** : Export PDF avec graphiques pour archivage et compte-rendu
qualité Qualiopi. Estimé à ~2h de dev.
