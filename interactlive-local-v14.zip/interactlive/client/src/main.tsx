import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink } from "@trpc/client";
import { trpc } from "./lib/trpc";
import App from "./App";
import "./index.css";
import superjson from "superjson";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

// Déterminer l'URL de l'API dynamiquement
function getApiUrl(): string {
  const host = window.location.hostname;
  
  // Si on accède via localhost ou 127.0.0.1, utiliser le proxy Vite
  if (host === "localhost" || host === "127.0.0.1") {
    return "/api/trpc";
  }
  
  // Sinon, connexion directe au backend sur le port 3001
  return `http://${host}:3001/api/trpc`;
}

const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: getApiUrl(),
      transformer: superjson,
    }),
  ],
});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <App />
      </QueryClientProvider>
    </trpc.Provider>
  </React.StrictMode>
);
