import { useState, useEffect } from "react";
import { trpc } from "../lib/trpc";
import { navigate } from "../App";

export default function Login() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [error, setError] = useState("");

  const utils = trpc.useUtils();

  // On ne lance la requête qu'après un minimum de contenu pour éviter les appels pour "a@b.c"
  const emailLooksValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const { data: emailStatus, isLoading: checking } = trpc.auth.checkEmail.useQuery(
    { email: email.trim().toLowerCase() },
    { enabled: emailLooksValid, retry: false }
  );

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      navigate("/dashboard");
    },
    onError: (err) => { setError(err.message); },
  });

  useEffect(() => {
    setPassword("");
    setPasswordConfirm("");
    setError("");
  }, [email]);

  const exists = emailStatus?.exists === true;
  const hasPassword = emailStatus?.hasPassword === true;
  const isNew = emailLooksValid && emailStatus?.exists === false;

  // Trois cas distincts :
  // 1. Compte existant AVEC mot de passe → champ mdp obligatoire, bouton "Se connecter"
  // 2. Compte existant SANS mot de passe → bouton "Se connecter" direct, champ mdp optionnel
  // 3. Nouveau compte → champ nom + champ mdp optionnel + bouton "Créer le compte"
  const mode: "login-with-pwd" | "login-no-pwd" | "create" | "wait" =
    !emailLooksValid ? "wait"
    : exists && hasPassword ? "login-with-pwd"
    : exists && !hasPassword ? "login-no-pwd"
    : "create";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailLooksValid) { setError("Veuillez entrer un email valide"); return; }

    if (mode === "login-with-pwd" && !password) {
      setError("Ce compte nécessite un mot de passe");
      return;
    }

    // Nouveau compte ou ajout de mdp sur compte existant : valider la confirmation
    if (password && (mode === "create" || mode === "login-no-pwd")) {
      if (password.length < 6) { setError("Le mot de passe doit faire au moins 6 caractères"); return; }
      if (password !== passwordConfirm) { setError("Les mots de passe ne correspondent pas"); return; }
    }

    loginMutation.mutate({
      email: email.trim().toLowerCase(),
      name: name || undefined,
      password: password || undefined,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-primary-600 mb-2">⚡ InteractLive</h1>
          <p className="text-gray-600">
            {mode === "create" ? "Créer un compte" : "Se connecter"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              placeholder="votre@email.com" autoComplete="email" autoFocus />
            {checking && emailLooksValid && (
              <p className="text-xs text-gray-400 mt-1">Vérification du compte...</p>
            )}
          </div>

          {/* Message d'état selon le cas */}
          {mode === "login-with-pwd" && (
            <div className="bg-blue-50 border-l-4 border-blue-400 px-3 py-2 rounded text-sm text-blue-800">
              👋 Bon retour ! Entrez votre mot de passe pour vous connecter.
            </div>
          )}
          {mode === "login-no-pwd" && (
            <div className="bg-green-50 border-l-4 border-green-400 px-3 py-2 rounded text-sm text-green-800">
              ✓ Compte trouvé. Vous pouvez vous connecter directement, ou sécuriser votre compte avec un mot de passe.
            </div>
          )}
          {mode === "create" && (
            <div className="bg-yellow-50 border-l-4 border-yellow-400 px-3 py-2 rounded text-sm text-yellow-800">
              ✨ Aucun compte n'existe avec cet email. Un nouveau compte va être créé.
            </div>
          )}

          {/* Nom uniquement en mode création */}
          {mode === "create" && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom <span className="text-gray-400 font-normal">(optionnel)</span>
              </label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="Votre nom" />
            </div>
          )}

          {/* Mot de passe selon le mode */}
          {mode === "login-with-pwd" && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Mot de passe <span className="text-red-500">*</span>
              </label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="Votre mot de passe"
                autoComplete="current-password" autoFocus />
            </div>
          )}

          {(mode === "login-no-pwd" || mode === "create") && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Mot de passe <span className="text-gray-400 font-normal">(recommandé, facultatif)</span>
              </label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                placeholder="Choisissez un mot de passe (6+ caractères)"
                autoComplete="new-password" />
              {password && (
                <input type="password" value={passwordConfirm} onChange={(e) => setPasswordConfirm(e.target.value)}
                  className="w-full px-4 py-3 mt-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  placeholder="Confirmez le mot de passe" autoComplete="new-password" />
              )}
              {!password && (
                <p className="text-xs text-gray-500 mt-1">
                  Laissez vide pour {mode === "create" ? "créer un compte sans" : "vous connecter sans"} mot de passe.
                </p>
              )}
            </div>
          )}

          {error && <p className="text-red-500 text-sm">{error}</p>}

          <button type="submit" disabled={loginMutation.isPending || !emailLooksValid}
            className="w-full py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-semibold disabled:opacity-50">
            {loginMutation.isPending
              ? "Connexion..."
              : mode === "create" ? "Créer le compte"
              : mode === "login-with-pwd" ? "Se connecter"
              : mode === "login-no-pwd" ? (password ? "Se connecter et sécuriser" : "Se connecter")
              : "Se connecter"}
          </button>
        </form>

        <button onClick={() => navigate("/")}
          className="w-full mt-4 py-2 text-gray-600 hover:text-primary-600">
          ← Retour à l'accueil
        </button>
      </div>
    </div>
  );
}
