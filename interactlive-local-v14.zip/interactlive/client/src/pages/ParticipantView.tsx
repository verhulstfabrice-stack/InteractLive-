import { useEffect, useState, useMemo } from "react";
import { trpc } from "../lib/trpc";
import { useSocket } from "../hooks/useSocket";
import { useStore } from "../stores/useStore";
import { navigate } from "../App";

const COLORS = ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#06b6d4"];

export default function ParticipantView({ eventId, participantId }: { eventId: number; participantId: number }) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [wordInput, setWordInput] = useState("");
  const [sentWords, setSentWords] = useState<string[]>([]);
  const [openAnswer, setOpenAnswer] = useState("");
  const [scaleValue, setScaleValue] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [myScore, setMyScore] = useState({ correct: 0, total: 0 });
  const [showParticipantScoreboard, setShowParticipantScoreboard] = useState(false);

  const { data: scoreboard } = trpc.event.getScoreboard.useQuery(
    { id: eventId },
    { enabled: showParticipantScoreboard }
  );

  const { participantSession, clearSession } = useStore();
  const { data: participant, isLoading: isLoadingParticipant, error: participantError } = trpc.participant.getBySession.useQuery(
    { sessionId: participantSession?.sessionId || "" },
    { enabled: !!participantSession?.sessionId, retry: false }
  );

  const { isConnected, eventState, joinRoom, submitAnswer } = useSocket();

  const { data: eventData, error: eventError } = trpc.event.getByCode.useQuery(
    { code: participant?.event?.code || "" },
    { enabled: !!participant?.event?.code, retry: false }
  );

  const event = participant?.event;
  const currentQuestionIndex = eventState?.currentQuestion || 0;

  const currentQuestion = useMemo(() => {
    if (!eventData?.questions) return null;
    return eventData.questions[currentQuestionIndex] || null;
  }, [eventData?.questions, currentQuestionIndex]);

  const { data: existingAnswer, refetch: refetchAnswer } = trpc.answer.getForQuestion.useQuery(
    { questionId: currentQuestion?.id || 0, participantId },
    { enabled: !!currentQuestion?.id && participantId > 0 }
  );

  const { options, correctAnswerId, explanation } = useMemo(() => {
    if (!currentQuestion?.payload) return { options: [], correctAnswerId: null, explanation: null };
    try {
      const payload = JSON.parse(currentQuestion.payload);
      const opts = payload.options || [];
      const correctId = payload.correctAnswerId || opts.find((o: any) => o.isCorrect)?.id || null;
      return { options: opts, correctAnswerId: correctId, explanation: payload.explanation || null };
    } catch {
      return { options: [], correctAnswerId: null, explanation: null };
    }
  }, [currentQuestion?.payload]);

  const scaleConfig = useMemo(() => {
    if (currentQuestion?.type !== "scale" || !currentQuestion.payload) return { min: 1, max: 5 };
    try {
      const p = JSON.parse(currentQuestion.payload);
      return { min: p.min ?? 1, max: p.max ?? 5 };
    } catch {
      return { min: 1, max: 5 };
    }
  }, [currentQuestion]);

  const answerFeedback = useMemo(() => {
    if (!hasAnswered || !selectedOption || !correctAnswerId) return null;
    if (currentQuestion?.type !== "mcq" && currentQuestion?.type !== "trueFalse") return null;
    return selectedOption === correctAnswerId ? "correct" : "incorrect";
  }, [hasAnswered, selectedOption, correctAnswerId, currentQuestion?.type]);

  useEffect(() => {
    if (participant?.event?.code && participantSession) {
      joinRoom(participant.event.code, participantId, participantSession.nickname);
    }
  }, [participant?.event?.code, participantId, participantSession, joinRoom]);

  // Timer countdown — démarre depuis timerDuration pour éviter l'écart d'horloge
  useEffect(() => {
    if (!eventState?.timerEndAt || !eventState?.timerDuration) {
      setTimeLeft(null);
      return;
    }
    // On part de la durée exacte définie, et on décrémente chaque seconde
    setTimeLeft(eventState.timerDuration);
    let current = eventState.timerDuration;
    const interval = setInterval(() => {
      current -= 1;
      if (current <= 0) {
        setTimeLeft(0);
        clearInterval(interval);
      } else {
        setTimeLeft(current);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [eventState?.timerEndAt]);

  // Reset quand question change
  useEffect(() => {
    setSelectedOption(null);
    setHasAnswered(false);
    setWordInput("");
    setSentWords([]);
    setOpenAnswer("");
    setScaleValue(null);
    if (currentQuestion?.id) refetchAnswer();
  }, [eventState?.currentQuestion, currentQuestion?.id, refetchAnswer]);

  // Restaurer l'état depuis réponse existante
  useEffect(() => {
    if (!existingAnswer) return;
    const content = existingAnswer.content;
    if ((currentQuestion?.type === "mcq" || currentQuestion?.type === "trueFalse") && content.selectedOptionId) {
      setSelectedOption(content.selectedOptionId);
      setHasAnswered(true);
    } else if (currentQuestion?.type === "wordcloud" && content.words) {
      setSentWords(content.words);
    } else if (currentQuestion?.type === "open" && content.text) {
      setOpenAnswer(content.text);
      setHasAnswered(true);
    } else if (currentQuestion?.type === "scale" && content.value !== undefined) {
      setScaleValue(content.value);
      setHasAnswered(true);
    }
  }, [existingAnswer, currentQuestion?.type]);

  const handleSelectOption = (optionId: string) => {
    if (!eventState?.votingOpen || hasAnswered) return;
    setSelectedOption(optionId);
  };

  const handleSubmitMcq = () => {
    if (!selectedOption || !event?.code || !currentQuestion) return;
    submitAnswer(event.code, currentQuestion.id, participantId, { selectedOptionId: selectedOption });
    setHasAnswered(true);
    if (correctAnswerId) {
      setMyScore(prev => ({
        correct: prev.correct + (selectedOption === correctAnswerId ? 1 : 0),
        total: prev.total + 1,
      }));
    }
  };

  const handleSubmitWords = () => {
    if (!wordInput.trim() || !event?.code || !currentQuestion) return;
    const words = wordInput.split(/[,\s]+/).filter(w => w.trim());
    submitAnswer(event.code, currentQuestion.id, participantId, { words, append: true });
    setSentWords(prev => [...prev, ...words]);
    setWordInput("");
  };

  const handleSubmitOpen = () => {
    if (!openAnswer.trim() || !event?.code || !currentQuestion) return;
    submitAnswer(event.code, currentQuestion.id, participantId, { text: openAnswer });
    setHasAnswered(true);
  };

  const handleSubmitScale = () => {
    if (scaleValue === null || !event?.code || !currentQuestion) return;
    submitAnswer(event.code, currentQuestion.id, participantId, { value: scaleValue });
    setHasAnswered(true);
  };

  // Pas de session locale → renvoyer à la page de connexion
  if (!participantSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-500 to-primary-700 p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md text-center">
          <div className="text-5xl mb-4">🔌</div>
          <h2 className="text-2xl font-bold mb-2 text-gray-800">Session expirée</h2>
          <p className="text-gray-600 mb-6">Vous n'êtes pas connecté à un événement.</p>
          <button onClick={() => navigate("/join")}
            className="px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold">
            Rejoindre un événement
          </button>
        </div>
      </div>
    );
  }

  // Erreur : événement introuvable ou participant invalide
  if (participantError || eventError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-500 to-primary-700 p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md text-center">
          <div className="text-5xl mb-4">😕</div>
          <h2 className="text-2xl font-bold mb-2 text-gray-800">Événement introuvable</h2>
          <p className="text-gray-600 mb-6">
            Cet événement a été supprimé ou votre session a expiré.
          </p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => { clearSession(); navigate("/join"); }}
              className="px-5 py-3 bg-primary-600 text-white rounded-xl font-semibold">
              Rejoindre un autre événement
            </button>
            <button onClick={() => { clearSession(); navigate("/"); }}
              className="px-5 py-3 border border-gray-300 rounded-xl font-medium">
              Accueil
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!participant || !event || isLoadingParticipant) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-500 to-primary-700">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent mx-auto mb-4"></div>
          <p>Connexion en cours...</p>
        </div>
      </div>
    );
  }

  const isWaiting = !eventState || eventState.status === "waiting" || eventState.status === "draft";
  const isEnded = eventState?.status === "finished";
  const timerUrgent = timeLeft !== null && timeLeft <= 10;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-500 to-primary-700 text-white">
      <header className="bg-black/20 backdrop-blur-sm">
        <div className="max-w-lg mx-auto px-4 py-3 flex justify-between items-center">
          <div>
            <h1 className="font-bold">{event.title}</h1>
            <p className="text-white/70 text-sm">{participantSession?.nickname}</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs ${isConnected ? "bg-green-500" : "bg-red-500"}`}>
            {isConnected ? "●" : "○"}
          </span>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-8">

        {isWaiting && (
          <div className="text-center py-12">
            <div className="animate-pulse">
              <div className="w-24 h-24 bg-white/20 rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-4xl">⏳</span>
              </div>
            </div>
            <h2 className="text-2xl font-bold mb-2">En attente...</h2>
            <p className="text-white/70">Le présentateur va bientôt démarrer l'événement</p>
          </div>
        )}

        {isEnded && (
          <div className="py-8">
            <div className="text-center mb-8">
              <div className="w-24 h-24 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-5xl">🎉</span>
              </div>
              <h2 className="text-3xl font-bold mb-2">Quiz Terminé !</h2>
              <p className="text-white/70">Merci pour ta participation</p>
            </div>

            {/* Score personnel */}
            {myScore.total > 0 && (
              <div className="bg-white/10 rounded-2xl p-6 mb-6 text-center">
                <p className="text-white/70 text-sm mb-1">Ton score</p>
                <p className="text-5xl font-bold mb-1">{myScore.correct} / {myScore.total}</p>
                <p className="text-white/70 text-sm">
                  {Math.round((myScore.correct / myScore.total) * 100)}% de bonnes réponses
                </p>
              </div>
            )}

            {/* Bouton classement */}
            <button
              onClick={() => setShowParticipantScoreboard(s => !s)}
              className="w-full py-4 bg-yellow-400 text-yellow-900 rounded-xl font-bold text-lg mb-4 transition-transform hover:scale-[1.02]"
            >
              {showParticipantScoreboard ? "❌ Masquer le classement" : "🏆 Voir le classement"}
            </button>

            {/* Classement */}
            {showParticipantScoreboard && scoreboard && (
              <div className="bg-white/10 rounded-2xl p-5">
                <h3 className="text-xl font-bold text-center mb-4">🏆 Classement Final</h3>
                {scoreboard.scoreboard.length === 0 ? (
                  <p className="text-white/50 text-center py-4">Aucune réponse QCM enregistrée</p>
                ) : (
                  <div className="space-y-3">
                    {scoreboard.scoreboard.map((entry, index) => {
                      const isMe = entry.nickname === participantSession?.nickname;
                      return (
                        <div key={index}
                          className={`rounded-xl p-4 flex items-center gap-3 ${isMe ? "bg-yellow-400/30 ring-2 ring-yellow-400" : "bg-white/10"}`}
                        >
                          <span className="text-2xl w-10 text-center">
                            {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}.`}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className={`font-bold truncate ${isMe ? "text-yellow-300" : ""}`}>
                              {entry.nickname} {isMe && "👈 toi"}
                            </p>
                            <p className="text-white/60 text-sm">
                              {entry.score} / {entry.totalQuestions} bonnes réponses
                            </p>
                          </div>
                          <p className="text-xl font-bold shrink-0">
                            {entry.totalQuestions > 0 ? Math.round((entry.score / entry.totalQuestions) * 100) : 0}%
                          </p>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            <button onClick={() => navigate("/")}
              className="w-full py-3 mt-4 bg-white/20 text-white rounded-xl font-medium hover:bg-white/30 transition-colors">
              Retour à l'accueil
            </button>
          </div>
        )}

        {eventState?.status === "live" && (
          <div className="space-y-6">

            {/* Timer */}
            {timeLeft !== null && (
              <div className={`text-center rounded-2xl py-3 px-6 font-bold text-2xl transition-all ${
                timerUrgent ? "bg-red-500 animate-pulse" : "bg-white/20"
              }`}>
                ⏱ {timeLeft}s
              </div>
            )}

            {/* Titre question */}
            {currentQuestion && (
              <div className="text-center bg-white/10 backdrop-blur-sm rounded-2xl p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white/60 text-sm">
                    Question {currentQuestionIndex + 1}{eventData?.questions ? ` / ${eventData.questions.length}` : ""}
                  </span>
                  {eventData?.questions && (
                    <span className="text-white/60 text-xs">
                      {Math.round(((currentQuestionIndex + 1) / eventData.questions.length) * 100)}%
                    </span>
                  )}
                </div>
                {eventData?.questions && (
                  <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden mb-4">
                    <div
                      className="h-full bg-white/60 rounded-full transition-all duration-500"
                      style={{ width: `${((currentQuestionIndex + 1) / eventData.questions.length) * 100}%` }}
                    />
                  </div>
                )}
                <h2 className="text-xl font-bold">{currentQuestion.title}</h2>
              </div>
            )}

            {/* Déjà répondu */}
            {hasAnswered ? (
              <div className="text-center py-10">
                {answerFeedback === "correct" ? (
                  <>
                    <div className="w-20 h-20 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-4xl">✓</span>
                    </div>
                    <h2 className="text-2xl font-bold mb-1 text-green-300">Bonne réponse !</h2>
                  </>
                ) : answerFeedback === "incorrect" ? (
                  <>
                    <div className="w-20 h-20 bg-red-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-4xl">✗</span>
                    </div>
                    <h2 className="text-2xl font-bold mb-1 text-red-300">Mauvaise réponse</h2>
                  </>
                ) : (
                  <>
                    <div className="w-20 h-20 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-4xl">✓</span>
                    </div>
                    <h2 className="text-2xl font-bold mb-1">Réponse envoyée !</h2>
                  </>
                )}
                <p className="text-white/70">En attente de la prochaine question...</p>
                {explanation && (currentQuestion?.type === "mcq" || currentQuestion?.type === "trueFalse") && (
                  <div className="mt-6 mx-auto max-w-md bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-left">
                    <p className="text-yellow-300 text-xs font-bold mb-1">💡 EXPLICATION</p>
                    <p className="text-white/90 text-sm">{explanation}</p>
                  </div>
                )}
              </div>

            ) : !eventState?.votingOpen ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-red-500/50 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <span className="text-4xl">🔒</span>
                </div>
                <h2 className="text-2xl font-bold mb-2">Votes fermés</h2>
                <p className="text-white/70">Le présentateur a fermé les votes</p>
              </div>

            ) : currentQuestion?.type === "mcq" ? (
              <div className="space-y-4">
                <p className="text-center text-white/70">Sélectionnez votre réponse</p>
                <div className="space-y-3">
                  {options.map((option: any, index: number) => (
                    <button key={option.id} onClick={() => handleSelectOption(option.id)}
                      className={`w-full p-4 rounded-2xl text-left transition-all flex items-center gap-4 ${
                        selectedOption === option.id ? "ring-4 ring-white scale-[0.98]" : "hover:scale-[1.02]"
                      }`}
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    >
                      <span className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl font-bold shrink-0">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="text-lg font-medium flex-1">{option.text}</span>
                      {selectedOption === option.id && <span className="text-2xl">✓</span>}
                    </button>
                  ))}
                </div>
                {selectedOption && (
                  <button onClick={handleSubmitMcq}
                    className="w-full py-4 bg-white text-primary-600 rounded-xl font-bold text-lg mt-4 hover:scale-[1.02] active:scale-[0.98] transition-transform">
                    Valider ma réponse
                  </button>
                )}
              </div>

            ) : currentQuestion?.type === "trueFalse" ? (
              <div className="space-y-4">
                <p className="text-center text-white/70">Vrai ou Faux ?</p>
                <div className="grid grid-cols-2 gap-4">
                  {options.map((option: any) => (
                    <button key={option.id} onClick={() => handleSelectOption(option.id)}
                      className={`py-10 rounded-2xl text-3xl font-bold transition-all ${
                        selectedOption === option.id ? "ring-4 ring-white scale-[0.97]" : "hover:scale-[1.03]"
                      }`}
                      style={{ backgroundColor: option.text === "Vrai" ? "#10b981" : "#ef4444" }}
                    >
                      {option.text === "Vrai" ? "✓ Vrai" : "✗ Faux"}
                    </button>
                  ))}
                </div>
                {selectedOption && (
                  <button onClick={handleSubmitMcq}
                    className="w-full py-4 bg-white text-primary-600 rounded-xl font-bold text-lg mt-2 hover:scale-[1.02] transition-transform">
                    Valider
                  </button>
                )}
              </div>

            ) : currentQuestion?.type === "scale" ? (
              <div className="space-y-6">
                <p className="text-center text-white/70">Positionnez votre réponse</p>
                <div className="bg-white/10 rounded-2xl p-6">
                  <div className="text-center text-6xl font-bold mb-4">
                    {scaleValue ?? "—"}
                  </div>
                  <input type="range"
                    min={scaleConfig.min} max={scaleConfig.max} step={1}
                    value={scaleValue ?? scaleConfig.min}
                    onChange={(e) => setScaleValue(Number(e.target.value))}
                    className="w-full h-3 accent-white cursor-pointer"
                  />
                  <div className="flex justify-between mt-2">
                    {Array.from({ length: scaleConfig.max - scaleConfig.min + 1 }, (_, i) => scaleConfig.min + i).map(v => (
                      <span key={v} className={`text-xs ${scaleValue === v ? "text-white font-bold" : "text-white/40"}`}>{v}</span>
                    ))}
                  </div>
                </div>
                {scaleValue !== null && (
                  <button onClick={handleSubmitScale}
                    className="w-full py-4 bg-white text-primary-600 rounded-xl font-bold text-lg hover:scale-[1.02] transition-transform">
                    Valider ma réponse
                  </button>
                )}
              </div>

            ) : currentQuestion?.type === "wordcloud" ? (
              <div className="space-y-4">
                <p className="text-center text-white/70">Entrez vos mots (séparés par des virgules ou espaces)</p>
                {sentWords.length > 0 && (
                  <div className="bg-white/10 rounded-xl p-4">
                    <p className="text-white/50 text-xs mb-2">Mots envoyés ({sentWords.length}) :</p>
                    <div className="flex flex-wrap gap-2">
                      {sentWords.map((word, i) => (
                        <span key={i} className="px-3 py-1 bg-white/20 rounded-full text-sm font-medium">{word}</span>
                      ))}
                    </div>
                  </div>
                )}
                <input type="text" value={wordInput}
                  onChange={(e) => setWordInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && wordInput.trim()) handleSubmitWords(); }}
                  placeholder={sentWords.length > 0 ? "Encore un mot ?" : "Ex: innovation, créativité, équipe"}
                  className="w-full p-4 rounded-xl bg-white/20 text-white placeholder-white/50 border-2 border-white/30 focus:border-white focus:outline-none"
                  autoFocus
                />
                {wordInput.trim() && (
                  <button onClick={handleSubmitWords}
                    className="w-full py-4 bg-white text-primary-600 rounded-xl font-bold text-lg hover:scale-[1.02] active:scale-[0.98] transition-transform">
                    Envoyer {sentWords.length > 0 ? "encore" : "mes mots"}
                  </button>
                )}
              </div>

            ) : currentQuestion?.type === "open" ? (
              <div className="space-y-4">
                <p className="text-center text-white/70">Écrivez votre réponse</p>
                <textarea value={openAnswer} onChange={(e) => setOpenAnswer(e.target.value)}
                  placeholder="Votre réponse..." rows={4}
                  className="w-full p-4 rounded-xl bg-white/20 text-white placeholder-white/50 border-2 border-white/30 focus:border-white focus:outline-none resize-none"
                />
                {openAnswer.trim() && (
                  <button onClick={handleSubmitOpen}
                    className="w-full py-4 bg-white text-primary-600 rounded-xl font-bold text-lg hover:scale-[1.02] active:scale-[0.98] transition-transform">
                    Envoyer ma réponse
                  </button>
                )}
              </div>

            ) : (
              <div className="text-center py-12">
                <p className="text-white/70">En attente de la question...</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
