import { useEffect, useRef, useCallback, useState } from "react";
import { io, Socket } from "socket.io-client";

interface EventState {
  currentQuestion: number;
  showResults: boolean;
  votingOpen: boolean;
  status: string;
  timerEndAt: number | null;
  timerDuration: number | null;
}

interface LiveResults {
  questionId: number;
  results: Record<string, number> | string[];
  totalAnswers: number;
  type?: string; // "wordcloud", "open", ou undefined pour MCQ
}

// Déterminer l'URL du serveur WebSocket dynamiquement
function getSocketUrl(): string {
  const host = window.location.hostname;
  const port = "3001";
  
  // Si on accède via localhost ou 127.0.0.1, utiliser le proxy Vite
  if (host === "localhost" || host === "127.0.0.1") {
    return "";
  }
  
  // Sinon, connexion directe au backend sur le port 3001
  return `http://${host}:${port}`;
}

export function useSocket() {
  const socketRef = useRef<Socket | null>(null);
  // Stocke les infos nécessaires pour re-rejoindre la room après une reconnexion
  const rejoinRef = useRef<
    | { type: "participant"; eventCode: string; participantId: number; nickname: string }
    | { type: "presenter"; eventCode: string }
    | null
  >(null);
  const [isConnected, setIsConnected] = useState(false);
  const [eventState, setEventState] = useState<EventState | null>(null);
  const [liveResults, setLiveResults] = useState<LiveResults | null>(null);
  const [participantCount, setParticipantCount] = useState(0);
  const [answerConfirmed, setAnswerConfirmed] = useState(false);

  useEffect(() => {
    const socketUrl = getSocketUrl();
    console.log("[Socket] Connexion à:", socketUrl || "proxy Vite");
    
    const socket = socketUrl 
      ? io(socketUrl, { transports: ["websocket", "polling"] })
      : io({ transports: ["websocket", "polling"] });

    socket.on("connect", () => {
      console.log("[Socket] Connecté, id:", socket.id);
      setIsConnected(true);
      // Re-join automatique après une reconnexion
      const r = rejoinRef.current;
      if (r) {
        if (r.type === "participant") {
          console.log("[Socket] Re-join participant:", r);
          socket.emit("JOIN_ROOM", { eventCode: r.eventCode, participantId: r.participantId, nickname: r.nickname });
        } else {
          console.log("[Socket] Re-join presenter:", r);
          socket.emit("PRESENTER_JOIN", { eventCode: r.eventCode });
        }
      }
    });

    socket.on("disconnect", () => {
      console.log("[Socket] Déconnecté");
      setIsConnected(false);
    });

    socket.on("connect_error", (error) => {
      console.error("[Socket] Erreur de connexion:", error.message);
    });

    socket.on("UPDATE_STATE", (state: EventState) => {
      console.log("[Socket] UPDATE_STATE:", state);
      setEventState(state);
      // Réinitialiser la confirmation quand la question change
      setAnswerConfirmed(false);
    });

    // IMPORTANT: Ne PAS effacer les résultats dans LIVE_RESULTS
    // Le serveur envoie les résultats complets (y compris les réponses précédentes)
    socket.on("LIVE_RESULTS", (results: LiveResults) => {
      console.log("[Socket] LIVE_RESULTS:", results);
      setLiveResults(results);
    });

    socket.on("PARTICIPANT_COUNT", (count: number) => {
      console.log("[Socket] PARTICIPANT_COUNT:", count);
      setParticipantCount(count);
    });

    // CORRECTION PERSISTANCE: Ne PAS effacer liveResults lors du changement de question
    // Le serveur va envoyer les résultats rechargés via LIVE_RESULTS juste après
    socket.on("QUESTION_CHANGED", (data: any) => {
      console.log("[Socket] QUESTION_CHANGED:", data);
      const questionIndex = typeof data === "number" ? data : data.questionIndex;
      setEventState(prev => prev ? { ...prev, currentQuestion: questionIndex } : null);
      // On efface les résultats temporairement, le serveur les renverra via LIVE_RESULTS
      // si des réponses existent déjà pour cette question
      setLiveResults(null);
      setAnswerConfirmed(false);
    });

    socket.on("ANSWER_CONFIRMED", () => {
      console.log("[Socket] ANSWER_CONFIRMED");
      setAnswerConfirmed(true);
    });

    socketRef.current = socket;

    return () => {
      socket.disconnect();
    };
  }, []);

  // Actions Participant
  const joinRoom = useCallback((eventCode: string, participantId: number, nickname: string) => {
    console.log("[Socket] JOIN_ROOM:", { eventCode, participantId, nickname });
    rejoinRef.current = { type: "participant", eventCode, participantId, nickname };
    socketRef.current?.emit("JOIN_ROOM", { eventCode, participantId, nickname });
  }, []);

  const submitAnswer = useCallback((eventCode: string, questionId: number, participantId: number, content: any) => {
    console.log("[Socket] SUBMIT_ANSWER:", { eventCode, questionId, participantId, content });
    socketRef.current?.emit("SUBMIT_ANSWER", { eventCode, questionId, participantId, content });
  }, []);

  // Actions Présentateur
  const presenterJoin = useCallback((eventCode: string) => {
    console.log("[Socket] PRESENTER_JOIN:", { eventCode });
    rejoinRef.current = { type: "presenter", eventCode };
    socketRef.current?.emit("PRESENTER_JOIN", { eventCode });
  }, []);

  const startEvent = useCallback((eventCode: string) => {
    console.log("[Socket] START_EVENT:", { eventCode });
    socketRef.current?.emit("START_EVENT", { eventCode });
  }, []);

  const nextQuestion = useCallback((eventCode: string) => {
    console.log("[Socket] NEXT_QUESTION:", { eventCode });
    socketRef.current?.emit("NEXT_QUESTION", { eventCode });
  }, []);

  const previousQuestion = useCallback((eventCode: string) => {
    console.log("[Socket] PREVIOUS_QUESTION:", { eventCode });
    socketRef.current?.emit("PREVIOUS_QUESTION", { eventCode });
  }, []);

  const toggleResults = useCallback((eventCode: string) => {
    console.log("[Socket] TOGGLE_RESULTS:", { eventCode });
    socketRef.current?.emit("TOGGLE_RESULTS", { eventCode });
  }, []);

  const toggleVoting = useCallback((eventCode: string) => {
    console.log("[Socket] TOGGLE_VOTING:", { eventCode });
    socketRef.current?.emit("TOGGLE_VOTING", { eventCode });
  }, []);

  const endEvent = useCallback((eventCode: string) => {
    console.log("[Socket] END_EVENT:", { eventCode });
    socketRef.current?.emit("END_EVENT", { eventCode });
  }, []);

  const startTimer = useCallback((eventCode: string, durationMs: number) => {
    socketRef.current?.emit("START_TIMER", { eventCode, durationMs });
  }, []);

  const stopTimer = useCallback((eventCode: string) => {
    socketRef.current?.emit("STOP_TIMER", { eventCode });
  }, []);

  return {
    isConnected,
    eventState,
    liveResults,
    participantCount,
    answerConfirmed,
    // Participant
    joinRoom,
    submitAnswer,
    // Presenter
    presenterJoin,
    startEvent,
    nextQuestion,
    previousQuestion,
    toggleResults,
    toggleVoting,
    endEvent,
    startTimer,
    stopTimer,
  };
}
