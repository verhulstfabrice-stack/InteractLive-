import { useState, useEffect, Component, ReactNode } from "react";
import { trpc } from "./lib/trpc";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import EventEditor from "./pages/EventEditor";
import PresenterView from "./pages/PresenterView";
import JoinEvent from "./pages/JoinEvent";
import ParticipantView from "./pages/ParticipantView";

type Route =
  | { page: "home" }
  | { page: "login" }
  | { page: "dashboard" }
  | { page: "event-editor"; eventId: number }
  | { page: "presenter"; eventId: number }
  | { page: "join"; code?: string }
  | { page: "participant"; eventId: number; participantId: number }
  | { page: "not-found" };

function parseRoute(): Route {
  const path = window.location.pathname;
  const params = new URLSearchParams(window.location.search);

  if (path === "/" || path === "") return { page: "home" };
  if (path === "/login") return { page: "login" };
  if (path === "/dashboard") return { page: "dashboard" };

  if (path.startsWith("/event/") && path.endsWith("/edit")) {
    const id = parseInt(path.split("/")[2], 10);
    if (Number.isFinite(id) && id > 0) return { page: "event-editor", eventId: id };
    return { page: "not-found" };
  }

  if (path.startsWith("/presenter/")) {
    const id = parseInt(path.split("/")[2], 10);
    if (Number.isFinite(id) && id > 0) return { page: "presenter", eventId: id };
    return { page: "not-found" };
  }

  if (path === "/join" || path.startsWith("/p/")) {
    const code = path.startsWith("/p/") ? path.split("/")[2] : params.get("code") || undefined;
    return { page: "join", code };
  }

  if (path.startsWith("/participate/")) {
    const parts = path.split("/");
    const eventId = parseInt(parts[2], 10);
    const participantId = parseInt(parts[3], 10);
    if (Number.isFinite(eventId) && Number.isFinite(participantId) && eventId > 0 && participantId > 0) {
      return { page: "participant", eventId, participantId };
    }
    return { page: "not-found" };
  }

  return { page: "not-found" };
}

export function navigate(path: string) {
  window.history.pushState({}, "", path);
  window.dispatchEvent(new PopStateEvent("popstate"));
}

// Error Boundary pour eviter les ecrans blancs
class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error) { console.error("[App] Erreur React:", error); }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
          <div className="max-w-md text-center">
            <div className="text-6xl mb-4">😕</div>
            <h1 className="text-2xl font-bold mb-2">Oups, une erreur est survenue</h1>
            <p className="text-gray-600 mb-6 text-sm">
              {this.state.error.message || "Erreur inattendue"}
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => { this.setState({ error: null }); navigate("/dashboard"); }}
                className="px-5 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
              >
                Retour au tableau de bord
              </button>
              <button
                onClick={() => window.location.reload()}
                className="px-5 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
              >
                Recharger
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="text-center max-w-md">
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="text-3xl font-bold mb-2">Page introuvable</h1>
        <p className="text-gray-600 mb-6">Cette adresse n'existe pas ou a ete supprimee.</p>
        <button
          onClick={() => navigate("/dashboard")}
          className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 font-medium"
        >
          Retour au tableau de bord
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [route, setRoute] = useState<Route>(parseRoute);
  const { data: user, isLoading } = trpc.auth.me.useQuery();

  useEffect(() => {
    const handlePopState = () => setRoute(parseRoute());
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  useEffect(() => {
    if (user && route.page === "login") navigate("/dashboard");
  }, [user, route.page]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
      </div>
    );
  }

  const renderPage = () => {
    // Routes publiques
    if (route.page === "join") return <JoinEvent initialCode={route.code} />;
    if (route.page === "participant") {
      return <ParticipantView eventId={route.eventId} participantId={route.participantId} />;
    }
    if (route.page === "not-found") return <NotFound />;

    // Routes necessitant login
    if (!user) {
      if (route.page === "home") return <Home />;
      return <Login />;
    }

    switch (route.page) {
      case "home": return <Home />;
      case "login": return <Login />;
      case "dashboard": return <Dashboard />;
      case "event-editor": return <EventEditor eventId={route.eventId} />;
      case "presenter": return <PresenterView eventId={route.eventId} />;
      default: return <NotFound />;
    }
  };

  return <ErrorBoundary>{renderPage()}</ErrorBoundary>;
}
