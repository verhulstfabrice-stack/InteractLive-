import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { networkInterfaces } from "os";
import { initTRPC } from "@trpc/server";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import superjson from "superjson";
import { z } from "zod";
import { PrismaClient } from "@prisma/client";
import { nanoid } from "nanoid";
import { SignJWT, jwtVerify } from "jose";
import { parse as parseCookie } from "cookie";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { readFileSync, writeFileSync, existsSync } from "fs";
import { parseMoodleXML, isValidMoodleXML } from "./moodleImport";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================
// DATABASE
// ============================================
const prisma = new PrismaClient();

// ============================================
// IP LOCALE (détectée au démarrage)
// ============================================
function getLocalIP(): string {
  const nets = networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) {
        return net.address;
      }
    }
  }
  return "localhost";
}

const LOCAL_IP = getLocalIP();

// ============================================
// AUTH HELPERS
// ============================================

// Générer un secret JWT persistant en local si absent
// Stocké dans .jwt-secret (créé automatiquement, à ne pas committer)
function getOrCreateJwtSecret(): string {
  if (process.env.JWT_SECRET && process.env.JWT_SECRET !== "default-secret") {
    return process.env.JWT_SECRET;
  }
  const secretFile = path.join(__dirname, "../.jwt-secret");
  if (existsSync(secretFile)) {
    try {
      const saved = readFileSync(secretFile, "utf-8").trim();
      if (saved.length >= 32) return saved;
    } catch {}
  }
  const newSecret = randomBytes(48).toString("hex");
  try {
    writeFileSync(secretFile, newSecret, { mode: 0o600 });
    console.log("[Auth] Nouveau secret JWT généré dans .jwt-secret");
  } catch (err) {
    console.warn("[Auth] Impossible d'écrire .jwt-secret, secret en mémoire uniquement");
  }
  return newSecret;
}

const JWT_SECRET = new TextEncoder().encode(getOrCreateJwtSecret());
const COOKIE_NAME = "interactlive_session";

// Hachage de mot de passe avec scrypt (intégré à Node, pas de dépendance externe)
function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(":");
    if (!salt || !hash) return false;
    const testHash = scryptSync(password, salt, 64);
    const storedBuf = Buffer.from(hash, "hex");
    if (testHash.length !== storedBuf.length) return false;
    return timingSafeEqual(testHash, storedBuf);
  } catch {
    return false;
  }
}

// Rate limiter simple en mémoire pour participant.join
// Max 5 tentatives par IP par fenêtre de 60s
const joinAttempts = new Map<string, number[]>();
function checkJoinRateLimit(ip: string): boolean {
  const now = Date.now();
  const windowMs = 60 * 1000;
  const max = 5;
  const attempts = (joinAttempts.get(ip) || []).filter(t => now - t < windowMs);
  if (attempts.length >= max) {
    joinAttempts.set(ip, attempts);
    return false;
  }
  attempts.push(now);
  joinAttempts.set(ip, attempts);
  return true;
}
// Nettoyage périodique de la Map (toutes les 5 min)
setInterval(() => {
  const now = Date.now();
  for (const [ip, attempts] of joinAttempts.entries()) {
    const fresh = attempts.filter(t => now - t < 60 * 1000);
    if (fresh.length === 0) joinAttempts.delete(ip);
    else joinAttempts.set(ip, fresh);
  }
}, 5 * 60 * 1000);

async function createSessionToken(userId: number, name: string): Promise<string> {
  return new SignJWT({ userId, name })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("7d")
    .sign(JWT_SECRET);
}

async function verifySession(token: string): Promise<{ userId: number; name: string } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as { userId: number; name: string };
  } catch {
    return null;
  }
}

// ============================================
// TRPC SETUP
// ============================================
interface Context {
  req: express.Request;
  res: express.Response;
  user: { id: number; name: string; email: string; role: string } | null;
}

const t = initTRPC.context<Context>().create({
  transformer: superjson,
});

const publicProcedure = t.procedure;
const protectedProcedure = t.procedure.use(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new Error("Non autorisé. Veuillez vous connecter.");
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});

// ============================================
// SCHÉMAS DE VALIDATION DES PAYLOADS
// ============================================
const mcqOptionSchema = z.object({
  id: z.string().min(1).max(50),
  text: z.string().min(1).max(500),
  isCorrect: z.boolean(),
});

// Un payload regroupe tous les champs possibles, tous optionnels
// On valide ensuite la cohérence avec validatePayloadForType selon le type
const questionPayloadSchema = z.object({
  options: z.array(mcqOptionSchema).max(20).optional(),
  correctAnswerId: z.string().max(50).optional(),
  min: z.number().int().min(0).max(100).optional(),
  max: z.number().int().min(1).max(100).optional(),
  label: z.string().max(200).optional(),
  timerDuration: z.number().int().min(5).max(600).nullable().optional(),
  explanation: z.string().max(2000).optional(),
  category: z.string().max(100).optional(),
}).strict(); // refuse les clés non déclarées

function validatePayloadForType(type: string, payload: any): boolean {
  if (!payload) return type === "wordcloud" || type === "open"; // ces 2 types n'exigent rien
  if (type === "mcq") {
    return Array.isArray(payload.options) && payload.options.length >= 2
      && payload.options.some((o: any) => o.isCorrect);
  }
  if (type === "trueFalse") {
    return Array.isArray(payload.options) && payload.options.length === 2;
  }
  if (type === "scale") {
    return typeof payload.min === "number" && typeof payload.max === "number"
      && payload.min < payload.max;
  }
  if (type === "wordcloud" || type === "open") {
    return true; // pas d'exigence sur le payload
  }
  return false;
}

// Schéma de validation des réponses des participants
// Chaque type de question attend un format de contenu différent
const answerContentSchema = z.object({
  selectedOptionId: z.string().max(50).optional(),     // QCM, Vrai/Faux
  value: z.number().min(0).max(100).optional(),         // Curseur
  words: z.array(z.string().min(1).max(50)).max(20).optional(), // Nuage (par envoi)
  append: z.boolean().optional(),                       // Flag d'accumulation nuage
  text: z.string().max(2000).optional(),                // Question ouverte
}).strict().refine(
  (data) => Object.keys(data).length > 0,
  { message: "Contenu de réponse vide" }
);

// ============================================
// TRPC ROUTER
// ============================================
const appRouter = t.router({
  // Auth
  auth: t.router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        name: z.string().optional(),
        password: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const email = input.email.trim().toLowerCase();
        let user = await prisma.user.findUnique({ where: { email } });
        
        if (!user) {
          // En production, un mot de passe est obligatoire à la création
          if (process.env.NODE_ENV === "production" && !input.password) {
            throw new Error("Mot de passe requis pour créer un compte");
          }
          if (input.password && input.password.length < 8) {
            throw new Error("Le mot de passe doit contenir au moins 8 caractères");
          }
          const passwordHash = input.password ? hashPassword(input.password) : null;
          user = await prisma.user.create({
            data: {
              email,
              name: input.name || email.split("@")[0],
              password: passwordHash,
              role: "admin",
            },
          });
        } else if (user.password) {
          // Compte existant avec mdp : on le vérifie
          if (!input.password || !verifyPassword(input.password, user.password)) {
            throw new Error("Mot de passe incorrect");
          }
        } else if (input.password) {
          // Compte existant sans mdp : on en enregistre un si fourni (upgrade)
          if (input.password.length < 8) {
            throw new Error("Le mot de passe doit contenir au moins 8 caractères");
          }
          await prisma.user.update({
            where: { id: user.id },
            data: { password: hashPassword(input.password) },
          });
        } else if (process.env.NODE_ENV === "production") {
          // En prod, refuser la connexion sans mot de passe
          throw new Error("Mot de passe requis");
        }
        
        const token = await createSessionToken(user.id, user.name);
        ctx.res.cookie(COOKIE_NAME, token, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          maxAge: 7 * 24 * 60 * 60 * 1000,
          path: "/",
        });
        
        return { user: { id: user.id, email: user.email, name: user.name, role: user.role, hasPassword: !!user.password } };
      }),

    // Savoir si un email a déjà un mot de passe (affichage conditionnel du champ)
    checkEmail: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .query(async ({ input }) => {
        const email = input.email.trim().toLowerCase();
        const user = await prisma.user.findUnique({ where: { email } });
        return { exists: !!user, hasPassword: !!user?.password };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME);
      return { success: true };
    }),
  }),

  // System - IP locale ou URL publique
  system: t.router({
    getLocalIP: publicProcedure.query(() => {
      // Si PUBLIC_URL est défini, il est toujours prioritaire.
      // Permet en local (WiFi de formation) de forcer l'URL de participation
      // vers l'IP du PC formateur (ex: http://192.168.1.42:3001)
      if (process.env.PUBLIC_URL) {
        try {
          const u = new URL(process.env.PUBLIC_URL);
          return {
            ip: u.hostname,
            port: u.port ? parseInt(u.port) : (u.protocol === "https:" ? 443 : 80),
            publicUrl: process.env.PUBLIC_URL.replace(/\/$/, ""),
          };
        } catch {
          // fallback silencieux
        }
      }
      // Fallback : IP détectée automatiquement + port du serveur
      const serverPort = parseInt(process.env.PORT || "3001");
      return { ip: LOCAL_IP, port: serverPort };
    }),
  }),

  // Events
  event: t.router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return prisma.event.findMany({
        where: { userId: ctx.user.id },
        orderBy: { createdAt: "desc" },
        include: { _count: { select: { questions: true, participants: true } } },
      });
    }),

    // Statistiques d'un événement (taux de réussite moyen, question la plus ratée)
    getStats: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const event = await prisma.event.findFirst({
          where: { id: input.id, userId: ctx.user.id },
          include: {
            questions: { orderBy: { order: "asc" }, include: { answers: true } },
            participants: true,
          },
        });
        if (!event) throw new Error("Événement non trouvé");

        let totalAnswers = 0;
        let totalCorrect = 0;
        const perQuestion: Array<{ id: number; title: string; type: string; total: number; correct: number; successRate: number; category?: string }> = [];

        for (const q of event.questions) {
          if (q.type !== "mcq" && q.type !== "trueFalse") continue;
          const payload = q.payload ? JSON.parse(q.payload) : {};
          const options = payload.options || [];
          const correctId = payload.correctAnswerId || options.find((o: any) => o.isCorrect)?.id;
          if (!correctId) continue;

          let correct = 0;
          for (const a of q.answers) {
            const content = JSON.parse(a.content);
            if (content.selectedOptionId === correctId) correct++;
          }
          totalAnswers += q.answers.length;
          totalCorrect += correct;
          const rate = q.answers.length > 0 ? (correct / q.answers.length) * 100 : 0;
          perQuestion.push({
            id: q.id,
            title: q.title,
            type: q.type,
            total: q.answers.length,
            correct,
            successRate: Math.round(rate),
            category: payload.category,
          });
        }

        // Question la plus ratée (min successRate avec au moins 1 réponse)
        const answered = perQuestion.filter(q => q.total > 0);
        const hardest = answered.length > 0
          ? [...answered].sort((a, b) => a.successRate - b.successRate)[0]
          : null;
        const easiest = answered.length > 0
          ? [...answered].sort((a, b) => b.successRate - a.successRate)[0]
          : null;

        return {
          totalQuestions: event.questions.length,
          scorableQuestions: perQuestion.length,
          totalParticipants: event.participants.length,
          avgSuccessRate: totalAnswers > 0 ? Math.round((totalCorrect / totalAnswers) * 100) : null,
          hardest,
          easiest,
          perQuestion,
        };
      }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const event = await prisma.event.findFirst({
          where: { id: input.id, userId: ctx.user.id },
          include: { questions: { orderBy: { order: "asc" } } },
        });
        if (!event) throw new Error("Événement non trouvé");
        return event;
      }),

    getByCode: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        const event = await prisma.event.findUnique({
          where: { code: input.code.toUpperCase() },
          include: {
            questions: { orderBy: { order: "asc" } },
          },
        });
        if (!event) throw new Error("Événement non trouvé");
        return {
          id: event.id,
          code: event.code,
          title: event.title,
          status: event.status,
          questions: event.questions.map(q => ({
            id: q.id,
            title: q.title,
            type: q.type,
            payload: q.payload,
            order: q.order,
          })),
        };
      }),

    create: protectedProcedure
      .input(z.object({ title: z.string(), description: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        const code = nanoid(6).toUpperCase();
        return prisma.event.create({
          data: { ...input, code, userId: ctx.user.id },
        });
      }),

    // Dupliquer un événement (sans réponses ni participants)
    duplicate: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const source = await prisma.event.findFirst({
          where: { id: input.id, userId: ctx.user.id },
          include: { questions: { orderBy: { order: "asc" } } },
        });
        if (!source) throw new Error("Événement non trouvé");

        const newCode = nanoid(6).toUpperCase();
        const newEvent = await prisma.event.create({
          data: {
            code: newCode,
            title: `${source.title} (copie)`,
            description: source.description,
            userId: ctx.user.id,
            status: "draft",
          },
        });

        // Dupliquer les questions
        for (const q of source.questions) {
          await prisma.question.create({
            data: {
              eventId: newEvent.id,
              type: q.type,
              title: q.title,
              payload: q.payload,
              order: q.order,
            },
          });
        }

        return newEvent;
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        status: z.string().optional(),
        currentQuestion: z.number().optional(),
        showResults: z.boolean().optional(),
        votingOpen: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        return prisma.event.update({
          where: { id, userId: ctx.user.id },
          data,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await prisma.event.delete({ where: { id: input.id, userId: ctx.user.id } });
        return { success: true };
      }),

    // Réinitialiser la progression d'un événement
    resetProgress: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Vérifier que l'événement appartient à l'utilisateur
        const event = await prisma.event.findFirst({
          where: { id: input.id, userId: ctx.user.id },
        });
        if (!event) throw new Error("Événement non trouvé");

        // Supprimer toutes les réponses de cet événement
        await prisma.answer.deleteMany({
          where: { question: { eventId: input.id } },
        });

        // Supprimer tous les participants
        await prisma.participant.deleteMany({
          where: { eventId: input.id },
        });

        // Remettre le statut à draft
        await prisma.event.update({
          where: { id: input.id },
          data: {
            status: "draft",
            currentQuestion: 0,
            showResults: false,
            votingOpen: true,
          },
        });

        // Nettoyer l'état en mémoire
        eventStates.delete(event.code);

        return { success: true };
      }),

    // Classement des participants (scores QCM)
    getScoreboard: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const event = await prisma.event.findFirst({
          where: { id: input.id },
          include: {
            questions: {
              orderBy: { order: "asc" },
              include: { answers: { include: { participant: true } } },
            },
            participants: true,
          },
        });
        if (!event) throw new Error("Événement non trouvé");

        // Calculer le score de chaque participant
        const scores: Record<number, { nickname: string; score: number; total: number }> = {};

        // Initialiser tous les participants
        for (const p of event.participants) {
          scores[p.id] = { nickname: p.nickname, score: 0, total: 0 };
        }

        // Compter les bonnes réponses QCM et Vrai/Faux
        for (const question of event.questions) {
          if (question.type !== "mcq" && question.type !== "trueFalse") continue;
          const payload = question.payload ? JSON.parse(question.payload) : {};
          const options = payload.options || [];
          const correctId = payload.correctAnswerId || options.find((o: any) => o.isCorrect)?.id;
          if (!correctId) continue;

          for (const answer of question.answers) {
            if (!scores[answer.participantId]) {
              scores[answer.participantId] = {
                nickname: answer.participant.nickname,
                score: 0,
                total: 0,
              };
            }
            scores[answer.participantId].total++;
            const content = JSON.parse(answer.content);
            if (content.selectedOptionId === correctId) {
              scores[answer.participantId].score++;
            }
          }
        }

        const totalMcqQuestions = event.questions.filter(q => q.type === "mcq" || q.type === "trueFalse").length;

        // Trier par score décroissant
        const sorted = Object.values(scores)
          .map(s => ({ ...s, totalQuestions: totalMcqQuestions }))
          .sort((a, b) => b.score - a.score);

        return { scoreboard: sorted, totalQuestions: totalMcqQuestions, totalParticipants: event.participants.length };
      }),

    // Export des résultats en JSON (le frontend convertira en Excel)
    exportResults: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const event = await prisma.event.findFirst({
          where: { id: input.id, userId: ctx.user.id },
          include: {
            questions: {
              orderBy: { order: "asc" },
              include: {
                answers: { include: { participant: true } },
              },
            },
            participants: true,
          },
        });
        if (!event) throw new Error("Événement non trouvé");

        // Données brutes
        const rows: Array<{
          question: string;
          questionType: string;
          category: string;
          participant: string;
          answer: string;
          isCorrect: string;
          timestamp: string;
        }> = [];

        // Synthèse par question
        const perQuestion: Array<{
          question: string; type: string; category: string;
          total: number; correct: number; successRate: number;
        }> = [];

        // Synthèse par participant
        const perParticipant: Record<number, { nickname: string; correct: number; total: number }> = {};
        for (const p of event.participants) {
          perParticipant[p.id] = { nickname: p.nickname, correct: 0, total: 0 };
        }

        // Synthèse par catégorie
        const perCategory: Record<string, { total: number; correct: number }> = {};

        const typeLabel = (t: string) =>
          t === "mcq" ? "QCM" :
          t === "trueFalse" ? "Vrai/Faux" :
          t === "scale" ? "Curseur" :
          t === "wordcloud" ? "Nuage de mots" :
          t === "open" ? "Question ouverte" : t;

        for (const question of event.questions) {
          const payload = question.payload ? JSON.parse(question.payload) : {};
          const options = payload.options || [];
          const correctId = payload.correctAnswerId || options.find((o: any) => o.isCorrect)?.id;
          const category = payload.category || "";

          let qCorrect = 0;
          let qTotal = 0;

          for (const answer of question.answers) {
            const content = JSON.parse(answer.content);
            let answerText = "";
            let isCorrect = "";
            let isCorrectBool = false;

            if (question.type === "mcq" || question.type === "trueFalse") {
              const selectedOption = options.find((o: any) => o.id === content.selectedOptionId);
              answerText = selectedOption?.text || content.selectedOptionId || "";
              isCorrectBool = content.selectedOptionId === correctId;
              isCorrect = isCorrectBool ? "Oui" : "Non";
              qTotal++;
              if (isCorrectBool) qCorrect++;
              if (perParticipant[answer.participantId]) {
                perParticipant[answer.participantId].total++;
                if (isCorrectBool) perParticipant[answer.participantId].correct++;
              }
              if (category) {
                if (!perCategory[category]) perCategory[category] = { total: 0, correct: 0 };
                perCategory[category].total++;
                if (isCorrectBool) perCategory[category].correct++;
              }
            } else if (question.type === "scale") {
              answerText = content.value !== undefined ? String(content.value) : "";
            } else if (question.type === "wordcloud") {
              answerText = (content.words || []).join(", ");
            } else if (question.type === "open") {
              answerText = content.text || "";
            }

            rows.push({
              question: question.title,
              questionType: typeLabel(question.type),
              category,
              participant: answer.participant.nickname,
              answer: answerText,
              isCorrect,
              timestamp: answer.createdAt.toISOString(),
            });
          }

          if (question.type === "mcq" || question.type === "trueFalse") {
            perQuestion.push({
              question: question.title,
              type: typeLabel(question.type),
              category,
              total: qTotal,
              correct: qCorrect,
              successRate: qTotal > 0 ? Math.round((qCorrect / qTotal) * 100) : 0,
            });
          }
        }

        const scoreboard = Object.values(perParticipant)
          .filter(p => p.total > 0)
          .map(p => ({
            ...p,
            successRate: p.total > 0 ? Math.round((p.correct / p.total) * 100) : 0,
          }))
          .sort((a, b) => b.correct - a.correct);

        const categoryStats = Object.entries(perCategory).map(([cat, s]) => ({
          category: cat,
          total: s.total,
          correct: s.correct,
          successRate: s.total > 0 ? Math.round((s.correct / s.total) * 100) : 0,
        }));

        return {
          eventTitle: event.title,
          eventCode: event.code,
          totalParticipants: event.participants.length,
          totalQuestions: event.questions.length,
          rows,
          perQuestion,
          scoreboard,
          categoryStats,
        };
      }),
  }),

  // Questions
  question: t.router({
    list: protectedProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        return prisma.question.findMany({
          where: { eventId: input.eventId },
          orderBy: { order: "asc" },
        });
      }),

    create: protectedProcedure
      .input(z.object({
        eventId: z.number().int().positive(),
        type: z.enum(["mcq", "wordcloud", "open", "trueFalse", "scale"]),
        title: z.string().min(1).max(500),
        payload: questionPayloadSchema.optional(),
      }))
      .mutation(async ({ input }) => {
        // Vérifier la cohérence payload ↔ type
        if (!validatePayloadForType(input.type, input.payload)) {
          throw new Error("Le contenu de la question ne correspond pas à son type.");
        }
        const count = await prisma.question.count({ where: { eventId: input.eventId } });
        return prisma.question.create({
          data: {
            eventId: input.eventId,
            type: input.type,
            title: input.title,
            payload: input.payload ? JSON.stringify(input.payload) : null,
            order: count,
          },
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number().int().positive(),
        title: z.string().min(1).max(500).optional(),
        payload: questionPayloadSchema.optional(),
        order: z.number().int().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, payload, ...data } = input;
        return prisma.question.update({
          where: { id },
          data: {
            ...data,
            ...(payload !== undefined && { payload: JSON.stringify(payload) }),
          },
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await prisma.question.delete({ where: { id: input.id } });
        return { success: true };
      }),

    // Échange atomique de deux questions (réordonnancement fiable)
    swapOrder: protectedProcedure
      .input(z.object({ idA: z.number(), idB: z.number() }))
      .mutation(async ({ input }) => {
        const [qA, qB] = await Promise.all([
          prisma.question.findUnique({ where: { id: input.idA } }),
          prisma.question.findUnique({ where: { id: input.idB } }),
        ]);
        if (!qA || !qB) throw new Error("Questions non trouvées");
        // Utiliser un order temporaire pour éviter les conflits d'unicité si jamais ajoutés
        await prisma.$transaction([
          prisma.question.update({ where: { id: input.idA }, data: { order: -1 } }),
          prisma.question.update({ where: { id: input.idB }, data: { order: qA.order } }),
          prisma.question.update({ where: { id: input.idA }, data: { order: qB.order } }),
        ]);
        return { success: true };
      }),

    results: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const question = await prisma.question.findUnique({
          where: { id: input.id },
          include: { answers: true },
        });
        if (!question) throw new Error("Question non trouvée");

        const answers = question.answers.map(a => JSON.parse(a.content));
        
        if (question.type === "mcq") {
          const counts: Record<string, number> = {};
          answers.forEach(a => {
            if (a.selectedOptionId) {
              counts[a.selectedOptionId] = (counts[a.selectedOptionId] || 0) + 1;
            }
          });
          return { type: "mcq", counts, total: answers.length };
        }
        
        if (question.type === "wordcloud") {
          const words: Record<string, number> = {};
          answers.forEach(a => {
            (a.words || []).forEach((w: string) => {
              words[w.toLowerCase()] = (words[w.toLowerCase()] || 0) + 1;
            });
          });
          return { type: "wordcloud", words, total: answers.length };
        }
        
        return { type: "open", answers, total: answers.length };
      }),

    importMoodle: protectedProcedure
      .input(z.object({ eventId: z.number(), xmlContent: z.string() }))
      .mutation(async ({ input }) => {
        if (!isValidMoodleXML(input.xmlContent)) {
          throw new Error("Fichier XML Moodle invalide");
        }

        const result = parseMoodleXML(input.xmlContent);
        if (!result.success && result.questions.length === 0) {
          throw new Error(result.errors.join("; ") || "Aucune question importée");
        }

        const count = await prisma.question.count({ where: { eventId: input.eventId } });
        const created = [];

        for (let i = 0; i < result.questions.length; i++) {
          const q = result.questions[i];
          const question = await prisma.question.create({
            data: {
              eventId: input.eventId,
              type: q.type,
              title: q.title,
              payload: JSON.stringify(q.payload),
              order: count + i,
            },
          });
          created.push(question);
        }

        return { imported: created.length, skipped: result.skipped, errors: result.errors };
      }),
  }),

  // Participants
  participant: t.router({
    join: publicProcedure
      .input(z.object({ code: z.string(), nickname: z.string() }))
      .mutation(async ({ input, ctx }) => {
        // Rate limiting : max 5 tentatives de join par IP par minute
        const ip = (ctx.req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim()
          || ctx.req.socket.remoteAddress || "unknown";
        if (!checkJoinRateLimit(ip)) {
          throw new Error("Trop de tentatives. Attendez 1 minute avant de réessayer.");
        }

        const event = await prisma.event.findUnique({
          where: { code: input.code.toUpperCase() },
        });
        if (!event) throw new Error("Événement non trouvé");
        if (event.status === "finished") throw new Error("Événement terminé");

        // Vérifier l'unicité du pseudo dans cet événement (case-insensitive)
        const normalized = input.nickname.trim();
        if (!normalized) throw new Error("Pseudo vide");
        if (normalized.length > 30) throw new Error("Pseudo trop long (30 caractères max)");
        const existing = await prisma.participant.findFirst({
          where: {
            eventId: event.id,
            nickname: { equals: normalized },
          },
        });
        if (existing) {
          throw new Error(`Le pseudo « ${normalized} » est déjà utilisé. Choisissez-en un autre.`);
        }

        const sessionId = nanoid(16);
        const participant = await prisma.participant.create({
          data: {
            sessionId,
            nickname: normalized,
            eventId: event.id,
          },
        });

        return { participant, event: { id: event.id, code: event.code, title: event.title } };
      }),

    getBySession: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .query(async ({ input }) => {
        return prisma.participant.findUnique({
          where: { sessionId: input.sessionId },
          include: { event: true },
        });
      }),
  }),

  // Answers
  answer: t.router({
    submit: publicProcedure
      .input(z.object({
        questionId: z.number().int().positive(),
        participantId: z.number().int().positive(),
        content: answerContentSchema,
      }))
      .mutation(async ({ input }) => {
        const existing = await prisma.answer.findUnique({
          where: {
            questionId_participantId: {
              questionId: input.questionId,
              participantId: input.participantId,
            },
          },
        });

        if (existing) {
          return prisma.answer.update({
            where: { id: existing.id },
            data: { content: JSON.stringify(input.content) },
          });
        }

        return prisma.answer.create({
          data: {
            questionId: input.questionId,
            participantId: input.participantId,
            content: JSON.stringify(input.content),
          },
        });
      }),

    hasAnswered: publicProcedure
      .input(z.object({ questionId: z.number(), participantId: z.number() }))
      .query(async ({ input }) => {
        const answer = await prisma.answer.findUnique({
          where: {
            questionId_participantId: {
              questionId: input.questionId,
              participantId: input.participantId,
            },
          },
        });
        return !!answer;
      }),

    // Récupérer la réponse existante d'un participant pour une question
    getForQuestion: publicProcedure
      .input(z.object({ questionId: z.number(), participantId: z.number() }))
      .query(async ({ input }) => {
        const answer = await prisma.answer.findUnique({
          where: {
            questionId_participantId: {
              questionId: input.questionId,
              participantId: input.participantId,
            },
          },
        });
        if (!answer) return null;
        return { id: answer.id, content: JSON.parse(answer.content) };
      }),
  }),
});

export type AppRouter = typeof appRouter;

// ============================================
// EXPRESS APP
// ============================================
const app = express();
// Indispensable en production derrière un reverse proxy (Nginx).
// Permet à Express de lire X-Forwarded-Proto / X-Forwarded-For
// et donc de gérer correctement les cookies Secure et l'IP client.
app.set("trust proxy", 1);
const httpServer = createServer(app);

// CORS : en production, whitelist stricte via ALLOWED_ORIGINS.
// En dev, autorise localhost + plages IP privées (réseau local de formation).
const PRODUCTION = process.env.NODE_ENV === "production";
const ALLOWED_ORIGINS_LIST = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

function isAllowedOrigin(origin: string | undefined): boolean {
  if (!origin) return true; // requêtes same-origin, curl, apps mobiles natives

  if (PRODUCTION) {
    // En prod : uniquement les origines explicitement autorisées
    return ALLOWED_ORIGINS_LIST.includes(origin);
  }

  // En dev : autorise localhost + plages IP privées (réseau local de formation)
  try {
    const url = new URL(origin);
    const host = url.hostname;
    if (host === "localhost" || host === "127.0.0.1" || host === "::1") return true;
    if (/^10\./.test(host)) return true;
    if (/^192\.168\./.test(host)) return true;
    if (/^172\.(1[6-9]|2\d|3[01])\./.test(host)) return true;
    if (/^fe80:/i.test(host)) return true;
    return false;
  } catch {
    return false;
  }
}

app.use(cors({
  origin: (origin, callback) => {
    if (isAllowedOrigin(origin)) callback(null, true);
    else callback(new Error(`Origine non autorisée: ${origin}`));
  },
  credentials: true,
}));

app.use(express.json({ limit: "50mb" }));

// Context creator
async function createContext({ req, res }: { req: express.Request; res: express.Response }): Promise<Context> {
  let user = null;
  
  const cookies = parseCookie(req.headers.cookie || "");
  const token = cookies[COOKIE_NAME];
  
  if (token) {
    const session = await verifySession(token);
    if (session) {
      const dbUser = await prisma.user.findUnique({ where: { id: session.userId } });
      if (dbUser) {
        user = { id: dbUser.id, name: dbUser.name, email: dbUser.email, role: dbUser.role };
      }
    }
  }
  
  return { req, res, user };
}

// tRPC middleware
app.use("/api/trpc", createExpressMiddleware({
  router: appRouter,
  createContext,
}));

// ============================================
// SOCKET.IO
// ============================================
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: (origin, callback) => {
      if (isAllowedOrigin(origin)) callback(null, true);
      else callback(new Error(`Origine non autorisée: ${origin}`));
    },
    credentials: true,
  },
  transports: ["websocket", "polling"],
});

// Stockage en mémoire des états
const eventStates = new Map<string, {
  currentQuestion: number;
  showResults: boolean;
  votingOpen: boolean;
  status: string;
  timerEndAt: number | null;
  timerDuration: number | null;
}>();

// ============================================
// Fonction utilitaire : charger les résultats depuis la DB
// ============================================
async function loadResultsFromDB(eventCode: string, questionId: number) {
  const answers = await prisma.answer.findMany({
    where: { questionId },
  });

  // Récupérer le type de question
  const question = await prisma.question.findUnique({ where: { id: questionId } });
  if (!question) return;

  if (question.type === "mcq" || question.type === "trueFalse") {
    const counts: Record<string, number> = {};
    answers.forEach(a => {
      const content = JSON.parse(a.content);
      if (content.selectedOptionId) {
        counts[content.selectedOptionId] = (counts[content.selectedOptionId] || 0) + 1;
      }
    });
    io.to(`presenter:${eventCode}`).emit("LIVE_RESULTS", {
      questionId, results: counts, totalAnswers: answers.length,
    });
  } else if (question.type === "scale") {
    const valueCounts: Record<string, number> = {};
    let sum = 0; let cnt = 0;
    answers.forEach(a => {
      const content = JSON.parse(a.content);
      if (content.value !== undefined) {
        const v = String(content.value);
        valueCounts[v] = (valueCounts[v] || 0) + 1;
        sum += Number(content.value); cnt++;
      }
    });
    io.to(`presenter:${eventCode}`).emit("LIVE_RESULTS", {
      questionId, results: valueCounts, totalAnswers: answers.length,
      type: "scale",
      average: cnt > 0 ? Math.round((sum / cnt) * 10) / 10 : null,
    });
  } else if (question.type === "wordcloud") {
    const wordCounts: Record<string, number> = {};
    answers.forEach(a => {
      const content = JSON.parse(a.content);
      (content.words || []).forEach((w: string) => {
        const word = w.toLowerCase().trim();
        if (word) {
          wordCounts[word] = (wordCounts[word] || 0) + 1;
        }
      });
    });

    io.to(`presenter:${eventCode}`).emit("LIVE_RESULTS", {
      questionId,
      results: wordCounts,
      totalAnswers: answers.length,
      type: "wordcloud",
    });
  } else if (question.type === "open") {
    const openAnswers = answers.map(a => {
      const content = JSON.parse(a.content);
      return content.text || "";
    }).filter(t => t);

    io.to(`presenter:${eventCode}`).emit("LIVE_RESULTS", {
      questionId,
      results: openAnswers,
      totalAnswers: answers.length,
      type: "open",
    });
  }
}

// ============================================
// SOCKET.IO EVENT HANDLERS
// ============================================
io.on("connection", (socket) => {
  console.log(`[Socket] Client connecté: ${socket.id}`);

  // Participant rejoint un événement
  socket.on("JOIN_ROOM", async (data: { eventCode: string; participantId: number; nickname: string }) => {
    const room = `event:${data.eventCode}`;
    socket.join(room);
    
    // Restaurer l'état depuis la DB si pas en mémoire
    if (!eventStates.has(data.eventCode)) {
      const dbEvent = await prisma.event.findUnique({
        where: { code: data.eventCode },
      });
      if (dbEvent) {
        eventStates.set(data.eventCode, {
          currentQuestion: dbEvent.currentQuestion || 0,
          showResults: dbEvent.showResults || false,
          votingOpen: dbEvent.votingOpen ?? true,
          status: dbEvent.status || "waiting",
          timerEndAt: null,
          timerDuration: null,
        });
      }
    }
    
    // Envoyer l'état actuel
    const state = eventStates.get(data.eventCode);
    if (state) {
      socket.emit("UPDATE_STATE", state);
    }
    
    // Notifier le présentateur
    io.to(`presenter:${data.eventCode}`).emit("PARTICIPANT_JOINED", {
      participantId: data.participantId,
      nickname: data.nickname,
    });
    
    // Mettre à jour le compte (exclure le présentateur)
    const eventRoom = io.sockets.adapter.rooms.get(room);
    const presenterRoom = io.sockets.adapter.rooms.get(`presenter:${data.eventCode}`);
    const presenterSockets = presenterRoom ? presenterRoom.size : 0;
    const totalInRoom = eventRoom ? eventRoom.size : 0;
    const count = Math.max(0, totalInRoom - presenterSockets);
    io.to(room).emit("PARTICIPANT_COUNT", count);
    io.to(`presenter:${data.eventCode}`).emit("PARTICIPANT_COUNT", count);
    
    console.log(`[Socket] ${data.nickname} a rejoint ${data.eventCode}`);
  });

  // Présentateur rejoint
  socket.on("PRESENTER_JOIN", async (data: { eventCode: string }) => {
    socket.join(`event:${data.eventCode}`);
    socket.join(`presenter:${data.eventCode}`);
    
    // Restaurer l'état depuis la DB si pas en mémoire
    if (!eventStates.has(data.eventCode)) {
      const dbEvent = await prisma.event.findUnique({
        where: { code: data.eventCode },
      });
      eventStates.set(data.eventCode, {
        currentQuestion: dbEvent?.currentQuestion || 0,
        showResults: dbEvent?.showResults || false,
        votingOpen: dbEvent?.votingOpen ?? true,
        status: dbEvent?.status || "waiting",
        timerEndAt: null,
        timerDuration: null,
      });
    }

    // Envoyer l'état actuel au présentateur
    const state = eventStates.get(data.eventCode)!;
    socket.emit("UPDATE_STATE", state);

    // Charger les résultats existants pour la question courante
    const event = await prisma.event.findUnique({
      where: { code: data.eventCode },
      include: { questions: { orderBy: { order: "asc" } } },
    });

    if (event && event.questions[state.currentQuestion]) {
      await loadResultsFromDB(data.eventCode, event.questions[state.currentQuestion].id);
    }
    
    console.log(`[Socket] Présentateur a rejoint ${data.eventCode}`);
  });

  // Démarrer / Reprendre l'événement
  socket.on("START_EVENT", async (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode) || {
      currentQuestion: 0,
      showResults: false,
      votingOpen: true,
      status: "live",
      timerEndAt: null,
      timerDuration: null,
    };
    // Reprendre là où on en était (ne pas réinitialiser currentQuestion)
    state.status = "live";
    state.votingOpen = true;
    eventStates.set(data.eventCode, state);
    
    await prisma.event.update({
      where: { code: data.eventCode },
      data: { status: "live" },
    });
    
    io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", state);
    io.to(`event:${data.eventCode}`).emit("EVENT_STARTED");

    // Charger les résultats existants pour la question courante (pas forcément la première)
    const event = await prisma.event.findUnique({
      where: { code: data.eventCode },
      include: { questions: { orderBy: { order: "asc" } } },
    });
    if (event && event.questions[state.currentQuestion]) {
      await loadResultsFromDB(data.eventCode, event.questions[state.currentQuestion].id);
    }
  });

  // Question suivante - AVEC PERSISTANCE
  socket.on("NEXT_QUESTION", async (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode);
    if (state) {
      state.currentQuestion++;
      state.showResults = false;
      state.votingOpen = true;
      state.timerEndAt = null;
      eventStates.set(data.eventCode, state);
      
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", state);
      io.to(`event:${data.eventCode}`).emit("QUESTION_CHANGED", state.currentQuestion);

      // Charger les résultats existants pour la nouvelle question
      const event = await prisma.event.findUnique({
        where: { code: data.eventCode },
        include: { questions: { orderBy: { order: "asc" } } },
      });
      if (event && event.questions[state.currentQuestion]) {
        await loadResultsFromDB(data.eventCode, event.questions[state.currentQuestion].id);
      }
    }
  });

  // Question précédente - AVEC PERSISTANCE
  socket.on("PREVIOUS_QUESTION", async (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode);
    if (state && state.currentQuestion > 0) {
      state.currentQuestion--;
      state.showResults = false;
      state.votingOpen = true;
      state.timerEndAt = null;
      eventStates.set(data.eventCode, state);
      
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", state);
      io.to(`event:${data.eventCode}`).emit("QUESTION_CHANGED", state.currentQuestion);

      // Charger les résultats existants pour la question précédente
      const event = await prisma.event.findUnique({
        where: { code: data.eventCode },
        include: { questions: { orderBy: { order: "asc" } } },
      });
      if (event && event.questions[state.currentQuestion]) {
        await loadResultsFromDB(data.eventCode, event.questions[state.currentQuestion].id);
      }
    }
  });

  // Toggle résultats
  socket.on("TOGGLE_RESULTS", (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode);
    if (state) {
      state.showResults = !state.showResults;
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", state);
    }
  });

  // Toggle votes
  socket.on("TOGGLE_VOTING", (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode);
    if (state) {
      state.votingOpen = !state.votingOpen;
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", state);
    }
  });

  // Soumettre une réponse - AVEC NUAGE DE MOTS (accumulation)
  socket.on("SUBMIT_ANSWER", async (data: { 
    eventCode: string; 
    questionId: number; 
    participantId: number;
    content: any;
  }) => {
    // Pour le nuage de mots avec append=true, on accumule les mots
    if (data.content.append && data.content.words) {
      const existing = await prisma.answer.findUnique({
        where: {
          questionId_participantId: {
            questionId: data.questionId,
            participantId: data.participantId,
          },
        },
      });

      let allWords: string[] = [];
      if (existing) {
        try {
          const prev = JSON.parse(existing.content);
          allWords = prev.words || [];
        } catch {}
      }
      allWords = [...allWords, ...data.content.words];

      const contentToSave = JSON.stringify({ words: allWords });

      await prisma.answer.upsert({
        where: {
          questionId_participantId: {
            questionId: data.questionId,
            participantId: data.participantId,
          },
        },
        update: { content: contentToSave },
        create: {
          questionId: data.questionId,
          participantId: data.participantId,
          content: contentToSave,
        },
      });
    } else {
      // Comportement normal (QCM, question ouverte)
      await prisma.answer.upsert({
        where: {
          questionId_participantId: {
            questionId: data.questionId,
            participantId: data.participantId,
          },
        },
        update: { content: JSON.stringify(data.content) },
        create: {
          questionId: data.questionId,
          participantId: data.participantId,
          content: JSON.stringify(data.content),
        },
      });
    }

    // Recharger tous les résultats depuis la DB pour cette question
    await loadResultsFromDB(data.eventCode, data.questionId);
    // Confirmer au participant
    socket.emit("ANSWER_CONFIRMED");
    console.log(`[Socket] Réponse reçue pour question ${data.questionId}`);
  });

  // Démarrer un timer
  socket.on("START_TIMER", (data: { eventCode: string; durationMs: number }) => {
    const state = eventStates.get(data.eventCode);
    if (state) {
      const durationSec = Math.round(data.durationMs / 1000);
      state.timerEndAt = Date.now() + data.durationMs;
      state.timerDuration = durationSec;
      state.votingOpen = true;
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", { ...state });
      setTimeout(() => {
        const s = eventStates.get(data.eventCode);
        if (s && s.timerEndAt && Date.now() >= s.timerEndAt) {
          s.votingOpen = false;
          s.timerEndAt = null;
          s.timerDuration = null;
          io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", { ...s });
        }
      }, data.durationMs + 500);
    }
  });

  // Arrêter le timer
  socket.on("STOP_TIMER", (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode);
    if (state) {
      state.timerEndAt = null;
      state.timerDuration = null;
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", { ...state });
    }
  });

  // Terminer l'événement (sauvegarde la position courante)
  socket.on("END_EVENT", async (data: { eventCode: string }) => {
    const state = eventStates.get(data.eventCode);
    if (state) {
      state.status = "finished";
      io.to(`event:${data.eventCode}`).emit("UPDATE_STATE", state);
      io.to(`event:${data.eventCode}`).emit("EVENT_ENDED");
    }
    
    // Sauvegarder la position courante en DB pour pouvoir reprendre
    await prisma.event.update({
      where: { code: data.eventCode },
      data: {
        status: "finished",
        currentQuestion: state?.currentQuestion || 0,
        showResults: state?.showResults || false,
        votingOpen: state?.votingOpen ?? true,
      },
    });
  });

  socket.on("disconnect", () => {
    console.log(`[Socket] Client déconnecté: ${socket.id}`);
    // Pour chaque event auquel ce socket appartenait, recalculer le compte
    // Note: à la déconnexion, socket.rooms est déjà vide, on doit itérer sur toutes les rooms connues
    for (const eventCode of eventStates.keys()) {
      const room = `event:${eventCode}`;
      const presenterRoomName = `presenter:${eventCode}`;
      const eventRoom = io.sockets.adapter.rooms.get(room);
      const presenterRoom = io.sockets.adapter.rooms.get(presenterRoomName);
      const presenterSockets = presenterRoom ? presenterRoom.size : 0;
      const totalInRoom = eventRoom ? eventRoom.size : 0;
      const count = Math.max(0, totalInRoom - presenterSockets);
      io.to(room).emit("PARTICIPANT_COUNT", count);
      io.to(presenterRoomName).emit("PARTICIPANT_COUNT", count);
    }
  });
});

// ============================================
// STATIC FILES (Production)
// ============================================
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../dist/client")));
  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../dist/client/index.html"));
  });
}

// ============================================
// START SERVER
// ============================================
const PORT = parseInt(process.env.PORT || "3001");

httpServer.listen(PORT, "0.0.0.0", () => {
  console.log("\n========================================");
  console.log("🚀 InteractLive - Serveur démarré !");
  console.log("========================================");
  console.log(`\n📍 API Backend:     http://localhost:${PORT}`);
  console.log(`\n📍 Accès local:     http://localhost:3000`);
  console.log(`📍 Accès réseau:    http://${LOCAL_IP}:3000`);
  console.log(`\n📱 Les participants peuvent rejoindre via:`);
  console.log(`   http://${LOCAL_IP}:3000/join`);
  console.log("\n========================================\n");
});
